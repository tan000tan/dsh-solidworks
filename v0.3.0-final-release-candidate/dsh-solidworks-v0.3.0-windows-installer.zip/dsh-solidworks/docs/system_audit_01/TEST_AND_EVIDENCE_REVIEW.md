# NIGHT-SYSTEM-AUDIT-01 测试可信度与运行物证复核报告 (Test & Evidence Review)

## 一、测试分层与覆盖度统计

项目当前建立了跨越五个层次的测试防护网，其实际覆盖与通过情况复核如下：

| 测试层级 | 技术载体 | 测试用例数 | 实际状态 | 证据等级 | 核心评价 |
| :--- | :--- | :---: | :---: | :---: | :--- |
| **L1 (离线纯单元测试)** | Python `unittest` | 121 项 | 全部 PASS | E3 | 覆盖状态机、特征图、IR解析、拓扑排序、尺寸迁移与影子备份，执行迅速，无外部依赖 |
| **L1/L4 (宿主策略契约测试)** | Node.js Test Runner | 68 项 | 全部 PASS | E3 | 覆盖风险评级、路径遍历阻断、FastMCP 参数解包与打包纯净度 |
| **L2 (宿主桩服务与崩溃隔离测试)** | `host.test.js` / `crash.test.js` | 18 项 | 全部 PASS | E3 | 验证 Python 启动崩溃、服务断开时的优雅降级与 `solidworks_status` 诊断 |
| **L3 (真实 SolidWorks 实机测试)** | `tests/real_cad/` | 20+ 套件 | 实机通过 | E4 | 覆盖真实建模、特征树物理逆序回滚、2D工程图保存重开闭环与多批次资源压测 |
| **L4/L5 (DSH 宿主全真端到端)** | `dsh_host_trace_test.mjs` | 4 场景 | 实机通过 | E4/E5 | 验证 Node.js McpClient 与 Python MCP Server 纯净 stdio 协议级全真交互 |

---

## 二、历史重大争议与技术真相彻底清算

### 1. 历史 E07 测试假阳性通过之谜（圆角/倒角）
- **历史现象**：在 NIGHT-02 / NIGHT-03 审计中，历史 JSON 记录显示倒角特征实际上未生效（`chamfer: false`），但测试脚本最终判定仍然为 `[PASS]`。
- **底层根因查实**：
  经静态审计 `vendor/solidworks-automation-skill/scripts/cad_graph_executor.py` 第 769 与 778 行代码：
  ```python
  elif ftype == FeatureType.FILLET:
      radius_m = float(args["radius_m"])
      edges = args.get("edges", None)
      fillet(model, radius_m, edges=edges)      # <-- 根本没有接收返回值！
      return node.name or "Fillet1"             # <-- 直接无条件返回成功！

  elif ftype == FeatureType.CHAMFER:
      distance_m = float(args["distance_m"])
      angle_deg = float(args.get("angle_deg", 45.0))
      chamfer(model, distance_m, angle_deg=angle_deg)  # <-- 根本没有接收返回值！
      return node.name or "Chamfer1"                   # <-- 直接无条件返回成功！
  ```
  **审查定性**：代码执行器在调用倒角/圆角时，完全忽略了底层 COM API 的执行结果，即使 SolidWorks 返回空或失败，执行器也直接宣布该节点执行完毕，并伪造节点名称向后推进！这直接导致了历史测试中的“虚假通过 (False Positive)”。

### 2. 历史 E11 测试 Top Plane 质心校正之谜
- **历史现象**：在基准测试中，Top Plane 拉伸立方体的质心校验曾发生偏离报错。
- **底层根因查实**：SolidWorks 在上视基准面（Top Plane）执行默认方向拉伸时，法向向量沿 $-Y$ 方向增长，其真实质心 $Y$ 坐标为负值。早期测试用例将理论值硬编码为正值，引发断言冲突。后续在 NIGHT-04 中通过理论坐标校正与 `GeometryVerifier` 修正，该问题已通过实机验证闭环。

### 3. Python 测试数量口径争议（51 vs 111 vs 121）
- **历史争议**：历史报告曾出现将 51/51 与 111 项测试混淆的口径问题。
- **本次实机清点真相**：
  通过 `unittest.TestLoader().discover('tests', pattern='*_test.py')` 实机清点：
  - 当前代码库共有 **18 个测试文件**，总计 **121 项独立测试用例**；
  - 历史演进脉络：早期子模块单测共 51 项；后经 P0.4/P1 扩展至 111 项；在 NIGHT-04/07 引入状态机（7项）与尺寸迁移（3项）后，当前实存 121 项单测；
  - **审查定性**：历史报告确实存在用局部套件通过率代替全局套件的口径不严谨，但当前 121 项测试均真实存在并保持 100% 通过。

### 4. Node.js 测试数量与执行范围审查（68 项 vs 隐藏套件）
- **审查发现**：`package.json` 中的默认 `npm test` 仅串行执行 4 个测试文件（`policy.test.js`, `mcp.test.js`, `schema.test.js`, `package.test.js`），总计 **68 项断言**。
- **隐藏测试**：`audit.test.js`、`host.test.js`、`crash.test.js`（共约 35 项断言）仅在配置了显式脚本或显式传参时运行，并未纳入默认 `npm test` 命令。经本轮单独执行核验，上述隐藏套件均能通过，但存在测试覆盖分流的治理瑕疵。

---

## 三、真实 CAD 核心能力物证复核

### 1. Level 3 真实特征树物理逆序回滚 —— [VERIFIED, 等级 E4]
- **物证文件**：`tests/real_cad/sandbox/night_07/evidence_night07.json`
- **核验数据**：
  - 正向建模：基板（$150,000\text{ mm}^3$）+ 支柱（$175,623.62\text{ mm}^3$）；
  - 注入异常后逆序删除：`['凸台-拉伸2', '草图2', '凸台-拉伸1', '草图1']`；
  - 内存态核验：实体数由 1 降为 0，物理体积清零为 $0.00\text{ mm}^3$；
  - 离线落盘重开一致性核验：重新打开模型，实体数依然精确为 0，体积依然为 $0.00\text{ mm}^3$；
  - 初始特征保护：初始 18 项基准面与系统特征未受误伤。

### 2. 2D 工程图保存、关闭与重新打开闭环 —— [VERIFIED, 等级 E4]
- **物证文件**：`tests/real_cad/sandbox/night_07/evidence_night07.json`
- **核验数据**：
  - 源零件保存与正交投影：主视图、俯视图、左视图 3 视图完整投影；
  - 矢量 PDF 导出：成功导出 50,684 字节有效矢量文档；
  - 重新打开（Re-open）：耗时 1930ms 重新打开离线 `.SLDDRW`，结构内省状态为 `pass`，视图清单与图元完好。

---

## 四、测试盲区与无法完全验证项 (Blind Spots)

1. **真实 DSH 桌面 Electron 容器端到端交互缺少生产级长期物证 [等级 E4，未达到 E5]**：
   目前所有的集成验证均是通过 Node.js 脚本模拟 McpClient 与 Python Server 通信，**尚未在带有真实用户界面的 DSH Electron 桌面客户端上完成连续 8 小时以上的生产环境端到端自动化录制与验证**；
2. **多用户 / 跨机器网络 MCP (Streamable HTTP) 未全面实机测试**：
   虽然 `server.py` 声明了 `--transport streamable-http` 模式，但在当前真实测试套件中，所有实机测试均基于本地 `stdio`，跨机器网络并发场景处于未充分验证状态（UNVERIFIED）。
