# NIGHT-SYSTEM-AUDIT-01 安全策略与权限边界审计报告 (Security Review)

## 一、威胁模型与信任边界定义

在 DSH 桌面宿主与 SolidWorks 交互场景中，系统面临以下核心安全威胁：
1. **不可信或幻觉的 Agent 指令**：LLM 生成了错误的参数（如负数拉伸、越界孔径、自交轮廓），或者误解用户意图直接尝试覆盖、删除关键图纸；
2. **恶意路径注入与系统探测**：通过构造包含目录穿越（`../`）、Windows 目录连接点（NTFS Junction）、DOS 保留设备名（`CON`, `NUL`）或远程 UNC 路径（试图触发 SMB NTLM 哈希嗅探）；
3. **权限提升与越权写操作**：绕过用户确认（Confirmation Grant）机制，伪造或重用已有授权凭据，向系统磁盘或只读白名单零件发起非法写入；
4. **CAD 进程状态污染与不可逆破坏**：异常中断后导致 SolidWorks 后台留下无序堆积的脏文档，锁定文件句柄导致用户正常工作流瘫痪。

---

## 二、信任边界与防御深度核验

```mermaid
flowchart LR
    subgraph Untrusted_Zone ["不可信域 (Agent / LLM)"]
        AgentPrompt["Agent 生成的工具调用与参数"]
    end

    subgraph Defense_Line_1 ["第一道防线: 宿主安全策略 (lib/policy.js)"]
        ModeCheck{"Policy Mode 检查<br>(read-only / standard / full)"}
        TierClassify["Zero-Trust 分级分类<br>(READ / WRITE / HIGH)"]
        GrantVerifier{"单次绑定授权校验<br>(solidworks_confirm)"}
        PathSandbox{"物理真实路径校验<br>(allowedRoots / Junction 拦截)"}
    end

    subgraph Defense_Line_2 ["第二道防线: 协议安全适配 (lib/index.js & schema.js)"]
        SchemaValidator["FastMCP 参数结构校验"]
        StdioIsolation["stdio 管道重定向隔离"]
    end

    subgraph Defense_Line_3 ["第三道防线: CAD 执行与事务隔离 (Python 侧)"]
        TaskIsolation["CADTaskContext 独立上下文"]
        ProtectedFeatures["系统基准与白名单特征保护"]
        Level3Rollback["Level 3 真实逆序特征物理回滚"]
    end

    subgraph Trusted_Target ["受信目标 (SolidWorks 桌面宿主)"]
        SolidWorksDesktop["SolidWorks 进程 / 物理磁盘模型"]
    end

    AgentPrompt --> ModeCheck
    ModeCheck -- "未授权写操作" --> Refuse1["拦截: 拒绝执行 (POLICY_MODE)"]
    ModeCheck -- "进入校验" --> TierClassify
    TierClassify -- "HIGH 级高风险操作" --> GrantVerifier
    GrantVerifier -- "无有效单次授权" --> Refuse2["拦截: 需要显式确认 (CONFIRMATION_REQUIRED)"]
    GrantVerifier -- "授权有效" --> PathSandbox
    PathSandbox -- "路径越界 / 目录遍历" --> Refuse3["拦截: 越界路径拒绝 (PATH_OUTSIDE_ALLOWED_ROOTS)"]
    PathSandbox -- "合法受控路径" --> SchemaValidator
    SchemaValidator --> StdioIsolation
    StdioIsolation --> TaskIsolation
    TaskIsolation --> ProtectedFeatures
    ProtectedFeatures --> Level3Rollback
    Level3Rollback --> SolidWorksDesktop
```

---

## 三、安全机制实证与对抗式检验结论

### 1. 默认拒绝 (Fail-Closed) 策略有效性 —— [VERIFIED]
- **源码断言**：`lib/policy.js` 默认 `mode = 'read-only'`。在只读模式下，仅发布 `READ` 级别工具；任何 `WRITE` 和 `HIGH` 级别工具直接被 withheld。
- **未知工具防御**：`classify(name)` 采用 Zero-Trust 设计，若遇到未知工具名，默认归为 `HIGH`，绝不回退至 `READ`。

### 2. 单次绑定授权 (One-Shot Bound Grant) 机制 —— [VERIFIED]
- **源码断言**：`solidworks_confirm` 将工具名与其确切参数序列化后计算 SHA256 摘要（`digest`），绑定在内部的 `#grants` 映射中。
- **防重放与防篡改**：
  1. 授权被一次性消费后立即 `this.#grants.delete(key)`，即使同一指令重复提交也必须重新授权；
  2. 哪怕修改参数中的一个浮点数字符，生成的摘要即刻改变，原授权失效；
  3. 授权具有严格的有效时长（默认 `grantTtlMs = 300,000`，即 5 分钟），超时自动作废。

### 3. 文件系统与路径安全防御 —— [VERIFIED]
- **Junction / 符号链接穿透**：通过 Windows API 原生 `GetFinalPathNameByHandle` 解析物理磁盘真实路径，彻底阻断利用 Junction 将临时目录指向系统盘的逃逸行为；
- **目录遍历防御**：递归解析每一层路径，对包含 `..` 尝试越出 `allowedRoots` 的操作坚决阻断；
- **DOS 设备与远程 UNC 拦截**：针对 `CON`, `PRN`, `AUX`, `NUL` 等保留设备名，以及以 `\\` 开头的 UNC 远程路径（防止 Windows 自动发起 SMB 认证泄露 NTLM Hash），均直接拒绝。

---

## 四、安全盲区与脆弱点审计 (Vulnerability Findings)

### 1. 【高风险】新增 5 个高级参数化工具未在 Manifest 与 Policy 中显式注册
- **风险分析**：Python 暴露了 `solidworks_compile_feature_graph`, `solidworks_execute_feature_graph`, `solidworks_identify_dimensions`, `solidworks_inspect_dimension_impact`, `solidworks_modify_dimension_safe`。这些工具未进入 `RISK_TABLE`。虽然 `classify()` 正则兜底将其归为 `HIGH`，但由于 Manifest 缺失，DSH 宿主无法在 UI 上为用户呈现标准风险卡片，导致用户在确认授权时看到的提示可能不准确或缺乏上下文。

### 2. 【中风险】白名单受保护零件缺少 Policy 层全局一等公民拦截
- **风险分析**：目前白名单保护列表 `['垫圈.SLDPRT', '螺母 GB_T 6170 M10.SLDPRT']` 仅在 Python 实机测试脚本和特定回滚逻辑中做过滤检查。
- **潜在穿透路径**：如果用户将工作区配置为 `allowedRoots`，Agent 若生成 `solidworks_open_document` 或 `solidworks_save_document` 指向白名单零件，只要用户在交互中误点击了确认，`policy.js` 会认为该文件在 `allowedRoots` 内部而放行，最终由底层直接写入！
- **修复方案**：应在 `policy.js` 中新增全局只读黑名单规则，即使在 `full` 模式下，针对特定关键零件的修改也必须硬编码拒绝（Hard Fail-Closed）。
