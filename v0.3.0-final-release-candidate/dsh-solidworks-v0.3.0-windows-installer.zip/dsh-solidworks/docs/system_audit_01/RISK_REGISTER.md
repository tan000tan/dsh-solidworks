# NIGHT-SYSTEM-AUDIT-01 风险登记总表 (Risk Register)

## 一、风险统计摘要

- **CRITICAL（严重）**：0 项
- **HIGH（高风险）**：2 项
- **MEDIUM（中风险）**：4 项
- **LOW（低风险）**：3 项
- **INFO（提示与建议）**：2 项
- **总计登记风险项**：11 项

---

## 二、风险登记表（按严重程度降序排列）

| ID | 风险项描述 | 等级 | 所属阶段 | 潜在影响 | 关联代码与物证 | 触发 / 复现条件 | 处置建议 | 是否阻断跨阶段发布 |
| :--- | :--- | :---: | :---: | :--- | :--- | :--- | :--- | :---: |
| **RSK-01** | **工具注册与风险表漂移**<br>Python MCP 暴露 71 工具，Manifest 与 Policy 仅登记 66 工具 | **HIGH** | 第一/二阶段 | DSH 宿主无法通过 Manifest 静态发现 5 个高级参数化工具；且未在 `RISK_TABLE` 中显式评级，完全依赖运行时动态 fallback 判定，存在策略失配风险 | `vendor/.../mcp-server/server.py`<br>`dsh-plugin.json`<br>`lib/policy.js:34` | DSH 宿主解析 `dsh-plugin.json` 时试图调用新增的 `solidworks_compile_feature_graph` 或 `solidworks_modify_dimension_safe` | 在 `dsh-plugin.json` 与 `lib/policy.js` 中显式补全这 5 个工具的声明与风险分级 | **是** |
| **RSK-02** | **双轨制执行导致基础工具绕过事务回滚**<br>基础建模工具直接调用 `sw_part.py`，未受 `CADTaskContext` 事务纳管 | **HIGH** | 第二/三阶段 | Agent 若直接调用 `solidworks_sketch_and_extrude` 等底层基础工具建模，中途失败将无法自动逆序删除特征，在特征树中残留半成品孤儿几何 | `vendor/.../mcp-server/server.py`<br>`vendor/.../scripts/sw_part.py`<br>`cad_task_context.py` | Agent 生成直接建模指令而非 FeatureGraph，且在执行拉伸/切除中途抛出 CAD 异常 | 将所有直接建模工具底层统一路由至 `CADTaskContext` 事务执行包装器 | **是** |
| **RSK-03** | **底层 CAD 特征返回值未校验导致假阳性通过**<br>`cad_graph_executor.py` 中圆角与倒角节点执行不检查返回值 | **MEDIUM** | 第二/三阶段 | SolidWorks 内部特征构建失败（返回空或错误状态），执行器仍直接标记节点成功并推进下一步，产生虚假通过（False Positive） | `vendor/.../scripts/cad_graph_executor.py:769,778`<br>历史 E07 测试记录 | 执行无效边线倒角或超出几何极值的倒圆角操作 | 检查 `fillet()` 与 `chamfer()` 返回的 `IFeature`，核验 `GetErrorCode2()` 与有效性 | 否 |
| **RSK-04** | **代码库广泛存在静默异常吞没**<br>检索发现多达 105 处 `except ...: pass` 或 `continue` | **MEDIUM** | 第一/二/三阶段 | 底层 COM 或计算异常被掩盖，导致问题现场丢失、排查极其困难，甚至使失效特征被带入后续流程 | `vendor/.../scripts/cad_graph_executor.py:608,721,740,758,819,858` 等 105 处 | 特征重命名失败、实体读取微小异常或文件加载轻度异常 | 审计 105 处吞异常，对非容错性业务逻辑改为记录 `logger.warning` 或显式向上抛出 | 否 |
| **RSK-05** | **白名单受保护零件未上升为 Policy 一等公民**<br>`['垫圈.SLDPRT', '螺母 GB_T 6170 M10.SLDPRT']` 仅在测试脚本硬编码 | **MEDIUM** | 第二阶段 | 若外部 Agent 生成的写入路径直接指向用户受保护零件，宿主 `policy.js` 仅检查了目录是否在 `allowedRoots`，并未拦截该特定文件名 | `lib/policy.js:151`<br>`tests/real_cad/` | 用户将工作区设为 allowedRoots 且指令直接覆盖受保护零件 | 在 `policy.js` 中增加 `protectedFiles` 过滤规则，默认拒绝任何针对白名单零件的写请求 | 否 |
| **RSK-06** | **尺寸参数化体系存在历史重叠与双重实现**<br>旧 `dimension_manager` 与新 Dimension IR 体系并存 | **MEDIUM** | 第三阶段 | 增加维护负担，且不同模块对尺寸命名（`D1@草图1` vs `D1@Sketch1`）与草图维度的解析机制存在潜在不一致隐患 | `vendor/.../scripts/dimension_manager.py`<br>`vendor/.../scripts/dimension_ir.py`<br>`vendor/.../scripts/sw_document_data.py` | 复杂混合装配体或含有多重配置的零件提取尺寸时 | 制定渐进废弃计划，将旧尺寸提取底层完全代理到 Dimension IR 管道 | 否 |
| **RSK-07** | **COM 阻塞缺乏硬抢占与外部超时终止能力**<br>模态弹窗或死锁会导致 STA Worker 线程陷入内核等待 | **LOW** | 第三阶段 | 若 SolidWorks 触发必须人工点击的模态对话框，Worker 将无法处理后续任务，外部超时后旧任务仍在等待 | `vendor/.../scripts/sw_connect.py:442` | 打开损坏模型或缺失外部参考零件触发系统警告对话框 | 开启 SolidWorks 静默模式（`swUserPreferenceToggle_e.swSilentError`）并建立 Worker 崩溃强制重启恢复机制 | 否 |
| **RSK-08** | **核心宿主契约测试未纳入默认 `npm test`**<br>`audit.test.js`, `host.test.js`, `crash.test.js` 仅在 `test:all` 中运行 | **LOW** | 第一阶段 | 开发者常规运行 `npm test` 只能覆盖 68 项基础契约，无法及时感知真实宿主加载、崩溃捕获与审计流测试是否退化 | `package.json:73,80` | 常规 CI 仅执行 `npm test` | 在 `package.json` 的 `test` 脚本中合并核心宿主与审计测试套件 | 否 |
| **RSK-09** | **缺乏百轮级真实长周期高压疲劳测试**<br>目前仅进行了 3 批次轻量压测，无 8 小时连续运行数据 | **LOW** | 第三阶段 | 无法完全排除长期运行中 GDI 对象在复杂特征反复操作下的碎片化风险与极端内存泄漏 | `docs/night_engineering_07/RESOURCE_REPORT.md` | 生产环境下连续进行数十小时、数百个零件的高强度自主设计 | 在 Alpha 阶段前排期实施 100 轮连续建模疲劳测试 | 否 |
| **RSK-10** | **错误信息与诊断提示对普通机械工程师极不友好**<br>底层频繁暴露 COM HRESULT 或 Python 内部异常堆栈 | **INFO** | 第一阶段 | 用户无法理解错误根因（如 `RPC_E_WRONG_THREAD` 或 `0x8002000F`），导致自助排障困难 | `lib/index.js:296`<br>`vendor/.../scripts/sw_connect.py` | 运行环境存在轻微版本差异或权限不足时 | 在 Node.js 错误映射层增加常见 HRESULT 错误码的人类可读翻译表 | 否 |
| **RSK-11** | **缺乏建模中途进度可视化与直观撤销 UI**<br>Agent 执行长耗时建模时，前台界面表现为冻结或闪烁 | **INFO** | 第三阶段 | 用户无法感知当前执行到哪一步特征，也无法一键中断已执行的部分步骤 | DSH 交互层 | 长耗时复杂装配体构建过程中 | 在 DSH 前端组件引入任务进度条与状态机可视卡片 | 否 |
