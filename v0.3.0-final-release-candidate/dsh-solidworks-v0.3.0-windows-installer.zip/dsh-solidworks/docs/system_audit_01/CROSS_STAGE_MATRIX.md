# NIGHT-SYSTEM-AUDIT-01 跨阶段依赖与系统一致性矩阵 (Cross-Stage Matrix)

## 一、阶段定义与目标回顾

- **第一阶段（P0.1–P0.3 / Phase 1）**：项目基础与 MCP 接入（FastMCP 服务端、stdio 通信、Node.js 插件结构、基础 SolidWorks 连接与建模）；
- **第二阶段（P0.4 / Phase 2）**：安全与底层架构（Zero-Trust 策略模式、单次绑定授权 Grant、路径防穿透、FeatureGraph IR、DAG 拓扑编译）；
- **第三阶段（P1–P1.1 / Phase 3）**：执行稳定性、事务管理与故障恢复（STA Worker 专用线程、12 状态机、Level 3 真实特征树物理逆序回滚、尺寸驱动参数化统一门面、2D 工程图闭环）。

---

## 二、跨阶段依赖关系与贯通矩阵

| 交互维度 | 参与阶段 | 预期协同机制 | 当前实际贯通状态 | 审查结论与缝隙诊断 |
| :--- | :--- | :--- | :---: | :--- |
| **工具发现与注册** | 阶段一 $\to$ 阶段二 | 阶段一 Python 暴露的所有 MCP 工具均需被阶段二的 Manifest 和 Policy 风险表覆盖 | **部分断裂 (BROKEN)** | **71 vs 66 漂移**：阶段一新增 5 个高级参数化工具未在阶段二 Manifest 与 `RISK_TABLE` 中显式登记 |
| **安全策略拦截** | 阶段二 $\to$ 阶段一/三 | 任何对 SolidWorks 的写操作与高风险操作必须先经过阶段二的 Policy 检查与确认 | **完全贯通 (VERIFIED)** | 宿主入口统一被 `policy.evaluate()` 守门，默认 `read-only` 拦截全部写工具，单次授权单次消费 |
| **执行上下文纳管** | 阶段三 $\to$ 阶段一/二 | 阶段一暴露的建模工具必须被阶段三的 `CADTaskContext` 纳管，实现失败自动回滚 | **双轨分裂 (PARTIAL)** | **双轨制**：`execute_feature_graph` 具备完整回滚；但阶段一原子工具（如 `sketch_and_extrude`）直接调用 `sw_part`，绕过了回滚管理器 |
| **COM 线程与调度** | 阶段三 $\to$ 阶段一 | 阶段一所有的 COM 调用必须被路由至阶段三的 `DesktopPinnedStaWorker` 保证 STA 线程安全 | **完全贯通 (VERIFIED)** | `sw_connect.py` 的公共入口统一经由 STA Worker 单线程队列执行，杜绝跨线程封送崩溃 |
| **错误与异常传播** | 阶段三 $\to$ 阶段一/二 | 底层 SolidWorks 失败与回滚报告必须被规范转化为 JSON-RPC 错误向 DSH 宿主汇报 | **基本贯通 (VERIFIED)** | Python 异常经由 FastMCP 序列化为 `isError: true`，Node 侧转换为 `status: error/failed` 并写入审计日志 |
| **参数化与尺寸统一** | 阶段三 $\to$ 阶段一/二 | 阶段三统一门面必须兼容阶段一旧尺寸工具与阶段二新 Dimension IR 依赖图 | **完全贯通 (VERIFIED)** | `dimension_manager.py` 成功兼容旧静态接口，同时驱动底层 AST/IR 解析，24 项单测全绿 |

---

## 三、端到端全链路数据流与权限状态转移矩阵

| 步骤 | 环节 / 模块 | 所属阶段 | 输入数据 | 权限 / 状态校验 | 异常 / 故障处置 |
| :---: | :--- | :---: | :--- | :--- | :--- |
| **1** | 用户 / DSH Agent | 外部 | 自然语言或结构化设计请求 | 处于 DSH 用户会话上下文 | 格式错误直接由 Agent 拒绝 |
| **2** | `lib/policy.js` | 阶段二 | 工具名称 + 原始参数对象 | 检查模式 (read-only/standard/full)；<br>检查是否命中 Deny 白名单；<br>检查路径是否在 `allowedRoots`；<br>检查 HIGH 级单次授权 | 若未授权返回 `CONFIRMATION_REQUIRED`；<br>若越权返回 `POLICY_MODE` 或 `PATH_OUTSIDE_ALLOWED_ROOTS` |
| **3** | `lib/index.js` & `schema.js` | 阶段一 | 归一化重写参数 (rewrittenArgs) | 检查 FastMCP 是否需要 `{ params: {...} }` 包裹 | 无法连接 Python 服务时返回 `SERVER_UNAVAILABLE` 并触发 status 诊断 |
| **4** | `mcp.js` (McpClient) | 阶段一 | JSON-RPC 2.0 `tools/call` | stdio 双工管道通信；设置超时定时器 | 超时触发 `AbortController` 并终止等待 |
| **5** | `server.py` (FastMCP) | 阶段一 | 解析 JSON-RPC 请求并分发工具函数 | Pydantic 模型参数类型校验 | 参数不合法返回 MCP 400 校验错误 |
| **6** | `cad_graph_executor.py` | 阶段二/三 | Feature Graph 规范结构 | 拓扑依赖检查与环形依赖检测 | 存在依赖环立即抛出 `CyclicDependencyError` 阻止执行 |
| **7** | `cad_task_context.py` | 阶段三 | 任务 ID，纳管初始文档快照 | 状态由 `CREATED` $\to$ `VALIDATING` $\to$ `RUNNING` | 非法状态流转抛出 `InvalidStateTransitionError` |
| **8** | `DesktopPinnedStaWorker` | 阶段三 | CAD 执行函数与上下文 | 检查线程是否绑定 Default 桌面；<br>检查 COM 是否正常初始化 | 执行超时抛出 `TimeoutError`，排队超时任务直接丢弃 |
| **9** | SolidWorks COM | 底层 | C++ API 调用 (FeatureExtrusion3 等) | 检查草图是否闭合、尺寸是否合理 | 捕获底层 COM 异常，通知上层执行回滚 |
| **10** | 事务回滚与收尾 | 阶段三 | 失败特征追踪列表 | 状态流转至 `ROLLING_BACK`；<br>强制重建与实体数核验 | 若回滚失败流转至 `RECOVERY_REQUIRED` 阻止盲目重试；回滚成功流转至 `FAILED` |
| **11** | 结果交付与审计 | 阶段一/二 | 几何与执行明细 | 写入 `auditLog`（脱敏参数摘要与耗时） | 审计写入失败静默容错，不阻断正常业务 |

---

## 四、跨阶段关键阻断性问题总结

1. **阻断项 1（阶段一 $\to$ 阶段二）**：**Manifest 与 Policy 缺失 5 个高级参数化工具**。
   直接阻断了 DSH 宿主通过正规方式发现并调度 FeatureGraph 与安全尺寸修改工具，破坏了系统的声明一致性。
2. **阻断项 2（阶段一 $\to$ 阶段三）**：**原子建模工具未纳入阶段三事务上下文**。
   导致系统虽然在报告中宣称具备“Level 3 真实特征树物理回滚”，但该能力仅在特定的图执行工具中生效，直接调用原子建模工具时依然存在模型污染风险。
