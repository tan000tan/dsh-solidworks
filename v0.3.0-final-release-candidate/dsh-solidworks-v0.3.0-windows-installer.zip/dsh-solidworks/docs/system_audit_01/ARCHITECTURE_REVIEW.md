# NIGHT-SYSTEM-AUDIT-01 系统架构与调用链总审查 (Architecture Review)

## 一、系统架构现状剖析

`dsh-solidworks` 旨在为 DeepSeek Harness (DSH) 桌面宿主提供安全、参数化驱动且具备事务故障恢复能力的 SolidWorks 自动化桥梁。整体架构跨越两个运行时（Node.js 与 Python），通过严格的标准输入输出 (stdio) JSON-RPC 进行解耦。

### 1.1 系统物理与逻辑分层图

```mermaid
flowchart TD
    subgraph DSH_Host ["DSH 桌面宿主层 (Cordis 容器)"]
        UI["DSH Agent / 前端交互"]
        HostCtx["Cordis Context (ctx.tools)"]
    end

    subgraph Node_Plugin ["Node.js 插件适配层 (lib/)"]
        Index["index.js (生命周期 / 注册)"]
        Policy["policy.js (Zero-Trust 策略)"]
        Schema["schema.js (FastMCP 协议适配)"]
        Discover["discover.js (环境与 Python 探测)"]
        McpClient["mcp.js (stdio JSON-RPC 双工)"]
    end

    subgraph Python_MCP ["Python MCP 服务层 (mcp-server/)"]
        FastMCPServer["server.py (FastMCP 1.30 服务端)"]
        StdioRedirect["stdio 重定向保护 (stdout -> stderr)"]
        ToolManager["FastMCP Tool Manager (71 项工具)"]
    end

    subgraph Python_Core ["Python 核心业务与事务层 (scripts/)"]
        FeatureGraph["feature_graph_ir.py (特征图 IR / 校验)"]
        GraphExecutor["cad_graph_executor.py (拓扑执行引擎)"]
        TaskContext["cad_task_context.py (12状态机 / 物理回滚)"]
        DimensionMgr["dimension_manager.py (参数化统一门面)"]
        DimensionIR["dimension_ir.py / reader / resolver"]
        SWPart["sw_part.py / sw_drawing.py / sw_measure.py"]
    end

    subgraph COM_Bridge ["Windows COM 调度层"]
        StaWorker["DesktopPinnedStaWorker (STA 专用线程)"]
        DesktopPin["Windows Default Desktop Pinning"]
        MsgPump["PumpWaitingMessages (COM 消息泵)"]
    end

    subgraph SolidWorks_Desktop ["SolidWorks 桌面宿主"]
        ROT["Running Object Table (ROT)"]
        SldWorksApp["SldWorks.Application (C++ Out-of-Process Server)"]
        ModelDoc["ModelDoc2 (零件 / 装配体 / 工程图)"]
        FeatureTree["FeatureTree (真实物理特征树)"]
    end

    UI --> HostCtx
    HostCtx --> Index
    Index --> Policy
    Policy --> Index
    Index --> Schema
    Index --> McpClient
    Index --> Discover

    McpClient <-- "stdio (JSON-RPC 2.0)" --> StdioRedirect
    StdioRedirect --> FastMCPServer
    FastMCPServer --> ToolManager

    ToolManager --> FeatureGraph
    ToolManager --> GraphExecutor
    ToolManager --> DimensionMgr
    ToolManager --> SWPart

    GraphExecutor --> TaskContext
    TaskContext --> StaWorker
    SWPart --> StaWorker
    DimensionMgr --> DimensionIR
    DimensionIR --> StaWorker

    StaWorker --> DesktopPin
    StaWorker --> MsgPump
    StaWorker --> ROT
    ROT --> SldWorksApp
    SldWorksApp --> ModelDoc
    ModelDoc --> FeatureTree
```

---

## 二、真实端到端关键调用链

### 2.1 链路 A：带事务保障的高级特征图执行链路 (Feature Graph Path)

```mermaid
sequenceDiagram
    autonumber
    actor User as 用户 / Agent
    participant Host as DSH 宿主 (Cordis)
    participant Policy as policy.js (安全策略)
    participant MCP as mcp.js (McpClient)
    participant Server as server.py (FastMCP)
    participant Exec as cad_graph_executor.py
    participant Ctx as cad_task_context.py
    participant Worker as DesktopPinnedStaWorker
    participant SW as SolidWorks COM

    User->>Host: 提出参数化设计/修改需求
    Host->>Policy: evaluate("solidworks_execute_feature_graph", args)
    alt 未授权写操作 / 高风险
        Policy-->>Host: refused / confirmation-required
    else 策略允许通过
        Policy-->>Host: allowed (rewrittenArgs)
        Host->>MCP: callTool("solidworks_execute_feature_graph", wireArgs)
        MCP->>Server: JSON-RPC "tools/call" (stdio)
        Server->>Exec: execute_feature_graph(graph_spec)
        Exec->>Ctx: 初始化 CADTaskContext(task_id)
        Ctx->>Ctx: transition_to(RUNNING)
        loop 拓扑逆序执行节点
            Exec->>Worker: execute(CAD操作函数)
            Worker->>SW: COM 调用 (如 FeatureManager.FeatureExtrusion3)
            SW-->>Worker: 返回 COM 引用 / 状态
            Worker-->>Exec: 操作执行结果
            alt 发生建模求解失败
                Exec->>Ctx: 捕获异常 -> transition_to(ROLLING_BACK)
                Ctx->>Worker: 执行 Level 3 逆序特征删除
                Worker->>SW: DeleteSelection2 物理清除特征
                Worker->>SW: ForceRebuild3 强制重建
                Ctx->>Ctx: transition_to(FAILED)
                Exec-->>Server: 抛出回滚成功及失败原因报告
            else 节点执行正常
                Exec->>Ctx: 注册已建特征 (register_feature)
            end
        end
        Exec->>Ctx: transition_to(COMMITTING) -> transition_to(SUCCEEDED)
        Exec-->>Server: 返回全量几何与执行结果
        Server-->>MCP: JSON-RPC Result (content: text)
        MCP-->>Host: 解包交付
        Host-->>User: 反馈模型创建成功
    end
```

### 2.2 链路 B：直接建模工具调用链路 (Direct API Path)
> **审查警示**：该路径直接从 `server.py` 路由至 `sw_part.py`，**完全脱离了 `CADTaskContext` 的事务纳管**。一旦执行中途抛出异常，半成品草图或特征将直接永久残留在特征树中。

---

## 三、架构缺陷与技术债清单

### 1. 契约漂移：工具注册清单不一致 (Manifest Drift)
- **事实**：Python MCP 服务端（`server.py`）实际暴露 **71** 项工具；而 DSH 插件描述清单（`dsh-plugin.json`）与策略静态风险表（`lib/policy.js: RISK_TABLE`）仅声明了 **66** 项工具。
- **缺失的 5 个关键工具**：
  1. `solidworks_compile_feature_graph`
  2. `solidworks_execute_feature_graph`
  3. `solidworks_identify_dimensions`
  4. `solidworks_inspect_dimension_impact`
  5. `solidworks_modify_dimension_safe`
- **架构后果**：DSH 宿主在基于静态 Manifest 进行工具展示与授权分析时无法感知这 5 个工具的存在；同时运行时由于不在静态 `RISK_TABLE` 中，触发动态兜底策略，在不同运行模式下可能出现意外拦截或授权阻断。

### 2. 事务边界分裂与双轨制隐患 (Dual Execution Paths)
- **事实**：系统未将所有底层写操作强制收拢至单一执行引擎。
- **后果**：如果 Agent 决定直接调用原子 MCP 工具（如 `solidworks_sketch_and_extrude`、`solidworks_fillet`）进行离散建模，一旦第二步发生几何求解失败，第一步创建的实体无法自动回滚，系统丧失了“原子性执行与自动回滚”承诺。

### 3. 尺寸驱动模块的双重历史实现 (Dual Dimension Architecture)
- **事实**：旧版基于正则表达式和简单文档遍历的 `dimension_manager.py` 与 `sw_document_data.py`，与新版基于完整 AST/IR 模型的 `dimension_ir.py`、`dimension_reader.py`、`dimension_resolver.py`、`dimension_modifier.py` 并存。
- **后果**：虽然本轮已通过统一门面做了向上兼容，但内部逻辑依然存在两套代码流，对维护成本、单位统一性与草图尺寸命名解析构成了潜在的技术债风险。

---

## 四、架构演进与最小重构建议

1. **统一工具契约**：在 `dsh-plugin.json` 与 `lib/policy.js` 中补齐 5 个高级参数化工具的元数据声明，保持 Manifest、Policy 与 Server 三位一体严格匹配（总数 71 + 2 Meta = 73 项）。
2. **底层收拢至 TaskContext 装饰器**：为 `server.py` 中所有的原子写操作工具增加统一的 `@with_cad_task_context` 上下文装饰器，使离散调用也具备自动失败回滚保护。
3. **退役旧尺寸解析路径**：将 `sw_document_data.py` 中的尺寸抽取实现重定向到底层 `DimensionReader`，收敛为单一套参数化核心。
