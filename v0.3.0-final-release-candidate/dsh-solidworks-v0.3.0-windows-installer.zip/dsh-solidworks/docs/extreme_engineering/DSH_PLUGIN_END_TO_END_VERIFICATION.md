# DSH 插件端到端调用链真实核验与普通用户体验分析

## 一、产品定位与宿主集成架构

本项目成果最终定位于 **DeepSeek Harness (DSH) 桌面宿主环境下的专业 CAD 智能体插件** (`dsh-solidworks`)。
插件架构采用分层防御体系：
1. **DSH 宿主层 (Host Tier)**：基于 Cordis 插件体系，监听桌面端用户自然语言输入，负责会话管理、工具目录呈现与前端交互卡片渲染；
2. **安全策略代理层 (Policy Gateway Tier)**：内置 `lib/policy.js` 零信任网关，实施三级风险管控（`read-only` / `standard` / `full`），接管受保护文件硬拦截（RSK-05）、沙箱路径越界阻断与高风险工具单次确认防重放授权（`solidworks_confirm`）；
3. **MCP 通信层 (MCP Transport Tier)**：基于 Model Context Protocol (FastMCP stdio)，实现 Node.js 宿主与 Python 进程的高性能、低时延全双工通信；
4. **CAD 执行引擎层 (CAD Engine Tier)**：基于 `STAWorker` 单线程单元隔离 SolidWorks COM API，纳管 `CADTaskContext` 事务与三级物理回滚管理器，直连 SolidWorks 几何建模内核。

```
 [DSH 桌面宿主 / 普通用户界面]
              │
      (自然语言指令 / 请求)
              ▼
  [dsh-solidworks Plugin Gateway]
              │
       (Policy 安全评估)
       ├── 读操作 (READ) ─────────────► 直接放行
       ├── 越界写 / 白名单保护文件 ────► [拦截拒绝] (PROTECTED_FILE_REFUSED)
       └── 高风险写操作 (HIGH) ───────► [挂起拦截] 提示用户单次授权确认
                                             │
                                    (用户点击允许 / solidworks_confirm)
                                             │
                                             ▼
                                  [FastMCP Client (stdio)]
                                             │
                                   (JSON-RPC 协议传输)
                                             ▼
                                  [FastMCP Python Server]
                                             │
                                    (STAWorker 隔离调度)
                                             ▼
                                  [SolidWorks 2024 COM API]
                                             │
                                  (物理特征构建 / 事务回滚)
                                             ▼
                                  [三维模型 / 2D工程图 / 矢量PDF]
```

---

## 二、端到端调用链实机流转闭环

在真实宿主环境自动化核验脚本中（`tests/real_cad/dsh_end_to_end_test.mjs`），系统完整走通了以下五大真实流转闭环：

### 2.1 插件装载与工具自动挂载
- 宿主完成装载后，自动扫描并注册 **73 项全量工具**（包含 71 项专业 CAD 工具与 2 个元管理工具 `solidworks_status`、`solidworks_confirm`）；
- 探针工具 `solidworks_status` 正确反馈底层运行状态、Python 解释器版本、服务脚本及当前 Policy 运行模式。

### 2.2 受保护白名单零件 Policy 级物理拦截 (RSK-05)
- **攻击场景模拟**：尝试调用参数化修改工具对系统基准受保护零件（`垫圈.SLDPRT`、`螺母 GB_T 6170 M10.SLDPRT`）执行尺寸篡改；
- **防护结果**：Policy 策略在入参解析阶段即时识别文件名指纹，直接返回 `PROTECTED_FILE_REFUSED` 物理硬拦截，请求未穿透至底层 CAD 进程，保障用户核心基准资产 100% 只读不可侵犯。

### 2.3 沙箱外部越界写入拦截防御
- **越界场景模拟**：尝试将生成的 CAD 模型保存至沙箱外部系统敏感路径；
- **防护结果**：`allowedRoots` 机制通过绝对物理路径解析（`realpath`）拦截非授权目录访问，返回 `PATH_OUTSIDE_ALLOWED_ROOTS` 错误码，杜绝路径穿越逃逸。

### 2.4 用户交互单次授权流转 (Interactive Grant Workflow)
- **第一阶段（挂起拦截）**：普通用户或智能体尝试直接调用高风险落盘工具（如 `solidworks_save_document`），Policy 判定为 HIGH 风险并返回 `CONFIRMATION_REQUIRED`，提供标准化确认提示语句；
- **第二阶段（用户授权）**：DSH 宿主弹出授权对话框，用户确认后前端调度 `solidworks_confirm` 工具，传入严格匹配的参数对象，系统签发单次有效、带有时效（TTL）和参数指纹（Digest）的 Grant；
- **第三阶段（授权穿透与执行）**：携带该指纹再次调用目标工具，Policy 校验 Grant 成功后将其即刻销毁（防止重放攻击），FastMCP 调度 SolidWorks 核心成功完成实体物理写入并返回物证路径。

---

## 三、普通用户视角体验与产品可用性评估

针对普通机械工程师或非专业 CAD 用户在 DSH 桌面端使用本插件的体验分析如下：

| 用户体验维度 | 传统 CAD 插件痛点 | dsh-solidworks 解决方案与实测表现 | 用户体验定级 |
| :--- | :--- | :--- | :--- |
| **安装与环境配置** | 需要用户手动配置 Python 环境、安装 COM 依赖、注册 DLL，极易配置失败。 | **开箱即用，自动发现**：内置自愈探测机制，按虚拟环境 -> 环境变量 -> 候选目录依次寻找可用 Python，启动失败时通过 `solidworks_status` 输出自愈排查指导。 | **优秀 (Level 5)** |
| **操作安全性与误触防范** | 智能体直接操作用户已有 CAD 文件，极易误删特征、篡改原尺寸、导致装配体崩溃。 | **强制只读保护与单次确认**：白名单零件硬拦截，写操作受控在沙箱内；对破坏性操作必须由用户在前端点击授权，完全符合企业级安全规范。 | **极佳 (Level 5)** |
| **指令容错与故障自愈** | 建模遇到几何干涉或草图欠定义报错时，SolidWorks 弹出阻塞弹窗甚至崩溃挂起。 | **三级逆序物理回滚**：遇到非法参数自适应拦截，发生几何求解失败时毫秒级自动回滚到初始无污染状态，模型不留碎片特征。 | **工业级 (Level 6)** |
| **成果可视化与闭环交付** | 仅返回冰冷的代码或日志，用户无法直观确认三维零件和工程图是否符合预期。 | **多维成果直观呈现**：除生成 `.SLDPRT` / `.SLDDRW` 实体外，同步生成可直接预览的高清矢量 PDF，并附带 MQI 独立质量评分卡片与体积公差比对数据。 | **卓越 (Level 5)** |

### 结论
当前 `dsh-solidworks` 插件不仅在底层架构上实现了坚如磐石的物理稳定性和严格的工程规范，而且在 DSH 桌面宿主交互中形成了完整的安全拦截、确认授权与直观结果反馈闭环，完全达到直接面向普通用户发布与交付的工业级产品标准。
