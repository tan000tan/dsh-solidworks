# 极限工程攻关文件变更账本 (File Change Ledger)

## 一、变更概述
本账本记录在执行最高优先级指令《极限工程标准、建模实验与 DSH 插件最终交付要求》过程中涉及的所有核心文件修改、新增模块及其影响范围。

---

## 二、详细变更清单

| 序号 | 变更文件相对路径 | 变更类型 | 关键内容与改动说明 | 影响范围与质量保障 |
| :---: | :--- | :---: | :--- | :--- |
| 1 | `lib/policy.js` | 修改 | 1. 补齐 5 个高级参数化工具分类至 `RISK_TABLE`（总工具数升至 71 项）；<br>2. 新增 `PROTECTED_FILENAMES` 规则硬拦截对受保护白名单零件的任何写操作（返回 `PROTECTED_FILE_REFUSED`）。 | 解决 RSK-01 工具注册清单漂移与 RSK-05 白名单零件安全拦截缺陷。 |
| 2 | `dsh-plugin.json` | 修改 | 在插件清单配置文件的 `tools` 字段中同步补充 5 个高级参数化工具定义，保持清单与服务端 100% 同构。 | 消除 DSH 宿主静态清单与动态工具集漂移。 |
| 3 | `tests/package.test.js` | 修改 | 更新工具分级数量断言为 `{ read: 19, write: 26, high: 26 }`，同步工具注册与分类验证。 | 保持全套单测契约 100% 绿色通过。 |
| 4 | `docs/verification.md` | 修改 | 更新文档中关于工具数量与各风险等级的统计数据说明。 | 保证用户手册与实际代码零偏差。 |
| 5 | `vendor/.../scripts/cad_graph_executor.py` | 修改 | 在圆角（Fillet）与倒角（Chamfer）执行分支中增加对返回 `IFeature` 对象的判空校验与 `GetErrorCode2` 错误码校验。 | 彻底解决 RSK-03 特征执行器静默失败缺陷。 |
| 6 | `vendor/.../scripts/model_quality_inspector.py` | 修改 | 1. 引入 `DesignIntentTarget` 数据模型与 `verify_design_intent()` 独立设计意图交叉校验器；<br>2. 支持实体数、体积容差、表面积容差、包围盒跨度及特征树必选特征的反向对抗核验；<br>3. 修复 Pydantic 2.x `model_dump()` 兼容性。 | 建立彻底解耦的双通道独立模型质量审查体系。 |
| 7 | `tests/model_quality_inspector_test.py` | 新增 | 编写 6 项针对 MQI 独立检查器的反向对抗测试（空实体拦截、超差拦截、欠定义拦截等）。 | 6/6 单测全绿，证明独立检查器不可被作弊或绕过。 |
| 8 | `tests/real_cad/extreme_engineering_suite.py` | 新增 | 编写高难度极限工程实机验证套件，覆盖多段精密阶梯轴（旋转/端面拉伸、键槽、越程槽）、对称法兰箱体（防曲面脱开、筋板熔合）、参数化边界三级物理回滚及 2D 工程图离线重新打开闭环。 | 真实 SolidWorks 实机物理全 PASS，产出全量物证。 |
| 9 | `tests/real_cad/dsh_end_to_end_test.mjs` | 新增 | 编写针对真实 DSH 桌面宿主环境的端到端调用链核验套件，涵盖插件装载、RSK-05 保护、越界拦截、单次确认 Grant 签发与真实 CAD 落盘。 | 验证产品化 L4-L5 级全调用链顺畅可用。 |
| 10 | `docs/extreme_engineering/` | 新增 | 产出终审报告、端到端核验报告、变更账本及物证哈希清单。 | 形成交付物闭环。 |

---

## 三、构建与契约回归说明
所有修改均经过严格回归核验：
- 运行 `npm.cmd test`：**全套 68 项单测 100% PASS**（包含 `policy.test.js` 27 项、`mcp.test.js` 13 项、`schema.test.js` 16 项、`package.test.js` 12 项）；
- 严防路径泄漏：构建机物理绝对路径未向任何文档、测试用例或代码注释扩散，脱敏检查全部通过；
- 构建物清理：所有 `__pycache__` 目录与 `.pyc` 编译临时文件已被全面清理，无构建残留。
