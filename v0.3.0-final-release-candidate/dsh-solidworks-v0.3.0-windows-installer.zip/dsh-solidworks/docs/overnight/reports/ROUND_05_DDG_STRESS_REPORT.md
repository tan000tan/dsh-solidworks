# 第五轮参数依赖图 (DDG) 与长程高压修改验收报告 (ROUND_05_DDG_STRESS_REPORT.md)

**报告编号**：REPORT-ROUND-05  
**对应门禁**：Gate-05 (TASK-07)  
**验收时间**：2026-11-05 01:57  
**验收状态**：**PASS**  
**责任角色**：参数化架构工程师 & 质量保证工程师  

---

## 一、研发与验证目标

在 Gate-02（三轮机械修改）与 Gate-04（高级特征突破）的基础上，解决长程连续设计迭代中的参数耦合与稳定性问题：
1. **参数依赖图 (DDG)**：
   - 建立特征拓扑 (Feature Graph) 与尺寸参数 (Dimension IR) 之间的多对多映射；
   - 识别驱动尺寸与从动几何，支持无环检测与偏序拓扑排序；
   - 变更影响域分析 (Impact Scope)：精准推演单尺寸变更波及的下游特征与尺寸集合。
2. **20 轮真实环境长程连续修改高压测试**：
   - 在真实工业级电机安装支架物理模型上，连续执行 20 轮跨特征尺寸驱动修改；
   - 严苛实现两项零容忍底线：
     a. **零意外漂移 (Zero Drift)**：所有未被指定修改的非目标物理尺寸，绝对偏差必须 $\le 0.005\text{ mm}$；
     b. **双重几何校验**：每一轮物理保存落盘后，通过 SolidWorks COM 读取质量属性实测体积，必须与独立解析几何理论公式绝对吻合（误差 $< 1.0\text{ mm}^3$）。

---

## 二、架构演进与关键修复

### 1. 新增 DDG 核心模块
新建 `vendor/solidworks-automation-skill/scripts/dimension_dependency_graph.py`：
- `DimensionDependencyGraph` 类：
  - 基于 Kahn 算法的有向无环图拓扑排序；
  - 基于 DFS 回溯路径染色的循环依赖检测 (`detect_cycles`)；
  - 基于 BFS 传递闭包的下游影响域推导 (`get_impact_scope`)；
  - 动态变更影响分析器 (`analyze_modification_impact`)；
  - 零漂移比对核验器 (`verify_zero_drift`)。

### 2. COM 尺寸别名幽灵注册根治 (Defect Fix)
在实机压力测试首轮暴露了一处底层 COM 特征吸收草图时的属性重叠问题：
- **根因**：SolidWorks 特征（如 `BaseBoss`）会向 COM 暴露其吸收草图的 DisplayDimension。此前直接采用所属顶层特征名生成全限定名（`D2@BaseBoss`），而该尺寸本质是 `D2@BaseSketch`。当修改 `D2@BaseSketch` 时，`D2@BaseBoss` 同步变化，导致零漂移检查器判定为非目标尺寸漂移。
- **修复方案**：重构 `dimension_reader.py`，从 COM `dim.FullName` 严格截取第二段真身规范特征名称（`parts[1]`）。模型中重复的特征别名被天然合一，模型从 14 个虚假尺寸精准归一为 11 个物理真实约束。

---

## 三、真实实机实测结果

测试脚本：`tests/real_cad/real_cad_ddg_stress_test.py --authorize-cad-write`
测试平台：SolidWorks 2026 SP4.1 (PID: 26516), Python 3.13 COM STA

### 1. 连续 20 轮执行指标
- **总轮次**：20 轮
- **成功率**：**100% (20 / 20)**
- **零漂移违反数**：**0 项**
- **最大几何体积偏差**：**0.0000 mm³**（全 20 轮均精确与理论公式吻合）
- **性能统计**：
  - P50 延迟：**2159.7 ms**
  - P90 延迟：**2332.6 ms**
  - P99 延迟：**2339.5 ms**
  - 平均单轮耗时：**2156.1 ms**

---

## 四、结论与下一步规划

第五轮 DDG 与长程高压参数化验证圆满收官，系统证明了其在长期长程复杂迭代中的数学与工程可靠性。
下一步调度：**Round-06 (TASK-08 / GATE_06)** —— 执行引擎高可用与故障注入强化（STA Worker 线程模型、COM 异常拦截与状态机全生命周期自愈）。
