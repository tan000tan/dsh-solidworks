# Round-02 真实机械零件建模与三轮参数化修改闭环报告

**执行时间**：2026-11-05 01:30  
**执行角色**：CAD 建模工程师 / 几何核验工程师  
**所属门禁**：GATE_02 (**PASS**)  
**对应任务**：`TASK-02`（复杂机械零件实机建模） & `TASK-03`（多参数三轮连续修改与独立交叉核验）

---

## 1. 任务背景与核心目标

在完成 P1.1 基础草图尺寸与孔位修改的基础上，Round-02 针对工程实用场景，全面验证复杂组合零件在真实 SolidWorks 环境下的构建稳健性，以及连续多轮、跨特征、跨草图的参数化驱动能力。

本轮严格遵守“不可自行唯一审计”的原则，引入解析几何体积公式作为独立于 SolidWorks COM 计算之外的客观反向度量。

---

## 2. 交付成果清单

1. **测试脚本套件**：
   - `tests/real_cad/real_cad_mechanical_parts_test.py`
   - 集成 Model A、Model B、Model C 三类物理模型建模、静默落盘、物理重新加载及解析理论体积校验逻辑。
2. **沙箱物理生成物**：
   - `tests/real_cad/sandbox/motor_bracket_20261105_012834_576445.SLDPRT`
   - `tests/real_cad/sandbox/bearing_pillow_block_20261105_012847_021020.SLDPRT`
   - `tests/real_cad/sandbox/multibranch_connector_20261105_012853_699425.SLDPRT`
3. **门禁报告**：
   - `docs/overnight/gates/GATE_02.md`

---

## 3. 关键工程发现与缺陷修复（强制返工记录）

在本轮自主实机执行过程中，共发现并解决 3 项深层工程问题：

### 发现 1：坐标系映射与包围盒轴向混淆
- **现象**：Top Plane 为 SolidWorks 中的 X-Z 平面（法向为 Y 轴向），拉伸实体厚度向 Y 方向延伸，底座矩形宽度实际对应 Z 轴，而垂直板绘制在 Front Plane（X-Y 平面），其高度对应 Y 轴。
- **问题**：初版断言将 Z 轴与 Y 轴混淆，导致宽度断言误读 Y 轴高度。
- **修复**：严格按坐标系定义，将底座宽度映射为 `size_mm[2]`，总高度映射为 `size_mm[1]`，彻底消除轴向错位。

### 发现 2：草图几何独立驱动尺寸标注
- **现象**：双孔特征中，初版使用几何约束 `sgEQUAL`，但由于 COM 调用层级差异，在未触发完整约束重算时，孔 2 未随孔 1 直径联动修改，导致理论体积与实测体积产生 $612.61\text{ mm}^3$ 的微小偏差。
- **解决**：为孔 1 和孔 2 分别建立独立的 DisplayDimension 驱动尺寸（`D2@MountHolesSketch` 与 `D3@MountHolesSketch`），参数修改器对两孔施加原子修改，最终实现体积误差 $0.0000\text{ mm}^3$ 完美匹配。

### 发现 3：静默打开参数防止自动化挂死
- **现象**：在多轮打开已落盘物理模型时，缺少 `silent=True` 可能触发 SolidWorks 重建或只读提示窗，阻塞无人值守流水线。
- **规范**：全面统一使用 `open_document(sw, path, silent=True)`。

---

## 4. 下一步任务准入判定

GATE_02 已经全项通过（ALL PASS），满足准入条件：
- `TASK-02`: **DONE**
- `TASK-03`: **DONE**
- 准备调度进入 **Round-03：Agent 自主规划与设计意图转译（CADTaskPlanner / DesignIntent -> Feature Graph IR）**。
