# 第六轮执行引擎可靠性与故障注入验收报告 (ROUND_06_ENGINE_RELIABILITY_REPORT.md)

**报告编号**：REPORT-ROUND-06  
**对应门禁**：Gate-06 (TASK-08)  
**验收时间**：2026-11-05 08:50  
**验收状态**：**PASS**  
**责任角色**：引擎稳定性专家 & CAD 架构工程师  

---

## 一、研发与验证目标

在 Gate-05 突破长程 20 轮连续参数化修改的基础上，针对工业环境中常见的死锁、COM 挂起、几何求解崩溃、句柄泄露及误伤用户资产等极端场景，实施全面的可靠性加固与故障注入验证：
1. **STA Worker 单线程单元模型加固**：
   - 彻底解决死锁与超时挂起，支持动态重启与纯净上下文重置；
   - 保证异常跨线程传递时类型与堆栈保真；
   - 支持同线程递归嵌套调用防自死锁。
2. **CADGraphExecutor 事务原子性与级联隔离**：
   - 特征图中段注入异常几何时，原子性回滚已生成的脏特征与未提交文档；
   - 验证宿主 SolidWorks 进程内文档列表在故障发生后 100% 守恒，实现“零文档污染”；
   - 验证下游从动特征的级联跳过（Cascade Skip）逻辑。
3. **高频文档句柄生命周期压测**：
   - 验证连续 10 轮高频文档创建、落盘、开盖读取、测量、关闭，无 COM 句柄泄漏。

---

## 二、架构演进与关键修复

### 1. `DesktopPinnedStaWorker` 锁模型重构
- **缺陷**：原实现使用 `threading.Lock()` 作为生命周期锁。当外部调用 `worker.restart()` 时，外层持锁后内部再次进入 `worker.start()`，触发不可恢复的死锁。
- **修复**：将 `_lifecycle_lock` 升级为 `threading.RLock()`，完善了 `is_healthy()` 探活与超时后任务状态标记为 `TIMED_OUT` 的丢弃机制。

### 2. 生产级 `close_document` 接口落地
- **背景**：此前部分测试直接调用 COM `get_com_member(sw, "CloseDoc", ...)`，当标题因异步延迟或空指针变为 `""` 时，SolidWorks 原生 API 会自动关闭当前活动的文档。
- **修复**：在 `vendor/solidworks-automation-skill/scripts/sw_connect.py` 中封装 `close_document(sw, doc_or_title)` 接口，严格校验标题有效性，并硬编码保护用户白名单文档，杜绝一切误关非测试资产的风险。

---

## 三、测试与验证数据

### 1. 单元测试 (`tests/engine_reliability_test.py`)
- 测试项数：5 / 5 项通过
- 耗时：0.512s
- 涵盖场景：线程隔离度检查、超时熔断与非阻塞恢复、Worker 重启与探活、异常保真穿透、同线程重入安全。

### 2. 实机故障注入测试 (`tests/real_cad/real_cad_fault_injection_test.py`)
- **用例 1（中途建模故障事务回滚）**：
  - 注入条件：在有效底板后注入非法基准面草图节点 `NonExistentPlane_FaultInjection_999`
  - 执行结果：`success=False`, `rollback_status=SUCCESS`, `rollback_occurred=True`
  - 文档守恒性：执行前后 SolidWorks 文档列表恒为 `['垫圈.SLDPRT', '螺母 GB_T 6170 M10.SLDPRT']`，无孤儿文档残留。
- **用例 2（故障依赖级联跳过）**：
  - 执行结果：上游故障草图状态为 `FAILED`，下游拉伸特征状态为 `SKIPPED`，未引发级联崩溃。
- **用例 3（10 轮高频文档生命周期压测）**：
  - 10 轮循环完整经历：新建 -> 建模 -> 保存 -> 关闭 -> 重开 -> 测量 -> 关闭
  - 10 轮物理体积测量值恒为 $12,500.0\text{ mm}^3$（与理论完全一致）
  - 最终打开文档列表与基线严格一致，未产生任何句柄泄漏。

---

## 四、结论与下一步规划

第六轮执行引擎可靠性与故障注入强化全面通过，系统在底层并发模型与异常容错方面达到生产级健壮性。
下一步调度：**Round-07 (TASK-09 / GATE_07)** —— 模型质量智能核查器 (MQI) 与 2D 工程图 (Drawing) 自动化创建全流程闭环。
