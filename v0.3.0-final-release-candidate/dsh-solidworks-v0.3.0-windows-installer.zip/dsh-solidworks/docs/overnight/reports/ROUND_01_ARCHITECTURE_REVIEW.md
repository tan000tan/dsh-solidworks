# Round-01 架构与能力基线审查报告 (ROUND_01_ARCHITECTURE_REVIEW.md)

**审查时间**：2026-11-05 01:07  
**审查范围**：`dsh-solidworks` 完整调用链、COM/STA 调度、尺寸参数化架构、工程图子系统与 MCP 注册现状。

---

## 一、系统端到端真实调用链穿透分析

```mermaid
flowchart TD
    User([用户自然语言设计/修改需求]) --> DSH[DSH Agent / MCP Client]
    DSH -->|JSON-RPC 2.0| NodePlugin[lib/index.js / Policy Gate 门禁]
    NodePlugin -->|Stdio 隔离调用| PythonServer[vendor/.../mcp-server/server.py]
    
    subgraph Execution_Engine [执行与规划核心]
        PythonServer -->|工具派发| TaskDispatcher{MCP 工具分发}
        TaskDispatcher -->|solidworks_execute_feature_graph| FGExec[scripts/cad_graph_executor.py]
        TaskDispatcher -->|solidworks_identify_dimensions| DimReader[scripts/dimension_reader.py]
        TaskDispatcher -->|solidworks_modify_dimension_safe| DimMod[scripts/dimension_modifier.py]
        FGExec -->|DAG拓扑排序与校验| FG_IR[scripts/feature_graph_ir.py]
        FGExec -->|任务上下文与生命周期| TaskCtx[scripts/cad_task_context.py]
    end

    subgraph STA_COM_Apartment [Windows STA COM 调度中心]
        FGExec -->|STA 任务排队| STAWorker[scripts/sw_connect.py:get_sta_worker]
        DimMod -->|STA 任务排队| STAWorker
        STAWorker -->|串行调度与异常捕获| COMBridge[SolidWorks API / SldWorks.Application]
    end

    subgraph SolidWorks_Host [SolidWorks 2026 SP4.1 宿主]
        COMBridge -->|草图/特征建立| SWPart[scripts/sw_part.py]
        COMBridge -->|参数读写/配置管理| SWData[scripts/sw_document_data.py]
        COMBridge -->|强制重构| Rebuilder[scripts/model_rebuilder.py]
        COMBridge -->|质量属性/包围盒/干涉| SWMeasure[scripts/sw_measure.py]
    end

    subgraph Verification_ClosedLoop [几何与事务自愈闭环]
        SWMeasure -->|物理属性实测| GeoVerifier[tests/real_cad/geometry_verifier.py]
        Rebuilder -->|健康诊断报告| DimValidator[scripts/dimension_validator.py]
        DimValidator -->|几何异常触发逆向还原| DimMod
        GeoVerifier -->|拓扑破损触发实体逆向销毁| TaskCtx
    end

    GeoVerifier --> ResultPacker[返回标准可审计 JSON 证据]
    ResultPacker --> DSH
```

### 1.1 关键环节真实代码位置对照表

| 环节 | 职责与功能 | 真实源文件与核心符号 |
| :--- | :--- | :--- |
| **1. 协议接入与门禁** | Policy 风险判定、Path 穿越防御、Grant 凭证校验 | [lib/index.js](file:///<REPO_ROOT>/DeepSeek%20Harness工作区/dsh-solidworks-plugin/lib/index.js), [lib/policy.js](file:///<REPO_ROOT>/DeepSeek%20Harness工作区/dsh-solidworks-plugin/lib/policy.js) |
| **2. MCP 服务端** | FastMCP 工具注册、参数校验、异常包装 | [mcp-server/server.py](file:///<REPO_ROOT>/DeepSeek%20Harness工作区/dsh-solidworks-plugin/vendor/solidworks-automation-skill/mcp-server/server.py) |
| **3. 特征图编译与执行** | DAG 排序、多父节点依赖、长链特征执行 | [scripts/cad_graph_executor.py](file:///<REPO_ROOT>/DeepSeek%20Harness工作区/dsh-solidworks-plugin/vendor/solidworks-automation-skill/scripts/cad_graph_executor.py) |
| **4. 任务上下文与回滚** | 文档隔离、特征跟踪、中段失败特征树逆向删除 | [scripts/cad_task_context.py](file:///<REPO_ROOT>/DeepSeek%20Harness工作区/dsh-solidworks-plugin/vendor/solidworks-automation-skill/scripts/cad_task_context.py) |
| **5. COM 与 STA 调度** | 跨桌面检测、单线程单元（STA）Worker 队列、安全成员访问 | [scripts/sw_connect.py:get_sta_worker](file:///<REPO_ROOT>/DeepSeek%20Harness工作区/dsh-solidworks-plugin/vendor/solidworks-automation-skill/scripts/sw_connect.py) |
| **6. 尺寸参数全景提取** | 递归子特征、DisplayDimension 枚举、语义推断 | [scripts/dimension_reader.py](file:///<REPO_ROOT>/DeepSeek%20Harness工作区/dsh-solidworks-plugin/vendor/solidworks-automation-skill/scripts/dimension_reader.py) |
| **7. 尺寸修改与事务恢复** | 原位 SetSystemValue3、参数快照、多级自愈回滚 | [scripts/dimension_modifier.py](file:///<REPO_ROOT>/DeepSeek%20Harness工作区/dsh-solidworks-plugin/vendor/solidworks-automation-skill/scripts/dimension_modifier.py) |
| **8. 重建与物理健康核查** | EditRebuild3/ForceRebuild3、实体计数、包围盒与体积比较 | [scripts/model_rebuilder.py](file:///<REPO_ROOT>/DeepSeek%20Harness工作区/dsh-solidworks-plugin/vendor/solidworks-automation-skill/scripts/model_rebuilder.py), [scripts/dimension_validator.py](file:///<REPO_ROOT>/DeepSeek%20Harness工作区/dsh-solidworks-plugin/vendor/solidworks-automation-skill/scripts/dimension_validator.py) |
| **9. 几何交叉核验** | 理论解析几何公式与物理实测交叉比对 | [tests/real_cad/geometry_verifier.py](file:///<REPO_ROOT>/DeepSeek%20Harness工作区/dsh-solidworks-plugin/tests/real_cad/geometry_verifier.py) |

---

## 二、真实模块清单与能力现状矩阵

| 模块名称 | 物理路径 | CODE | MOCK | PYTHON | MCP | REAL_CAD | 现状与能力评级 |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: | :--- |
| **FeatureGraphIR** | `scripts/feature_graph_ir.py` | PASS | PASS | PASS | PASS | PASS | 结构化 DAG，拓扑排序完备 |
| **CADGraphExecutor** | `scripts/cad_graph_executor.py` | PASS | PASS | PASS | PASS | PASS | 14节点、跨基准面、多分支汇聚实机验证通过 |
| **CADTaskRollback** | `scripts/cad_task_context.py` | PASS | PASS | PASS | PASS | PASS | 中段注入故障逆向销毁实体已实机验证 |
| **DimensionIR** | `scripts/dimension_ir.py` | PASS | PASS | PASS | PASS | PASS | 结构化参数模型，单位米/毫米精准转换 |
| **DimensionReader** | `scripts/dimension_reader.py` | PASS | PASS | PASS | PASS | PASS | 支持草图与特征 DisplayDimension 全量提取 |
| **DimensionResolver** | `scripts/dimension_resolver.py` | PASS | PASS | PASS | PASS | PASS | 自然语言歧义消除与目标特征绑定 |
| **DimensionModifier** | `scripts/dimension_modifier.py` | PASS | PASS | PASS | PASS | PASS | 原位修改，支持 SUCCESS / ROLLBACK_* 状态 |
| **ModelRebuilder** | `scripts/model_rebuilder.py` | PASS | PASS | PASS | PASS | PASS | 强制全量重解，实体丢失/破损拦截 |
| **DimensionValidator**| `scripts/dimension_validator.py` | PASS | PASS | PASS | PASS | PASS | 目标尺寸误差、非目标尺寸漂移监控 |
| **SW Drawing** | `subskills/.../drawing_workflow.py`| PASS | PASS | PASS | PARTIAL| PARTIAL | 基础视图投影就绪，缺少标准件实机闭环 |
| **Agent Planner** | *(待实现)* | - | - | - | - | - | 当前缺少自然语言到完整 Feature Graph 的自动生成器 |

---

## 三、识别出的核心技术债务与最高优先级缺陷

1. **【P0】尺寸系统实现未完全归一**：
   - 现象：`server.py` 中的 `solidworks_identify_dimensions` 和 `solidworks_modify_dimension_safe` 仍调用旧的 `scripts/dimension_manager.py`，而未完全直接绑定阶段三新构建的 `dimension_reader.py` 和 `dimension_modifier.py`。
   - 解决方案：在 `server.py` 中引入桥接，将高级 IR、自愈回滚状态（`ROLLBACK_SUCCESS` 等）及多参数验证报告无缝透传给 MCP 返回值。
2. **【P1】草图自动参数化驱动能力需内嵌至 FeatureGraphIR 执行管线**：
   - 现象：在草图执行中，如果不显式建立定位构造线或标注，草图尺寸在生成后无法原位驱动。
   - 解决方案：在 `cad_graph_executor.py` 的草图生成器中内嵌自动构造线约束与显式标注参数，使 Feature Graph 创建的零件天然具备 100% 参数化驱动修改能力。
3. **【P2】缺少从自然语言意图直接转译为合法 Feature Graph 的规划器 (Agent Planner)**：
   - 现象：目前特征图多为测试脚本手工构造，缺乏用户需求到参数化依赖树的结构化转译器。
   - 解决方案：在 Round-03 中构建 `cad_task_planner.py` 与 `design_intent.py`。

---

## 四、下一阶段实施路线规划

- **Round-02 (P1)**：真实机械零件实机建模与三轮连续参数化修改（电机安装支架、轴承座、多分支连接件），实施独立几何交叉比对。
- **Round-03 (P2)**：实现 Agent 自主规划器（`cad_task_planner.py`），验证从自然语言输入到生成 Feature Graph 并调用 SolidWorks 建模的完整闭环。
- **Round-04 (P3)**：突破旋转凸台、线性/圆周阵列等高级特征能力，并在真实实机环境中验证。
