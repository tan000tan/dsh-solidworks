# dsh-solidworks NIGHT-ENGINEERING-02 项目基线记录 (BASELINE.md)

**创建时间**：2026-11-05 01:04:40  
**工作区根目录**：`<HOST_PATH>\DeepSeek Harness工作区\dsh-solidworks-plugin`  
**Git HEAD Commit**：`7d70bc0e9fc78c71d2b826ce5a5be434f41444bf` (v0.2.0 Tag)  
**当前环境**：
- 操作系统：Windows 11 (AMD64)
- Python 解释器：`<HOST_PATH>\Python313\python.exe` (v3.13.16)
- Node.js 版本：v22.14.0
- SolidWorks 实例：SolidWorks 2026 SP4.1 (PID: 26516, Rev: 34.4.1)
- 启动时 SolidWorks 文档数：0（无任何未保护文档泄漏）

## 1. 保护边界资产概况
- **受保护历史成果文件数**：267 个文件（涵盖 vendor 脚本、测试套件、沙箱历史模型、架构文档与合规元数据）
- **哈希指纹存储位置**：`docs/overnight/baseline/protected_files.json`
- **初始未提交修改范围**：
  - `NOTICE` (文件数更新为 186)
  - `lib/discover.js`, `lib/index.js`, `tests/mcp.test.js`, `tests/probe-server.mjs`
  - `vendor/solidworks-automation-skill/mcp-server/server.py`
  - `vendor/solidworks-automation-skill/scripts/cad_task_context.py`
  - `vendor/solidworks-automation-skill/scripts/cad_graph_executor.py`
  - `vendor/solidworks-automation-skill/scripts/dimension_*.py` (6个模块)
  - `tests/cad_graph_executor_test.py`, `tests/dimension_system_test.py`, `tests/real_cad/`

## 2. 初始基线测试状态
- Node.js 集成测试：**68/68 PASS**
- Python 尺寸系统离线单元测试：**12/12 PASS**
- Python 特征图执行器离线单元测试：**21/21 PASS**
- MCP 协议与服务探针：**71 个工具全部探测发现并分类**
- 实机端到端历史状态：P0.4（14节点法兰、跨面支架、轴承座、中段回滚）与 P1.1（测试 A~G）已全绿

## 3. 运行准则
1. 开发者不能成为自己唯一的验收者：每一轮任务必须提供独立反例与断言。
2. 绝对禁止 `git reset`、`git clean` 与未经授权的 commit/push。
3. 绝对禁止操作用户已有文档，所有 CAD 测试严格局限在沙箱与分配的独立 Document ID 中。
