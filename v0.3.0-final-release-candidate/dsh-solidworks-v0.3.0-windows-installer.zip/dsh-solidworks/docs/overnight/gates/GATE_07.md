# Gate-07 模型质量智能核查器 (MQI) 与 2D 工程图自动化出图门禁报告 (GATE_07.md)

**验收时间**：2026-11-05 14:50  
**验收判定**：**PASS**  
**测试平台**：SolidWorks 2026 SP4.1 (PID: 26516, Rev: 34.4.1), Python 3.13.16 COM STA  
**执行脚本**：`tests/real_cad/real_cad_drawing_mqi_test.py --authorize-cad-write` (**3/3 ALL PASS**)  

---

## 1. 门禁验收概览

| 序号 | 验证模块 / 场景 | 核心验证能力 | 判定 | 依据与核心指标 |
| :---: | :--- | :--- | :---: | :--- |
| **1** | **工业零件 MQI 深度审查**<br>`Model Quality Inspector` | 实体数、特征树健康度、草图约束状态与可制造性判定 | **PASS** | 电机支架得分 **91.0 / 100.0 (Grade A)**，实体有效，无报错特征，判定可制造 |
| **2** | **缺陷反例严格扣分与拦截**<br>`Defective Part Rejection` | 零体积、欠定义无标注草图自动识别与扣分熔断 | **PASS** | 缺陷模型得分 **42.0 (Grade F)**，判定不可制造 (`is_manufacturable=False`) |
| **3** | **2D 工程图自动出图闭环**<br>`Automated 2D Drawing` | 新建工程图、自适应标准三视图、等轴测图、模型尺寸导入 | **PASS** | 自动生成 `.SLDDRW` (107,889 字节)，3个标准视图完整，自动导入 14 个真实模型尺寸 |
| **4** | **全生命周期文档守恒**<br>`Document Zero Pollution` | 出图与审查过程中宿主会话文档零污染 | **PASS** | 执行前后 SolidWorks 打开文档恒等于 `['垫圈.SLDPRT', '螺母 GB_T 6170 M10.SLDPRT']` |

---

## 2. 核心实测数据

### 用例 1：高品质工业电机支架 MQI 审查
- **被测物理零件**：`<REPO_ROOT>/tests/real_cad/sandbox/ddg_stress_bracket_*.SLDPRT`
- **综合得分**：**91.0 / 100.0**（质量等级：**Grade A**）
- **核心指标**：
  - 实体数量：2（底座与立柱实体，可制造）
  - 报错特征数：0，警告特征数：0
  - 草图定义状态：主基准草图完全定义，从动草图关键尺寸完备
  - 驱动尺寸总数：11 项
  - 实测物理体积：$475,302.21\text{ mm}^3$
- **可制造性裁定**：`is_manufacturable = True`（达到数控与工程出图交付标准）

### 用例 2：缺陷反例模型审查与熔断拦截
- **被测模型**：未拉伸实体、仅包含浮动无约束草图的残缺模型
- **综合得分**：**42.0 / 100.0**（质量等级：**Grade F**）
- **拦截扣分项**：
  - `[geometry]` 扣除 40.0 分：实测体积为 0
  - `[sketch_constraint]` 扣除 8.0 分：严重欠定义且无尺寸标注
  - `[dimension]` 扣除 10.0 分：缺少参数化驱动尺寸
- **可制造性裁定**：`is_manufacturable = False`（准确拦截残缺设计）

### 用例 3：2D 工程图自动化出图与物理落盘
- **工程图落盘文件**：`<REPO_ROOT>/tests/real_cad/sandbox/motor_bracket_drawing_*.SLDDRW`
- **落盘物理大小**：**107,889 字节**
- **工程图图幅**：GB/T 标准图框
- **视图与尺寸结构**：
  - 主视图 (Front View)、俯视图 (Top View)、右视图 (Right View)
  - 自动导入模型尺寸数：**14 个真实尺寸标注**
  - 视图边界检测：`drawing-view-outlines: pass`（全部视图边界解析无碰撞）
- **会话文档状态**：出图完成后安全关闭临时文件，用户白名单文档严格守恒。

---

## 3. 架构重大突破

1. **SolidWorks COM 草图约束常量校准**：
   - 实机逆向发现 SolidWorks COM 底层 `swSketchConstrainedStatus_e` 规范：`status=3` 为完全约束 (`FullyConstrained`)，`status=2` 为欠定义 (`UnderConstrained`)，`status=4` 为过定义 (`OverConstrained`)。
   - 严格过滤非草图特征（如 `OriginProfileFeature` 坐标原点），彻底避免系统坐标误当草图扣分的缺陷。
2. **工程图模型会话激活机制**：
   - 查明 SolidWorks COM 生成投影视图的核心先决条件：调用 `Create3rdAngleViews2` 或添加视图时，源零件模型必须处于当前会话加载状态。通过前置静默加载并在落盘后安全关闭，实现了 100% 稳定的全自动出图流水线。

---

## 4. 门禁结论

GATE_07 正式通过。系统具备了从三维物理零件的几何健康智能核查 (MQI)、缺陷拦截、到全自动生成符合 GB/T 规范的 2D 工程图 (`.SLDDRW`) 及标注导入的全流程工业交付能力。
