# Gate-03 Agent 自主规划与设计意图转译门禁报告 (GATE_03.md)

**验收时间**：2026-11-05 01:42  
**验收判定**：**PASS**  
**测试平台**：SolidWorks 2026 SP4.1 (PID: 26516, Rev: 34.4.1), Python 3.13.16 COM STA  
**执行脚本**：
- 单元测试：`tests/cad_task_planner_test.py` (9/9 PASS)
- 实机全闭环测试：`tests/real_cad/real_cad_planner_test.py --authorize-cad-write` (ALL PASS)

---

## 1. 门禁验收概览

| 序号 | 验证模块 / 场景 | 核心验证能力 | 判定 | 依据与核心指标 |
| :---: | :--- | :--- | :---: | :--- |
| **1** | **意图语义解析**<br>`DesignIntent` | 自然语言提示词转译为结构化意图 | **PASS** | 支持长宽厚、中心通孔、阵列安装孔、垂直立柱自动抽取 |
| **2** | **反例几何拦截**<br>`Counter-example Rejection` | 孔位越界/非物理负数/切边破坏拦截 | **PASS** | 静态拦截 6 类反例，SolidWorks 打开文档数保持 2，零污染 |
| **3** | **拓扑编译器**<br>`Intent -> FeatureGraphIR` | 结构化意图降阶编译为带驱动尺寸的 DAG | **PASS** | 自动创建 DisplayDimension，草图与特征名称精确双向映射 |
| **4** | **自然语言建模实机实测**<br>`Autonomous Modeling` | 自然语言需求 -> 真实实体物理落盘 | **PASS** | 法兰板落盘 `autonomous_flange_*.SLDPRT`，体积误差 **0.0000 mm³** |
| **5** | **原位参数化再驱动**<br>`In-Place Parametric Update` | 规划器生成的模型支持无损尺寸再修改 | **PASS** | 底板 120->150mm，中心孔 25->32mm，修改后体积误差 **0.0000 mm³** |

---

## 2. 核心实测数据

### 用例 1：自然语言法兰板自主规划与建模
- **输入提示词**：`"创建一个长140mm、宽90mm、厚12mm的机械法兰板，中心开一个直径28mm的通孔"`
- **落盘物理文件**：`tests/real_cad/sandbox/autonomous_flange_20261105_014049_762462.SLDPRT`
- **理论公式解析体积**：$V = (140 \times 90 \times 12) - (\frac{\pi}{4} \times 28^2 \times 12) = 143,810.97\text{ mm}^3$
- **SolidWorks COM 实测体积**：$143,810.97\text{ mm}^3$
- **体积偏差**：**$0.0000\text{ mm}^3$**
- **包围盒实测**：$[140.0, 12.0, 90.0]\text{ mm}$

### 用例 2：反例严苛拦截与零 CAD 污染防护
- **输入反例提示词**：`"创建一个长50mm、宽50mm、厚5mm的薄板，中心开一个直径80mm的通孔"`
- **审查拦截行为**：`IntentValidationError: [OUT_OF_BOUNDS] 孔 [center_bore] 物理越界: 中心=(25.0, 25.0)mm, 直径=80.0mm 超出底板包围域 X:[0.0, 50.0], Y:[0.0, 50.0]`
- **SolidWorks 进程保护**：执行前后文档数恒为 2，未触发任何新建文档或沙箱写入。

### 用例 3：自主规划零件原位参数化再驱动
- **基线生成**：$120 \times 80 \times 15\text{ mm}$ 底板，中心开 $\Phi 25\text{ mm}$ 通孔
- **参数化修改**：
  - `D1@BaseSketch`: $120.0\text{ mm} \rightarrow 150.0\text{ mm}$
  - `D1@HoleSketch_1`: $25.0\text{ mm} \rightarrow 32.0\text{ mm}$
- **理论解析体积**：$V = (150 \times 80 \times 15) - (\frac{\pi}{4} \times 32^2 \times 15) = 167,936.28\text{ mm}^3$
- **修改后实测体积**：$167,936.28\text{ mm}^3$
- **体积偏差**：**$0.0000\text{ mm}^3$**
- **包围盒 X 延伸**：精准扩展至 $150.0\text{ mm}$

---

## 3. 门禁结论

GATE_03 正式通过。系统完成了从 Agent 意图理解、几何可行性审查、DAG 拓扑编译到真实物理执行与参数化再驱动的完整工程闭环。具备进入 Round-04 高级特征能力实机突破的充分条件。
