# Gate-06 执行引擎高可用与故障注入门禁报告 (GATE_06.md)

**验收时间**：2026-11-05 08:50  
**验收判定**：**PASS**  
**测试平台**：SolidWorks 2026 SP4.1 (PID: 26516, Rev: 34.4.1), Python 3.13.16 COM STA  
**执行脚本**：
- 单元测试：`tests/engine_reliability_test.py` (5/5 PASS, 耗时 0.512s)
- 实机故障注入测试：`tests/real_cad/real_cad_fault_injection_test.py --authorize-cad-write` (**3/3 ALL PASS**)

---

## 1. 门禁验收概览

| 序号 | 验证模块 / 场景 | 核心验证能力 | 判定 | 依据与核心指标 |
| :---: | :--- | :--- | :---: | :--- |
| **1** | **STA Worker 线程模型加固**<br>`Thread Isolation & Re-entrancy` | 单线程单元生命周期、重入安全、异常穿透与重启探活 | **PASS** | 引入 `threading.RLock` 消除嵌套死锁，5 项并发可靠性单元测试全绿 |
| **2** | **中途建模故障事务回滚**<br>`Mid-Pipeline Rollback` | 特征图中段注入非法基准面导致失败时自动回滚与文档清理 | **PASS** | `rollback_status=SUCCESS`, `rollback_occurred=True`，无残缺特征残留 |
| **3** | **零文档污染守恒保障**<br>`Zero Document Pollution` | 建模失败或异常终止后宿主会话文档状态完全守恒 | **PASS** | 执行前后打开文档严格守恒，用户工作文档零破坏、零关闭 |
| **4** | **故障依赖级联跳过隔离**<br>`Broken Dependency Cascade Skip` | 上游特征失败时下游特征自动跳过，阻断雪崩扩散 | **PASS** | 故障节点状态为 `FAILED`，下游从动特征安全置为 `SKIPPED` |
| **5** | **高频文档生命周期压测**<br>`Lifecycle & Leak Stress` | 连续 10 轮新建、建模、落盘、开盖、测量、关闭高频压测 | **PASS** | 10 轮几何体积恒为 12,500.0 mm³，最终打开文档与初始完全一致，零句柄泄露 |

---

## 2. 核心架构缺陷诊断与修复

1. **STA 线程生命周期自死锁消除**：
   - 原 `DesktopPinnedStaWorker` 采用非可重入锁 `threading.Lock()`，导致 `restart()` 内部调用 `start()` 时发生自死锁。
   - 重构为可重入锁 `threading.RLock()`，并规范化 `execute()` 内部对同线程递归调用的零开销直通转发。
2. **安全文档关闭接口与用户资产白名单防御**：
   - 新增 `sw_connect.close_document(sw, doc_or_title)`，对传入参数进行严密非空和类型校验，杜绝调用 COM `CloseDoc("")` 误关当前活动文档。
   - 建立白名单硬隔离机制，绝不关闭用户既有的工程文档（如 `垫圈.SLDPRT`、`螺母 GB_T 6170 M10.SLDPRT`）。

---

## 3. 门禁结论

GATE_06 正式通过。系统在单线程单元 (STA)、COM 异常拦截、事务回滚一致性、依赖故障隔离与多轮高频文档生命周期防泄漏方面均达到工业级可靠性标准。
