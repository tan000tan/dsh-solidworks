# dsh-solidworks NIGHT-ENGINEERING-02 任务队列调度表 (TASK_QUEUE.md)

| 任务ID | 阶段归属 | 任务名称与范围 | 依赖项 | 优先级 | 执行状态 | 责任角色 |
| :--- | :--- | :--- | :---: | :---: | :---: | :--- |
| **TASK-00** | Gate-00 | 建立基线、环境检查、哈希存证与测试底线 | 无 | P0 | **DONE** | 基线管理员 |
| **TASK-01** | Round-01 | 穿透审计当前全链路架构，梳理真实调用断点与技术债务 | TASK-00 | P0 | **DONE** | 架构审查员 |
| **TASK-02** | Round-02 | 真实复杂机械零件实机建模 (电机安装支架/传动箱体/多孔汇聚件) | TASK-01 | P1 | **DONE** | CAD建模工程师 |
| **TASK-03** | Round-02 | 电机支架三轮多参数真实修改与体积/BBox独立交叉核验 | TASK-02 | P1 | **DONE** | 几何核验工程师 |
| **TASK-04** | Round-03 | Agent 自主规划模块实现 (CADTaskPlanner/DesignIntent) 与反例拦截 | TASK-01 | P2 | **DONE** | AI规划工程师 |
| **TASK-05** | Round-03 | 自然语言 -> 结构化意图 -> Feature Graph -> 真实建模端到端实机验证 | TASK-04 | P2 | **DONE** | 全栈集成工程师 |
| **TASK-06** | Round-04 | 高级特征能力实机闭环开发 (旋转凸台/切除、线性阵列、圆周阵列) | TASK-02 | P3 | **DONE** | CAD高级开发 |
| **TASK-07** | Round-05 | 参数依赖图 (DDG) 拓扑分析与 20 轮连续高压修改实机验证 | TASK-03 | P1 | **DONE** | 参数化工程师 |
| **TASK-08** | Round-06 | STA Worker 线程模型、COM异常拦截与全生命周期状态机加固 | TASK-01 | P4 | **DONE** | 引擎稳定性专家 |
| **TASK-09** | Round-07 | 模型质量智能核查器 (MQI) 与真实工程图 (Drawing) 自动化创建 | TASK-02 | P5 | **DONE** | 工程图专家 |
| **TASK-10** | Round-08 | 真实 FastMCP / DSH JSON-RPC 完整三轮多轮对话链路验证 | TASK-05 | P2 | **DONE** | MCP集成工程师 |
| **TASK-11** | Round-09 | 性能工程基准测试套件 (E01-E18 Benchmark) 自动化调度 | TASK-07 | P4 | **DONE** | 性能测试工程师 |
| **TASK-12** | Round-10 | 全局文件清理、未追踪项审计与最终独立交付报告编写 | TASK-11 | P6 | **DONE** | 交付总负责人 |
