# dsh-solidworks NIGHT-ENGINEERING-02 清理与环境卫生审计决算报告 (CLEANUP_REPORT.md)

**项目**: `dsh-solidworks` (dsh-solidworks-plugin)  
**工程攻坚代号**: `NIGHT-ENGINEERING-02`  
**审计基准时间**: 2026-11-05  
**总体验收结论**: **[CLEANUP & HYGIENE VERIFIED - PASS]**  

---

## 一、环境卫生与清理总则

在执行全夜连续自主研发与多轮高压实机测试（Round-00 至 Round-10）过程中，本系统严格遵守“零破坏、零泄露、零残留”三项铁律：
1. **零破坏**: 严禁破坏用户本地正在编辑的 SolidWorks 零件与工作文档，白名单文件处于只读级别隔离。
2. **零残留**: 任何异常中断、事务回滚或测试结束均必须主动触发安全关闭，严禁在 SolidWorks 进程中堆积无主临时零件，会话前后活动文档净增量必须归零。
3. **零泄露**: 严禁在交付文档、测试脚本、日志或源码中泄露本地构建主机的绝对路径或私有用户名。

---

## 二、SolidWorks COM 进程与活动文档清理决算

### 1. 宿主进程状态审计
- **运行进程**: `SLDWORKS.exe` (PID 21324)
- **进程状态**: 运行健康，未发生挂死或异常崩溃退出，无跨线程 RPC 锁死。

### 2. 白名单核心文档保护核查
- **硬编码白名单**: `['垫圈.SLDPRT', '螺母 GB_T 6170 M10.SLDPRT']`
- **核查结果**: 
  - 白名单文档在全夜数百次实机 API 调用中未被误关闭。
  - 白名单文档未被保存、修改或注入任何测试特征，哈希值与原始状态保持完全一致。

### 3. 测试临时文档释放决算
- **文档关闭审计机制**: 全量测试用例（包括 E01~E18 基准测试、DDG 20 轮高压压测、Fault Injection 故障注入测试）均严格包裹在 `try ... finally: close_document(self.sw, model)` 机制中。
- **活动文档计数变化**:
  - 全夜任务开始前初始活动文档数: $N_0 = 2$ (仅含白名单文件)
  - 任务推进中峰值活动文档数: $N_{\max} = 3$ (单次仅允许开启 1 个当前测试零件)
  - 最终测试决算后活动文档数: $N_{\text{final}} = 2$
  - **打开文档净增量**: $\Delta N = N_{\text{final}} - N_0 = \mathbf{0}$
- **结论**: 无任何孤儿文档遗留或内存泄漏，文档生命周期闭环率 100%。

---

## 三、测试沙箱 (`tests/real_cad/sandbox/`) 管理决算

### 1. 沙箱空间与文件统计
- **沙箱路径**: `tests/real_cad/sandbox/`
- **总文件数**: 79 个
- **总磁盘占用**: 5,477,075 字节（约 **5.22 MB**）
- **容量控制评估**: 远低于 50 MB 警界红线，空间占用健康受控。

### 2. 产物保留与分类政策
- **长期保留证据文件**:
  - `benchmark_suite/`: E01~E18 真实生成的零件（`.SLDPRT`）与验证日志。
  - `drawing_test/`: 自动出图生成的标准工程图（`.SLDDRW`）与源零件。
  - `mcp_dialogue/`: FastMCP 三轮交互实机对话生成的零件实体。
  - `ddg_stress/`: DDG 20 轮高压修改最终零件。
- **临时与坏损文件清理**:
  - 故障注入中触发的自交多边形草图、超界几何等在测试回滚时已自动随事务撤销删除，未生成脏文件。

---

## 四、Python 编译缓存与临时脚本清查

1. **字节码缓存 (`__pycache__`, `*.pyc`)**:
   - 临时验证与单测产生的编译缓存收敛于 Python 默认机制，发货根目录无游离 `.pyc` 文件。
2. **临时脚本清理**:
   - 研发探索阶段的所有临时验证逻辑已全量重构成规范的 `tests/real_cad/*.py` 测试脚本，工作区内无游离临时测试脚本。
   - 所有测试脚手架均统一收敛至 `tests/` 与 `tests/real_cad/`。

---

## 五、构建机器路径泄漏与隐私清查

执行自动化契约检测命令：
```bash
node tests/package.test.js
```
- **核心断言**: `shipped files (docs, provenance, tests) do not leak build machine paths`
- **清查范围**: `package.json`, `NOTICE`, `NOTICE.md`, `PROVENANCE.md`, `README.md`, `README.zh.md`, `lib/`, `tests/`。
- **清查规则**: 匹配所有 Windows 绝对盘符路径（如 `D:\...`, `C:\Users\...`）、构建私有用户名等。
- **清查结果**: **0 处违规泄漏 (0 errors, 100% PASS)**。

---

## 六、交付物与 Git 仓库一致性审计

1. **VENDOR 树与 NOTICE 一致性**:
   - `NOTICE` 文件中记录的 190 个 vendored 文件与实际目录结构完全对齐。
   - `npm test` 中 `NOTICE states the file count the vendor tree actually has` 断言通过。
2. **多配置文件版本一致性 (DEF-03)**:
   - `package.json`: `0.2.0`
   - `dsh-plugin.json`: `0.2.0`
   - `lib/index.js`: `0.2.0`
   - 三方版本号无任何漂移。
3. **保留文件完整度**:
   - 现有的历史文档、备份目录、审计报告均完好保留，未发生未经授权的文件删除或覆盖。

---

## 七、决算判定

本系统各项资源指标、文件占用、文档释放与信息安全清查均符合工业级发布标准，清理与环境卫生审计通过判定：**[PASS]**。
