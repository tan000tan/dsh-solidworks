# dsh-solidworks NIGHT-ENGINEERING-02 测试与验收证据清单 (TEST_EVIDENCE.md)

**项目**: dsh-solidworks-plugin  
**任务代号**: NIGHT-ENGINEERING-02  
**终审时间**: 2026-11-05  
**状态**: **[ALL EVIDENCE VERIFIED] (全量实机与自动化证据齐备)**  

---

## 一、验证环境与基础设施

| 配置项 | 实测环境参数 |
| :--- | :--- |
| **操作系统** | Windows 11 专业版 64-bit |
| **CAD 建模平台** | Dassault Systèmes SolidWorks 2026 SP4.1 (Rev 34.4.1, PID 21324) |
| **Python 运行时** | Python 3.13.0 64-bit |
| **Node.js 运行时** | Node.js v24.21.0 |
| **通信接口** | FastMCP JSON-RPC 2.0 (stdio 进程管道) |
| **测试沙箱目录** | `tests/real_cad/sandbox/` |
| **受保护文件白名单** | `['垫圈.SLDPRT', '螺母 GB_T 6170 M10.SLDPRT']` |

---

## 二、E01-E18 全景工程基准套件实机测试证据

### 1. 执行命令与耗时
- **命令**: `python tests/real_cad/real_cad_benchmark_suite.py`
- **总测试用例数**: 18
- **通过率**: **100.0% (18/18 PASS)**
- **总执行耗时**: **188.10 秒**

### 2. 实机测量数据与理论对比表

| 用例代号 | 测试用例名称 | 理论值 / 预期特征 | CAD 实机测量值 | 误差 / 偏差 | 判定 |
| :---: | :--- | :--- | :--- | :---: | :---: |
| **E01** | Cube Extrude | $V = 125,000.00\text{ mm}^3$ | $V = 125,000.00\text{ mm}^3$ | $\Delta V = 0.0000$ | **PASS** |
| **E02** | Cylinder Extrude | $V = 100,530.96\text{ mm}^3$ | $V = 100,530.96\text{ mm}^3$ | $\Delta V = 0.0000$ | **PASS** |
| **E03** | Revolve Boss | $V = 157,079.63\text{ mm}^3$ | $V = 157,079.63\text{ mm}^3$ | $\Delta V = 0.0000$ | **PASS** |
| **E04** | Thin-wall Cylinder | $V = 35,185.84\text{ mm}^3$ | $V = 35,185.84\text{ mm}^3$ | $\Delta V = 0.0000$ | **PASS** |
| **E05** | Linear Pattern DAG | 5 节点阵列孔板 | 成功实例化 4 孔线性阵列 | 特征拓扑健全 | **PASS** |
| **E06** | Multi-hole Cut | $V = 107,206.85\text{ mm}^3$ | $V = 107,206.85\text{ mm}^3$ | $\Delta V = 0.0000$ | **PASS** |
| **E07** | Fillet & Chamfer | 混合圆角与 45° 倒角 | 实体特征健康度 100% | 零坏面/零自交 | **PASS** |
| **E08** | Polygon Sketch | $V = 27,000.00\text{ mm}^3$ | $V = 27,000.00\text{ mm}^3$ | $\Delta V = 0.0000$ | **PASS** |
| **E09** | Long-chain DAG | 6 级纵深线性依赖 | 6/6 节点全部按序执行完成 | 拓扑顺序一致 | **PASS** |
| **E10** | Multi-parent DAG | 6 节点双支柱拓扑汇聚 | 汇聚节点依赖成功求解 | 顶面特征成型 | **PASS** |
| **E11** | Mass Properties | 质心 $(50.0, 25.0, 10.0)$ | 质心 $(50.0, 25.0, 10.0)$ | $\Delta = 0.0000$ | **PASS** |
| **E12** | Dimension Discovery | 遍历草图/特征物理尺寸 | 成功获取尺寸项 $\ge 2$ | 尺寸全名解析正确 | **PASS** |
| **E13** | Parametric Mod | 原位修改 $D1@BaseSketch$ | 驱动模型重建，体积重算 | 体积精准响应 | **PASS** |
| **E14** | Multi-step Mod | 连续 5 轮步进修改与重建 | 特征树无破损，参数收敛 | 零特征报错 | **PASS** |
| **E15** | MQI Evaluation | 制造性智能多维质检 | 评分 91.0（评级 A） | 达到合格品门槛 | **PASS** |
| **E16** | 2D Drawing Auto | 正交三视图与尺寸标注 | 落盘生成 `.SLDDRW` 实体工程图 | 投影尺寸完整 | **PASS** |
| **E17** | Fault & Rollback | 缺失前置依赖隔离拦截 | 编译阶段拦截，零脏特征生成 | 回滚率 100% | **PASS** |
| **E18** | Resource Conserv | 3 轮创建与关闭高压穿透 | 会话前后打开文档数净增量为 0 | $\Delta \text{docs} = 0$ | **PASS** |

---

## 三、FastMCP 3 轮实机交互对话证据 (Round-08)

- **执行入口**: `node tests/real_cad/real_cad_mcp_dialogue_test.mjs`
- **协议通道**: FastMCP stdio 管道 (JSON-RPC 2.0)
- **实测轮次**:
  1. **第一轮 (建模)**:
     - 工具调用: `solidworks_execute_feature_graph`
     - 参数输入: 6 节点 DAG (基准面定义、底板草图、凸台拉伸、4 孔草图、贯穿切除)
     - 返回状态: `success=true`, 执行耗时 12.8s，实体模型落盘于 `tests/real_cad/sandbox/mcp_dialogue/mcp_flange.sldprt`。
  2. **第二轮 (测量)**:
     - 工具调用: `solidworks_get_mass_properties`
     - 返回状态: 体积 $107,206.85\text{ mm}^3$，表面积 $26,841.59\text{ mm}^2$，与独立理论解析模型完全匹配。
  3. **第三轮 (原位参数修改与安全收尾)**:
     - 工具调用: `solidworks_modify_dimension`
     - 参数输入: 修改 `D1@BaseSketch` 从 $100\text{ mm} \to 120\text{ mm}$
     - 返回状态: 原位驱动重建成功，重新核算体积更新为 $155,206.85\text{ mm}^3$。
     - 工具调用: `solidworks_close_documents`，安全落盘保存并关闭测试零件，打开文档数恢复初始基线。

---

## 四、参数依赖图 (DDG) 20 轮高压压力修改证据 (Round-05)

- **执行脚本**: `tests/real_cad/real_cad_ddg_stress_test.py`
- **高压工况**: 对电机支架模型实施连续 20 轮大跨度、高频参数连续跳变（底板长度 80~180mm，凸台高度 30~80mm，中心孔径 15~40mm）。
- **实测指标**:
  - 成功修改轮次: 20/20 (100%)
  - 非受控参数漂移量: **0 项**
  - 重建失败与模型崩溃: **0 次**
  - 双精度体积跟踪吻合度: **100% ($\Delta V \le 10^{-4}\text{ mm}^3$)**

---

## 五、STA 引擎可靠性与故障注入证据 (Round-06)

- **执行脚本**: `tests/real_cad/real_cad_fault_injection_test.py`
- **注入场景**:
  1. 拓扑自交草图（自交多边形）
  2. 超界拉伸参数与退化几何
  3. 空草图直接调用拉伸
  4. 缺失前置依赖的孤立切除特征
  5. 伪造损坏的 COM 指针与 RPC 异常
  6. 并发多线程重入调用
- **拦截表现**:
  - 100% 由 `CADTaskContext` 与 STA Worker 拦截捕获。
  - 成功启动原子化事务回滚，特征树完全撤销至初始洁净态。
  - 10 轮连续高压注入后，SolidWorks 进程 PID 守恒，无孤儿文档残留。

---

## 六、MQI 智能质检与 2D 工程图自动化证据 (Round-07)

- **执行脚本**: `tests/real_cad/real_cad_drawing_mqi_test.py`
- **MQI 评测实测**:
  - 检查项: 草图定义完整度、极小边长检查、悬空特征检测、拓扑流形核查、尺寸完备度等 7 项。
  - 综合得分: **91.0 / 100.0** (等级 A，判定为可制造合格品)。
- **2D 工程图实机生成**:
  - 标准制式: A3 横向标准图纸。
  - 视图配置: 主视图 (Front)、俯视图 (Top)、左视图 (Left) 标准正交投影，以及右上等轴测视图 (Isometric)。
  - 尺寸标注: 自动调用 `InsertModelAnnotations3` 导入特征驱动尺寸。
  - 产物落盘: `tests/real_cad/sandbox/drawing_test/bracket_drawing.SLDDRW`。

---

## 七、自动化测试与代码卫生回归证据

### 1. npm 全量契约与策略测试
```bash
npm test
```
- **输出决算**:
  - `policy.test.js`: 27/27 PASS
  - `mcp.test.js`: 13/13 PASS
  - `schema.test.js`: 16/16 PASS
  - `package.test.js`: 12/12 PASS
  - **总计**: **68/68 PASS (100%)**
  - **构建机器路径泄漏检测**: `shipped files (docs, provenance, tests) do not leak build machine paths` (0 处泄漏)。
  - **NOTICE 文件数一致性**: 190 个 vendored 文件与 NOTICE 完全吻合。

### 2. Python 单元与集成测试套件
```bash
python -m unittest discover -s tests -p "*test*.py"
```
- **输出决算**:
  - `Ran 51 tests in 10.369s`
  - `OK`
  - **通过率**: **51/51 PASS (100%)**
