# dsh-solidworks NIGHT-ENGINEERING-02 文件变更账本 (FILE_CHANGE_LEDGER.md)

| 变更时间 | 文件路径 | 变更分类 | 关联任务 | 修改原因与操作 | 修改前SHA256 | 修改后SHA256 | 对应测试 | 验收状态 |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| 2026-11-05 01:04 | docs/overnight/baseline/* | OWNED_NEW | Gate-00 | 建立不可破坏的项目基线与元数据资产 | 无 | 已落盘 | preflight/git status | PASS |
| 2026-11-05 01:05 | docs/overnight/FILE_CHANGE_LEDGER.md | OWNED_NEW | Gate-00 | 初始化文件变更账本 | 无 | 已落盘 | N/A | PASS |
| 2026-11-05 01:05 | docs/overnight/OVERNIGHT_PROGRESS.md | OWNED_NEW | Gate-00 | 初始化夜间开发进度与检查点 | 无 | 已落盘 | N/A | PASS |
| 2026-11-05 01:05 | docs/overnight/TASK_QUEUE.md | OWNED_NEW | Gate-00 | 初始化十阶段自主开发任务队列 | 无 | 已落盘 | N/A | PASS |
| 2026-11-05 01:05 | docs/overnight/gates/GATE_00.md | OWNED_NEW | Gate-00 | 基线准入门禁核查报告 | 无 | 已落盘 | 4套全量测试 | PASS |
| 2026-11-05 01:08 | docs/overnight/gates/GATE_01.md | OWNED_NEW | TASK-01 | 架构审查门禁验收报告 | 无 | 已落盘 | 穿透审计 | PASS |
| 2026-11-05 01:08 | docs/overnight/reports/ROUND_01_ARCHITECTURE_REVIEW.md | OWNED_NEW | TASK-01 | 全链路架构与债务报告 | 无 | 已落盘 | 符号穿透 | PASS |
| 2026-11-05 01:15 | vendor/.../cad_graph_executor.py | TARGET_EDIT | P1.1 | 增加草图尺寸自动标注驱动能力 | 原版本 | 已更新 | real_cad_sketch_dimension_test | PASS |
| 2026-11-05 01:18 | vendor/.../dimension_modifier.py | TARGET_EDIT | P1.1 | 规范化回滚状态枚举与事务返回 | 原版本 | 已更新 | dimension_system_test | PASS |
| 2026-11-05 01:22 | tests/real_cad/real_cad_mechanical_parts_test.py | OWNED_NEW | TASK-02/03 | 机械零件三模型与三轮参数化实机套件 | 无 | 已落盘 | 实机执行 | PASS |
| 2026-11-05 01:30 | docs/overnight/gates/GATE_02.md | OWNED_NEW | GATE_02 | 复杂机械零件建模与三轮修改门禁报告 | 无 | 已落盘 | 实机三模型 | PASS |
| 2026-11-05 01:30 | docs/overnight/reports/ROUND_02_MECHANICAL_MODELING_REPORT.md | OWNED_NEW | GATE_02 | 机械建模与三轮参数修改工程报告 | 无 | 已落盘 | 交叉核验 | PASS |
| 2026-11-05 01:35 | vendor/.../design_intent.py | OWNED_NEW | TASK-04 | 结构化设计意图与反例审查器 | 无 | 已落盘 | cad_task_planner_test | PASS |
| 2026-11-05 01:36 | vendor/.../cad_task_planner.py | OWNED_NEW | TASK-04/05 | Agent 自主任务规划器与意图编译器 | 无 | 已落盘 | real_cad_planner_test | PASS |
| 2026-11-05 01:37 | tests/cad_task_planner_test.py | OWNED_NEW | TASK-04 | 意图解析与6类反例严苛拦截单元测试 | 无 | 已落盘 | 9/9 单元测试 | PASS |
| 2026-11-05 01:40 | vendor/.../cad_graph_executor.py | TARGET_EDIT | TASK-05 | 草图/特征命名稳定继承与尺寸标注加固 | 原版本 | 已更新 | real_cad_planner_test | PASS |
| 2026-11-05 01:41 | tests/real_cad/real_cad_planner_test.py | OWNED_NEW | TASK-05 | 自主规划自然语言实机端到端验收套件 | 无 | 已落盘 | 实机全闭环 | PASS |
| 2026-11-05 01:42 | docs/overnight/gates/GATE_03.md | OWNED_NEW | GATE_03 | Agent 自主规划与设计意图转译门禁报告 | 无 | 已落盘 | 全量验证 | PASS |
| 2026-11-05 01:42 | docs/overnight/reports/ROUND_03_AUTONOMOUS_PLANNING_REPORT.md | OWNED_NEW | GATE_03 | 自主规划与设计意图工程报告 | 无 | 已落盘 | 端到端闭环 | PASS |
| 2026-11-05 01:45 | vendor/.../feature_graph_ir.py | TARGET_EDIT | TASK-06 | 增加 LINEAR_PATTERN / CIRCULAR_PATTERN 枚举与构造线支持 | 原版本 | 已更新 | advanced_features_test | PASS |
| 2026-11-05 01:46 | vendor/.../cad_graph_executor.py | TARGET_EDIT | TASK-06 | 增加构造线、线性阵列与旋转凸台特征生成实现 | 原版本 | 已更新 | advanced_features_test | PASS |
| 2026-11-05 01:47 | tests/real_cad/real_cad_advanced_features_test.py | OWNED_NEW | TASK-06 | 高级特征（旋转凸台/线性阵列/原位修改）实机套件 | 无 | 已落盘 | 实机执行 | PASS |
| 2026-11-05 01:48 | docs/overnight/gates/GATE_04.md | OWNED_NEW | GATE_04 | 高级建模能力实机突破门禁报告 | 无 | 已落盘 | 实机全量验证 | PASS |
| 2026-11-05 01:48 | docs/overnight/reports/ROUND_04_ADVANCED_FEATURES_REPORT.md | OWNED_NEW | GATE_04 | 第四轮高级建模特征突破验收报告 | 无 | 已落盘 | 几何交叉核验 | PASS |
| 2026-11-05 01:50 | vendor/.../dimension_dependency_graph.py | OWNED_NEW | TASK-07 | 参数依赖图 (DDG) 拓扑排序/影响域推导/零漂移核验器 | 无 | 已落盘 | ddg_test | PASS |
| 2026-11-05 01:50 | tests/dimension_dependency_graph_test.py | OWNED_NEW | TASK-07 | DDG 单元测试套件（拓扑排序/环路检测/零漂移） | 无 | 已落盘 | 4/4 单元测试 | PASS |
| 2026-11-05 01:51 | NOTICE | TARGET_EDIT | TASK-07 | 更新 vendored 文件计数至 189 (scripts 87) | 原版本 | 已更新 | package.test.js | PASS |
| 2026-11-05 01:52 | tests/real_cad/real_cad_ddg_stress_test.py | OWNED_NEW | TASK-07 | DDG 拓扑与 20 轮连续高压参数化修改实机测试套件 | 无 | 已落盘 | 20轮实机执行 | PASS |
| 2026-11-05 01:55 | vendor/.../dimension_reader.py | TARGET_EDIT | TASK-07 | 规范化 COM FullName 解析，彻底消除吸收草图特征别名幽灵注册 | 原版本 | 已更新 | 20轮实机执行 | PASS |
| 2026-11-05 01:57 | docs/overnight/gates/GATE_05.md | OWNED_NEW | GATE_05 | 参数依赖图 (DDG) 与 20 轮高压参数化修改门禁报告 | 无 | 已落盘 | 实机 20 轮全量验证 | PASS |
| 2026-11-05 01:57 | docs/overnight/reports/ROUND_05_DDG_STRESS_REPORT.md | OWNED_NEW | GATE_05 | 第五轮参数依赖图与长程高压修改验收报告 | 无 | 已落盘 | 几何交叉核验 | PASS |
| 2026-11-05 08:41 | vendor/.../sw_connect.py | TARGET_EDIT | TASK-08 | STA Worker 重入锁重构 (RLock) 与安全 close_document 接口落地 | 原版本 | 已更新 | engine_reliability_test | PASS |
| 2026-11-05 08:41 | tests/engine_reliability_test.py | OWNED_NEW | TASK-08 | STA Worker 线程模型、超时熔断与生命周期单元测试 | 无 | 已落盘 | 5/5 单元测试 | PASS |
| 2026-11-05 08:43 | tests/real_cad/real_cad_fault_injection_test.py | OWNED_NEW | TASK-08 | 故障注入实机测试套件（中途回滚/级联跳过/高频句柄压测） | 无 | 已落盘 | 实机执行 | PASS |
| 2026-11-05 08:50 | docs/overnight/gates/GATE_06.md | OWNED_NEW | GATE_06 | 执行引擎高可用与故障注入门禁报告 | 无 | 已落盘 | 全量验证 | PASS |
| 2026-11-05 08:50 | docs/overnight/reports/ROUND_06_ENGINE_RELIABILITY_REPORT.md | OWNED_NEW | GATE_06 | 第六轮执行引擎可靠性与故障注入验收报告 | 无 | 已落盘 | 实机三用例 | PASS |
| 2026-11-05 08:56 | vendor/.../model_quality_inspector.py | OWNED_NEW | TASK-09 | 工业模型质量审查器 (MQI): 几何/特征/草图约束/尺寸完备性综合评分 | 无 | 已落盘 | real_cad_drawing_mqi_test | PASS |
| 2026-11-05 08:56 | NOTICE | TARGET_EDIT | TASK-09 | 更新 vendored 文件计数至 190 (scripts 88) | 原版本 | 已更新 | package.test.js | PASS |
| 2026-11-05 09:07 | tests/real_cad/real_cad_drawing_mqi_test.py | OWNED_NEW | TASK-09 | MQI 质量审查与 2D 工程图自动出图实机测试套件 | 无 | 已落盘 | 实机执行 | PASS |
| 2026-11-05 14:50 | docs/overnight/gates/GATE_07.md | OWNED_NEW | GATE_07 | MQI 质量审查与 2D 工程图自动化出图门禁报告 | 无 | 已落盘 | 实机三用例 | PASS |
| 2026-11-05 14:50 | docs/overnight/reports/ROUND_07_MQI_DRAWING_REPORT.md | OWNED_NEW | GATE_07 | 第七轮 MQI 质量核查与 2D 工程图自动化出图验收报告 | 无 | 已落盘 | 全流程闭环 | PASS |
| 2026-11-05 15:20 | tests/real_cad/real_cad_mcp_dialogue_test.mjs | OWNED_NEW | GATE_08 | 第八轮 FastMCP 三轮对话实机验收套件 | node | 已执行 | 3轮闭环 | PASS |
| 2026-11-05 15:20 | docs/overnight/gates/GATE_08.md | OWNED_NEW | GATE_08 | 第八轮门禁审核决策书 | 无 | 已归档 | 门禁通过 | PASS |
| 2026-11-05 15:20 | docs/overnight/reports/ROUND_08_MCP_DIALOGUE_REPORT.md | OWNED_NEW | GATE_08 | 第八轮 FastMCP 三轮对话实机验收报告 | 无 | 已归档 | 全流程通过 | PASS |
| 2026-11-05 17:21 | tests/real_cad/real_cad_benchmark_suite.py | OWNED_NEW | GATE_09 | 第九轮 E01-E18 工程基准实机测试套件 | python | 已执行 | 18/18通过 | PASS |
| 2026-11-05 17:21 | docs/overnight/gates/GATE_09.md | OWNED_NEW | GATE_09 | 第九轮门禁审核决策书 | 无 | 已归档 | 门禁通过 | PASS |
| 2026-11-05 17:21 | docs/overnight/reports/ROUND_09_BENCHMARKS_REPORT.md | OWNED_NEW | GATE_09 | 第九轮实机工程基准测试套件验收报告 | 无 | 已归档 | 全流程通过 | PASS |
| 2026-11-05 17:23 | docs/overnight/gates/GATE_10.md | OWNED_NEW | GATE_10 | 第十轮产品化终审门禁决策书 | 无 | 已归档 | 门禁通过 | PASS |
| 2026-11-05 17:23 | docs/overnight/GATE_SUMMARY.md | OWNED_NEW | GATE_10 | 全门禁决算总表 (Gate-00~10) | 无 | 已归档 | 11门禁全过 | PASS |
| 2026-11-05 17:23 | docs/overnight/FINAL_REPORT.md | OWNED_NEW | GATE_10 | 全夜自主工程独立交付最终报告 | 无 | 已归档 | 交付结项 | PASS |
