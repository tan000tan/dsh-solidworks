# NIGHT-ENGINEERING-05: 文件变更总台账 (FILE_CHANGE_LEDGER.md)

本文档记录在 NIGHT-ENGINEERING-05（DSH 真实宿主集成与 Alpha 产品化）执行周期内涉及的所有文件变更与新增产物。

---

## 一、变更原则遵守声明

- **DSH 主程序保护**：零修改；
- **SolidWorks 主程序保护**：零修改；
- **DSH 核心配置保护**：零修改；
- **用户原有模型保护**：白名单受保护零件（`垫圈.SLDPRT`, `螺母 GB_T 6170 M10.SLDPRT`）零写入；
- **系统环境与 PATH 保护**：零篡改；
- **Git 树完整性**：未执行任何 `git reset`、`git clean` 或破坏性检出指令；
- **独立沙箱隔离**：本轮所有宿主模拟与追踪物证严格限制在 `tests/real_cad/sandbox/night_05/` 中。

---

## 二、变更文件详细明细

| 序号 | 文件路径 | 变更类型 | 变更原因与工程影响 |
| :--- | :--- | :--- | :--- |
| 1 | `tests/real_cad/dsh_host_trace_test.mjs` | 新增 | 模拟真实 DSH 宿主环境的集成测试脚本。验证插件加载、Cordis 契约、stdio 通信与自然语言调用链测试 A/B/C/D。 |
| 2 | `tests/real_cad/sandbox/night_05/dsh_host_trace_evidence.json` | 新增 | DSH 宿主集成测试全量结构化执行物证（包含耗时、返回 Payload、策略拦截记录）。 |
| 3 | `tests/real_cad/sandbox/night_05/dsh_host_audit.jsonl` | 新增 | 宿主安全策略层记录的真实审计日志文件。 |
| 4 | `docs/night_engineering_05/PREREQUISITE_REVIEW.md` | 新增 | 阶段一：前置成果门禁验收与审查报告。 |
| 5 | `docs/night_engineering_05/DSH_HOST_INTEGRATION.md` | 新增 | 阶段二：DSH 真实宿主集成机制调查报告。 |
| 6 | `docs/night_engineering_05/MCP_TOOL_DISCOVERY.md` | 新增 | 阶段二：MCP 工具发现、数量差异与 Schema 结构审计报告。 |
| 7 | `docs/night_engineering_05/END_TO_END_TRACE.md` | 新增 | 阶段二：完整端到端调用链追踪与测试 A/B/C/D 验证报告。 |
| 8 | `docs/night_engineering_05/SECURITY_PERMISSION_AUDIT.md` | 新增 | 阶段三：安全策略与权限体系产品化审计报告。 |
| 9 | `docs/night_engineering_05/INSTALLATION_EXPERIENCE.md` | 新增 | 阶段四：安装与配置体验评估报告与向导方案设计。 |
| 10 | `docs/night_engineering_05/PRODUCT_CAPABILITY_MATRIX.md` | 新增 | 阶段五：插件功能边界与产品能力矩阵报告。 |
| 11 | `docs/night_engineering_05/RELIABILITY_AUDIT.md` | 新增 | 阶段六：可靠性与异常恢复能力审查报告。 |
| 12 | `docs/night_engineering_05/ALPHA_RELEASE_READINESS.md` | 新增 | 阶段七：Alpha 发布就绪度全景审计报告。 |
| 13 | `docs/night_engineering_05/FILE_CHANGE_LEDGER.md` | 新增 | 本文件，全流程变更总台账。 |
| 14 | `docs/night_engineering_05/FILE_HASH_MANIFEST.json` | 新增 | 本轮交付物与证据的 SHA-256 哈希清单。 |
| 15 | `docs/night_engineering_05/FINAL_REPORT.md` | 新增 | NIGHT-ENGINEERING-05 最终总结报告与 10 项决策判定。 |
