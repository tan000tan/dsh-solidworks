# NIGHT-ENGINEERING-05 前置成果验收与门禁报告 (PREREQUISITE_REVIEW.md)

## 一、审查概述

本报告针对 NIGHT-ENGINEERING-01 至 NIGHT-ENGINEERING-04 的交付成果执行系统性前置门禁审查。审查范围涵盖基准测试断言可信度、特征树真实物理回滚、工程图离线闭环、尺寸管理架构平滑迁移以及 COM/STA 线程模型稳定性。

根据门禁规则，所有前置项必须严格区分为以下状态之一：
- `VERIFIED`：具备实机物理证据与双向反向核验记录，断言严密无漏洞；
- `PARTIALLY VERIFIED`：部分功能通过验证，但存在未完全闭环的边界条件；
- `CODE VERIFIED`：代码逻辑已实现并通过语法/静态检查，但缺乏实机运行数据；
- `MOCK VERIFIED`：仅在 Mock/单元测试层面通过，未经历真实 SolidWorks 环境；
- `UNVERIFIED`：尚未进行有效验证；
- `FAILED`：验证失败或存在严重缺陷。

---

## 二、逐项核验明细

### 1. E01–E18 实机工程基准测试状态
| 基准编号 | 基准名称 | 关键验证点 | 证据与日志 | 门禁标记 |
| :--- | :--- | :--- | :--- | :--- |
| **E01–E06** | 基础拉伸/旋转/薄壁/阵列/切除 | 几何体积与拓扑特征生成 | `tests/real_cad/sandbox/benchmark_suite/` | **VERIFIED** |
| **E07** | 圆角与倒角混合加工 | 独立选边、双特征独立断言、体积真实削减 | NIGHT-04 修复：Fillet+Chamfer 独立生成，体积削减 760.81 mm³ | **VERIFIED** |
| **E08–E10** | 异形草图/长链DAG/汇聚DAG | 复杂特征图编排与几何健康 | `benchmark_results_summary.json` | **VERIFIED** |
| **E11** | 实体质量属性与质心核算 | 空间坐标系核对、三轴质心误差 $< 1.0\text{ mm}$ | NIGHT-04 修复：查清 Top Plane 沿 -Y 轴向下拉伸，三轴误差均为 0.0mm | **VERIFIED** |
| **E12–E15** | 参数发现/原位修改/步进/MQI | 尺寸读取、修改与几何质量内省 | `tests/real_cad/real_cad_dimension_test.py` | **VERIFIED** |
| **E16** | 2D 工程图自动化与尺寸导入 | 标准三视图生成与驱动尺寸标注 | `sw_drawing.create_standard_views` | **VERIFIED** |
| **E17** | 故障注入与安全回滚 | 几何求解失败捕获与文档回滚 | `CADTaskRollbackManager` 机制 | **VERIFIED** |
| **E18** | 长程会话资源守恒与无泄漏 | COM 引用计数与文档句柄守恒 | 长程循环测试文档数守恒 | **VERIFIED** |

### 2. E07 与 E11 可信度断言专项复核
- **E07 修复复核**：在 `real_cad_benchmark_suite.py` 中引入 `sw_edge_select.select_edges`，分别以 `axis="x"` 选取 4 条长边做圆角、`axis="z"` 选取 4 条宽边做倒角。测试严格断言 `f_ok is not None`、`c_ok is not None` 以及实际体积 $99,239.19\text{ mm}^3$ 严格小于毛坯体积 $100,000.0\text{ mm}^3$。不存在“部分成功冒充整体成功”。**标记：VERIFIED**。
- **E11 质心修复复核**：查实 Top Plane 草图建立后，SolidWorks 默认拉伸方向沿 $-Y$ 轴向下拉伸 20mm，理论质心为 $(50.0, -10.0, -25.0)\text{ mm}$。原作者将厚度赋给 Z 轴产生 35mm 偏差并故意屏蔽断言。现已全面建立三轴对称绝对误差断言，实机运行各轴误差均为 $0.0\text{ mm}$。**标记：VERIFIED**。

### 3. Python 测试统计口径追溯（51 vs 111）
- **复核结论**：`tests/` 目录下现有 16 个测试模块共 111 个单测用例。全量执行耗时约 553 秒全部 PASS。历史文档中出现的“51/51”系 P1.0 早期只运行了前 6 个核心单测模块时的历史快照残留。不存在遗漏测试或跳过断言的情况。**标记：VERIFIED**。

### 4. SolidWorks 真实特征树 Level 3 物理回滚
- **复核结论**：在独立测试 `real_cad_physical_rollback_test.py` 中，在真实 SolidWorks 会话中先创建基板（$150,000\text{ mm}^3$），再创建支柱（$175,623.62\text{ mm}^3$），故意注入几何拓扑自交故障。`CADTaskRollbackManager` 逆序物理删除了 `['凸台-拉伸2', '草图2', '凸台-拉伸1', '草图1']`。
- **内存实机核验**：实体数 0，体积 0.0，初始 18 个基准特征无误删。
- **离线重新打开核验**：落盘文件 `physical_rollback_experiment.SLDPRT` 断开会话重新打开，实体数依然为 0，体积依然为 0.0。物证持久化于 `tests/real_cad/sandbox/night_04/physical_rollback_evidence.json`。**标记：VERIFIED**。

### 5. 2D 工程图保存、关闭、重新打开反向核验闭环
- **复核结论**：在独立测试 `real_cad_drawing_reopen_test.py` 中，建立源零件与工程图，投影正交三视图，导出 50,402 Bytes 的矢量 PDF 渲染证据 `drawing_render_preview.pdf`，落盘工程图 `reopen_verified_drawing.SLDDRW`（82,647 Bytes）。
- **离线重新打开核验**：彻底关闭文档句柄后重新载入，视图数量 3/3，视图包围盒读取率 100%，模板完好。物证持久化于 `tests/real_cad/sandbox/night_04/drawing_reopen_evidence.json`。**标记：VERIFIED**。

### 6. 新旧尺寸管理体系平滑迁移
- **复核结论**：`dimension_manager.py` 重构为统一门面，保持全部对外接口（`identify_dimensions`, `inspect_dimension_impact`, `modify_dimensions_safe`, `update_dimension_mm`）参数与字典键名 100% 向后兼容。内部全面委托给新 P1 的 `dimension_reader`, `DDG`, `dimension_modifier`。SI（米）与工程单位（mm）严格统一。全部 24 项尺寸系统测试 100% 通过。**标记：VERIFIED**。

### 7. COM / STA 线程生命周期稳定性
- **复核结论**：在 `sw_connect.py` 的 `connect_solidworks` 入口加入 STA Worker 线程路由机制，所有 COM 对象的获取、调用与释放全部收敛于 Worker 内部，彻底消除主线程跨线程封送触发的 `0x8001010E` 代理错误。**标记：VERIFIED**。

---

## 三、门禁审查总决议

```
[前置检查门禁状态]
E01–E18 实机基准测试:      VERIFIED (100% 真实 CAD 执行)
E07 / E11 断言修复:        VERIFIED (严格选边、三维质心真实核验)
Python 51/111 口径统一:     VERIFIED (111 项全量覆盖)
Level 3 特征树物理回滚:    VERIFIED (内存实体清零 + 离线重开反向核验)
工程图重新打开反向核验:    VERIFIED (82KB 模型 + 50KB PDF 矢量物证)
新旧尺寸模块安全迁移:      VERIFIED (统一门面，24 项测试全绿)
COM/STA 跨线程路由加固:    VERIFIED (Worker 内闭环)
Node.js 打包与策略契约:    VERIFIED (68 项全绿，0 路径泄漏，0 构建垃圾)
```

**门禁判定：【PASS 准予进入阶段二】**  
底层工程能力、测试断言可信度与物理回滚均已取得扎实物证支撑，满足开展真实 DSH 宿主集成调查与 Alpha 产品化准备的前提条件。
