# NIGHT-ENGINEERING-05 阶段二：MCP 工具发现与 Schema 结构审计 (MCP_TOOL_DISCOVERY.md)

## 一、工具发现机制与实机清单

在真实 DSH 宿主运行环境中，工具发现经历三级递进流程：
1. **第一级（底层服务）**：Python FastMCP 子进程启动，通过 JSON-RPC `tools/list` 报文向 Node.js 客户端报告其内部注册的全部 CAD 工具。
2. **第二级（策略裁剪）**：Node.js 宿主插件根据当前配置的安全策略模式（`mode: read-only | standard | full`）与黑白名单（`allow`, `deny`），通过 `Policy.registerable(name)` 决定该工具是否向 DSH 宿主注册。
3. **第三级（宿主呈现）**：通过 `unwrapParams()` 将 FastMCP 内部生成的嵌套 `$defs` / `params` 包装层平铺提升，转换为符合 DSH 规范的扁平 JSON Schema，并通过 `ctx.tools.register()` 注册给 DSH Agent。

---

## 二、实机工具发现数量核对与差异分析

### 1. 核心数量统计
- **底层 `server.py` 实际暴露工具总数**：**71 项**
- **历史 `dsh-plugin.json` 声明工具数**：**66 项**
- **当前 `lib/policy.js` 风险映射表 (`RISK_TABLE`) 收录项**：**66 项**
- **宿主层常驻 Meta 工具数**：**2 项** (`solidworks_status`, `solidworks_confirm`)

### 2. 工具差异深入追溯（71 vs 66）
通过实机比对探针查实，`server.py` 比历史清单多出的 5 个工具为 P0.4 与 P1 阶段新增的核心工程建模与尺寸参数化工具：
1. `solidworks_compile_feature_graph`：离线特征依赖拓扑图编译与求解检查（只读内存操作）；
2. `solidworks_execute_feature_graph`：特征图全流程 SolidWorks 实机建模编排（模型写入操作）；
3. `solidworks_identify_dimensions`：零件/草图驱动与从动尺寸全景枚举与识别（只读内省操作）；
4. `solidworks_inspect_dimension_impact`：基于 DDG 的下游特征受波及影响面分析（只读拓扑分析操作）；
5. `solidworks_modify_dimension_safe`：尺寸参数原位就地安全修改与影子备份自愈（模型写入操作）。

### 3. Zero-Trust 安全分类断点发现
在 `lib/policy.js` 中，由于上述 5 个新工具尚未在硬编码的 `RISK_TABLE` 中登记，插件触发了 Zero-Trust 安全保底机制：
- **安全规则**：`Unknown tools default to HIGH, never READ.`（未知工具一律默认标记为 `HIGH` 高风险等级）；
- **产品化影响**：
  在默认的 `mode: read-only` 策略下，`solidworks_identify_dimensions` 与 `solidworks_inspect_dimension_impact` 这类纯只读尺寸查询工具因为被识别为 `HIGH`，被策略层直接拦截扣留（Withheld），未向普通用户的 DSH 对话界面暴露！
  用户在默认只读模式下询问“帮我看看这个零件的尺寸参数”时，Agent 无法在工具列表中找到尺寸查询工具。

---

## 三、各策略模式下实际暴露工具分布

| 策略模式 (Mode) | 暴露的 MCP 工具数量 | 扣留 (Withheld) 工具数量 | Meta 工具 | Agent 可见总工具数 | 说明 |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **`read-only` (默认)** | 16 项 | 55 项 | 2 项 | **18 项** | 仅允许检查状态、测量质量属性、查看边线，杜绝任何写入 |
| **`standard`** | 41 项 | 30 项 | 2 项 | **43 项** | 允许在活动内存中建模、创建特征、修改尺寸，禁止落盘与保存 |
| **`full`** | 71 项 | 0 项 | 2 项 | **73 项** | 全量开放全部功能，其中高风险保存/导出需单次显式授权 |

### 默认 `read-only` 模式下向 DSH Agent 暴露的 18 个工具清单
1. `solidworks_status` (Meta 诊断工具)
2. `solidworks_confirm` (Meta 授权工具)
3. `solidworks_health_check` (健康检查)
4. `solidworks_list_edges` (边线内省)
5. `solidworks_mass_properties` (质量属性核算)
6. `solidworks_bounding_box` (模型包围盒测量)
7. `solidworks_interference_check` (干涉检查)
8. `solidworks_inspect_configurations` (配置信息内省)
9. `solidworks_inspect_hole_features` (孔特征检查)
10. `solidworks_inspect_motion_studies` (运动算例检查)
11. `solidworks_validate_motion_study` (运动算例校验)
12. `solidworks_addin_host_status` (插件状态查询)
13. `solidworks_inspect_native_geometry` (原生几何检查)
14. `design_spec_validate` (设计规范离线校验)
15. `cadstudio_resolve_backend` (CAD 求解后端解析)
16. `cadstudio_routing_preflight` (管路预检)
17. `cadstudio_fea_preflight` (有限元分析预检)
18. `cadstudio_read_artifact` (工件只读检查)

---

## 四、Schema 参数格式与输出契约核验

1. **Schema 自动解包 (unwrapParams)**：
   - FastMCP 默认会将工具参数封装在 `params: { ... }` 包装对象中；
   - `lib/schema.js` 在注册给 DSH 宿主时，自动提升（Hoist）内部属性，剥离外层冗余包装，确保大模型生成的 JSON 参数能够直观对齐。
2. **DSH 规范统一输出格式 (OUTPUT)**：
   - 每个工具注册时均明确声明：
     ```javascript
     output: {
       schema: { type: 'object', properties: { text: { type: 'string' } }, required: ['text'] },
       render: (_args, value) => [{ type: 'text', text: String(value?.text ?? '') }]
     }
     ```
   - 彻底满足 DSH 宿主（Cordis 平台）对工具输出必须具备 `schema` 与 `render` 渲染函数的严苛契约。
