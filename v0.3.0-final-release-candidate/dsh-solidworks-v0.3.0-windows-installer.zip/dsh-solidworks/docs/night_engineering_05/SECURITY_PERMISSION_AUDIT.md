# NIGHT-ENGINEERING-05 阶段三：安全策略与权限体系产品化审计 (SECURITY_PERMISSION_AUDIT.md)

## 一、安全架构与设计哲学

在 CAD 自动化与桌面代理领域，直接将具有宿主文件写入和 CAD 操作权限的接口开放给大语言模型是极高风险的行为。大模型的幻觉或非预期指令可能导致用户模型被不可逆覆盖、特征被批量删除或重要工程图纸损坏。

`dsh-solidworks` 确立了**非对称纵深防御安全架构 (Asymmetric Defense-in-Depth)**：
1. **零信任原则 (Zero-Trust)**：永远不信任大模型自行判断危险性。所有调用在到达 Python 核心前，必须由 Node.js 宿主策略层静态审计拦截。
2. **默认只读 (Secure-by-Default)**：开箱默认运行于 `read-only` 模式，高风险写操作与持久化工具直接从 Agent 工具列表中隐藏，不可见即不可调。
3. **参数强绑定单次授权 (Single-Use Parameter-Bound Grant)**：高风险操作必须通过单次授权，授权严格绑定确切参数哈希，杜绝重放攻击与参数篡改。
4. **沙箱与路径白名单 (Allowed Roots Walk)**：严格限制文件操作根目录，拦截跨目录遍历、Windows 保留设备名（`CON`, `NUL` 等）与 SMB NTLM 远程哈希泄露 UNC 路径。

---

## 二、三级风险分类体系 (Risk Tiers)

宿主策略引擎将全部 CAD 工具划分为三级刚性风险：

```
        ┌─────────────────────────────────────────────────────────┐
        │  HIGH (高风险: 持久化/删除/关闭/求解)                    │
        │  例如: save_document, close_documents, run_fea          │
        │  要求: 必须 full 模式 + solidworks_confirm 单次参数授权 │
        └───────────────────────────▲─────────────────────────────┘
                                    │ (提升条件)
        ┌───────────────────────────┴─────────────────────────────┐
        │  WRITE / STANDARD (普通写入: 内存修改/建模)             │
        │  例如: new_document, sketch_and_extrude, fillet         │
        │  要求: 必须 standard 或 full 模式，read-only 模式下隐藏 │
        └───────────────────────────▲─────────────────────────────┘
                                    │ (提升条件)
        ┌───────────────────────────┴─────────────────────────────┐
        │  READ (只读内省: 状态/质量属性/无副作用)                │
        │  例如: solidworks_status, mass_properties, list_edges   │
        │  要求: 所有模式均可直接调用                             │
        └─────────────────────────────────────────────────────────┘
```

### 1. 风险分类判定规则
- **显式白名单 (`RISK_TABLE`)**：收录的 66 项核心工具具备严格固定的风险等级；
- **模式推断 (`HIGH_PATTERN` / `WRITE_PATTERN`)**：
  - 工具名包含 `save|export|close|delete|pack|remove|recover|write|install` 时，自动提升为 `HIGH`；
  - 工具名包含 `add|create|set|update|activate|fillet|chamfer|sketch|build` 时，自动识别为 `WRITE`；
- **保底防御**：任何既未在表格收录也未命中关键字的未识别工具，**一律强制归类为 `HIGH`，严禁判定为 `READ`**。

---

## 三、授权机制与漏洞防御审计

### 1. 单次授权与防重放机制 (Single-Use Grant)
- **机制**：调用 `solidworks_confirm` 时，需传入 `tool` 名称与完整的 `args` 字典；
- **参数哈希**：策略层调用 `canonicalArgs(args)` 将参数字典键名排序并序列化，计算 SHA-256 哈希值 `digest`；
- **时效性 (TTL)**：授权默认有效期为 300 秒（5 分钟），超时自动作废；
- **单次消费 (One-Shot Consumption)**：
  - 当高风险工具被调用时，策略层匹配 `digest` 并**立即从内存挂起列表中移除 (`policy.consumeGrant(tool, args)`)**；
  - **防二次利用漏洞**：即使同一会话中 Agent 再次发起一模一样的调用，由于授权已被消费，第二次调用将立即被拒绝 (`CONFIRM_REQUIRED`)。

### 2. 参数防篡改验证 (Anti-Tampering)
- **场景**：Agent 骗取了保存到临时目录的授权，但实际在调用 `solidworks_save_document` 时将路径偷换为用户原始模型路径；
- **防御**：由于 `digest` 严格绑定全部参数键值，任何参数的增减、修改均会导致 SHA-256 哈希改变，策略层对比失败立即拦截，篡改攻击无法得逞。

### 3. 路径遍历与系统设备注入防御
- **`allowedRoots` 强制边界**：如果配置了允许路径（例如工作区目录），所有带路径参数的工具调用均经过 `resolveAllowedPath()` 物理真实路径（`realpath`）解析；
- **符号链接/Junction 穿透防御**：通过深度真实路径解析，拦截指向白名单外部的 Windows 目录连接点；
- **DOS 设备名注入**：严密拦截 `CON`, `PRN`, `AUX`, `NUL`, `COM1-COM9`, `LPT1-LPT9` 等可能导致 Windows 驱动死锁的保留设备名；
- **远程 UNC 路径拦截**：严密拒绝 `\\192.168.x.x\share` 形式的远程 UNC 路径，防止攻击者通过 SMB 请求窃取 Windows NTLM 哈希。

---

## 四、破坏性操作保护机制

| 破坏性操作类型 | 潜在业务危害 | 插件内置保护机制 |
| :--- | :--- | :--- |
| **覆盖保存原文件** (`solidworks_save_document`) | 损坏用户原本完好的几何模型 | 必须进入 `full` 模式，且必须由用户在聊天界面明确获知并经 `solidworks_confirm` 批准；支持指定不同路径另存。 |
| **特征树删除/回滚** (`cad_task_context`) | 错误删除重要零件历史特征 | 必须在沙箱和受控上下文中运行；受保护特征白名单机制（基准面/原点绝对禁止删除）。 |
| **原位尺寸修改** (`solidworks_modify_dimension_safe`) | 尺寸过大导致几何自交或拓扑崩溃 | 结合 `ShadowBackupManager` 修改前自动建立影子副本；重构失败自动自愈回滚至修改前快照。 |
| **关闭所有文档** (`solidworks_close_documents`) | 造成未保存工作丢失 | 划入 `HIGH` 级别，需要显式授权，且支持检查脏文档标记。 |

---

## 五、安全审查结论

- **风险分级体系**：**PASS**（Zero-Trust 策略严密，未登记工具默认锁定为 HIGH）；
- **授权绑定机制**：**PASS**（单次使用、参数哈希绑定、超时自动失效、防重放）；
- **文件与路径安全**：**PASS**（遍历拦截、UNC 远程拦截、Windows 设备名防御 100% 通过）；
- **模型自愈保护**：**PASS**（影子快照与物理回滚双保险）。
