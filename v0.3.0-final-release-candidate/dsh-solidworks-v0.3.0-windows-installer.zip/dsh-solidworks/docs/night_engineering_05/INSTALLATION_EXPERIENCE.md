# NIGHT-ENGINEERING-05 阶段四：安装与配置体验评估报告 (INSTALLATION_EXPERIENCE.md)

## 一、普通用户安装路径现状审查

当前 `dsh-solidworks` 的安装与运行依赖链条较长，横跨 Node.js、Python、Windows COM 和 SolidWorks 桌面环境四个层次：

```
[用户电脑] ──► 安装 SolidWorks 桌面应用 (需已激活/运行中)
           ──► 安装 Node.js (>=22.12)
           ──► 安装 Python (>=3.10 且带 pywin32, mcp, pydantic)
           ──► 配置 DSH 插件 (cordis.patch.yml)
           ──► 启动 DSH 并开始对话
```

### 1. 现有配置门槛分析
- **痛点 1（多重环境依赖）**：普通机械工程师通常仅熟悉 SolidWorks 操作，对 Python 虚拟环境（`.venv`）、`pip install -r requirements.txt` 以及 Node.js 包机制较为陌生；
- **痛点 2（Windows Store 假解释器混淆）**：在未安装官方 Python 的 Windows 机器上，在终端输入 `python` 会自动唤起 Windows Store 伪别名，无法直接运行第三方库；
- **痛点 3（COM 注册表与位宽匹配）**：SolidWorks 是 64 位程序，若用户安装了 32 位 Python，会导致 `win32com.client.Dispatch("SldWorks.Application")` 跨位宽失败。

---

## 二、自动诊断与无感探测体验

为了降低普通用户的配置门槛，插件在底层已经内置了多重**自愈与自动发现**机制：

### 1. 解释器零配置发现 (DEF-01)
用户**无需手动修改 PATH 或编写复杂环境变量**。插件在启动时会自动按优先级遍历：
1. 插件目录内的 `.venv/pyvenv.cfg`；
2. 系统 `py` 启动器（`py -0p`，自动识别仅为当前用户安装的 Python）；
3. 常见根目录扫描（`C:\Python3*`、`%LOCALAPPDATA%\Programs\Python`）。
- **实测体验**：在我们的测试机器上，即使用户未将 Python 写入系统全局 PATH，插件仍能在 1.5 秒内通过虚拟环境配置准确锁定解释器。

### 2. 单例自愈诊断工具 (`solidworks_status`)
当环境不具备条件时（例如 Python 缺失 `mcp` 包，或 SolidWorks 未启动），插件**绝不直接报错崩溃**，而是向用户提供友好的状态报告：
- 明确告知当前插件版本；
- 明确指出当前使用的 Python 路径与版本；
- 如果失败，指出最后 10 行详细错误信息与修复建议（例如：“请启动 SolidWorks 桌面程序” 或 “执行 pip install mcp”）。

---

## 三、面向普通用户的配置向导设计方案

为了让非技术背景的 CAD 工程师能够“开箱即用”，建议在 Alpha 发布阶段引入**轻量级本地就绪向导 (Readiness Wizard)**。

### 1. 实施原则（无需管理员权限、不修改系统环境）
- 严禁擅自修改 Windows 注册表或全局 PATH；
- 严禁强制静默下载庞大安装包；
- 优先采用本地绿色虚拟环境（`.venv`）或免安装 Portable Python 打包方案。

### 2. 自动化就绪检查脚本 (`check_environment.bat`)
提供一键双击批处理脚本，执行纯只读检查：
```bat
@echo off
chcp 65001 >nul
echo ========================================================
echo      dsh-solidworks 本地运行就绪度快速检查
echo ========================================================
echo [1/3] 检查 SolidWorks 运行状态...
tasklist /FI "IMAGENAME eq SLDWORKS.exe" 2>NUL | find /I /N "SLDWORKS.exe">NUL
if "%ERRORLEVEL%"=="0" (
    echo [✔] SolidWorks 正在运行中
) else (
    echo [!] 提示: SolidWorks 未运行，请先打开 SolidWorks 软件
)

echo [2/3] 检查 Python 环境...
py -3 -c "import mcp, win32com; print('[✔] Python 环境与 CAD 依赖就绪 (Python ' + __import__('sys').version.split()[0] + ')')" 2>nul
if errorlevel 1 (
    echo [!] 未检测到包含 mcp 与 pywin32 的 Python 环境
    echo     建议执行: py -3 -m pip install -r requirements.txt
)

echo [3/3] 检查 Node.js 环境...
node -v 2>nul
if errorlevel 1 (
    echo [!] 未检测到 Node.js，DSH 宿主需要 Node.js ^>= 22.12
) else (
    echo [✔] Node.js 就绪
)
echo ========================================================
pause
```

---

## 四、配置指南与文档完备性核查

| 必备文档与指南 | 当前状态 | 评估与说明 |
| :--- | :--- | :--- |
| **安装说明** (`README.md`) | 完整 | 详细说明了 Node 与 Python 依赖要求 |
| **SolidWorks 版本要求** | 明确 | 支持 SolidWorks 2021–2026 (实机为 SW 2026 SP4.1) |
| **安全策略配置示例** (`cordis.patch.yml`) | 完整 | 提供 `read-only`, `standard`, `full` 三档配置示例 |
| **故障排查指南** | 具备 | 依托 `solidworks_status` 与 `tests/package.test.js` 验证 |
| **卸载与恢复方法** | 简洁 | 纯无侵入式插件，从 DSH profile 移除插件节点即可彻底卸载 |

---

## 五、安装体验审查结论

- **当前状态**：对于具备基础 Python 环境的开发者与高级用户，体验顺畅（支持自动探测）；
- **对普通用户的改进建议**：正式发布前应随包附带本地 `.venv` 初始化向导批处理，或推荐将 Python 运行时作为可选扩展包一同分发。
