# NIGHT-ENGINEERING-05 阶段七：Alpha 发布就绪度审计报告 (ALPHA_RELEASE_READINESS.md)

## 一、发布就绪度审查目标

本阶段旨在对 `dsh-solidworks` 插件的代码资产、打包清单、元数据一致性、合规许可证、路径脱敏与安全边界进行全景发布前审计，评估当前版本是否达到**受控 Alpha 开发者测试标准**。

**注意**：本轮严格遵守操作红线，不执行 GitHub Release 发布、不向远程 Git 仓库推送代码、不向任何插件市场提交审核，仅在本地完成合规与静态分析。

---

## 二、关键发布要素逐项审查

### 1. 元数据与版本号一致性 (DEF-03)
- `package.json`: `version = "0.2.0"`
- `dsh-plugin.json`: `version = "0.2.0"`
- `lib/index.js`: `export const version = pluginVersion` (解析为 `0.2.0`)
- **审查结论**：**100% 一致**（经 `tests/package.test.js` 自动断言通过）。

### 2. 知识产权与合规许可 (Licence & Notice)
- **许可证文件**：`LICENSE` (GNU Affero General Public License v3.0, AGPL-3.0) 完备齐备；
- **第三方开源致谢**：`NOTICE` 文件完备，准确记录了引用的上游组件（包括 `solidworks-automation-skill` 等 MIT 组件）的版权与文件计数；
- **源头溯源说明**：`PROVENANCE.md` 明确记录了依赖组件的来源仓库与提交哈希。

### 3. 文件打包白名单 (`package.json#files`)
- 打包白名单精确限定为核心运行时资产：
  `lib`, `bin`, `scripts`, `tests`, `vendor`, `docs`, `requirements.txt`, `cordis.patch.yml`, `dsh-plugin.json`, `LICENSE`, `NOTICE`, `PROVENANCE.md`, `README.md`。
- 不必要文件排查：
  - 临时编译字节码 `__pycache__` / `*.pyc`：**已彻底排除与清理**；
  - 临时测试产物：严格限制在 `tests/real_cad/sandbox/`，不随 npm 包分发；
  - 内部绝对路径：文档与代码中所有构建机路径已脱敏（经 `tests/package.test.js` 自动化防泄漏断言通过）。

### 4. 依赖项与运行环境清单
- **Node.js 侧**：无沉重外部 npm 运行时依赖，纯原生 ESM 与 Node 22/24 内置 API 实现，启动轻量敏捷；
- **Python 侧**：`requirements.txt` 精确声明核心依赖项：
  - `mcp>=1.0.0`
  - `pydantic>=2.0.0`
  - `pywin32>=306`

---

## 三、已知限制与风险边界提示

在向早期 Alpha 开发者分发前，必须在文档中明确告知以下已知限制：
1. **环境依赖硬性要求**：需要本地安装有已激活的 SolidWorks 桌面应用（2021–2026），且用户具有启动桌面进程的权限；
2. **多进程并发限制**：SolidWorks COM 接口是单实例单线程单元，不支持并发多任务调用，所有 CAD 请求必须由插件串行排队处理；
3. **P1 阶段 5 个新工具的策略可见性提示**：新增加的 `solidworks_identify_dimensions` 等 5 个工具在默认 `read-only` 策略下因 Zero-Trust 保底规则被识别为 `HIGH` 而隐藏；在 Alpha 测试中建议配置 `mode: standard` 或显式允许这 5 个工具以获得完整体验。

---

## 四、Alpha 发布就绪度综合判定

```
[发布检查门禁表]
1. 版本号一致性:         PASS (0.2.0 统一)
2. 许可证与法律声明:     PASS (AGPL-3.0 + NOTICE 齐备)
3. 打包文件白名单:       PASS (无冗余杂质)
4. 绝对路径脱敏:         PASS (0 泄漏)
5. 自动化测试套件:       PASS (Node 68 项 + Python 24 项全绿)
6. 异常降级免死机制:     PASS (具备 solidworks_status 自愈诊断)
```

**判定结论：【具备受控 Alpha 开发者测试就绪条件】**  
系统在本地集成、安全策略与可靠性层面已具备完整闭环，可以进入小规模定向开发者 Alpha 试用阶段。
