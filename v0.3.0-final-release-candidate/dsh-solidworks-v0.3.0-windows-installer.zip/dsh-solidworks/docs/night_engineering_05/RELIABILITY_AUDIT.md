# NIGHT-ENGINEERING-05 阶段六：可靠性与异常恢复能力审查报告 (RELIABILITY_AUDIT.md)

## 一、异常处理与系统韧性设计

工业级桌面自动化系统的核心考验在于面对不可预知的运行时故障时，系统能否具备“优雅降级、清晰报错、保护数据、杜绝死锁”的韧性表现。

---

## 二、关键异常场景实测与表现矩阵

| 序号 | 异常场景与触发条件 | 系统响应与处理机制 | 保护与恢复效果 | 验证状态 |
| :--- | :--- | :--- | :--- | :--- |
| 1 | **SolidWorks 未启动** | `sw_connect` 探测 ROT 运行对象表失败，捕获 COM 异常；若 `start_solidworks=False`，立即返回结构化错误。 | 明确提示“未找到运行中的 SolidWorks 实例，请启动桌面应用”，宿主不崩溃。 | **实机验证 (REAL_VERIFIED)** |
| 2 | **SolidWorks 启动超时** | 传入 `start_solidworks=True` 但在规定超时（默认 45 秒）内程序未就绪，抛出 `SolidWorksConnectionError`。 | 避免无限阻塞 Worker 线程，及时向 Agent 抛出超时说明。 | **实机验证 (REAL_VERIFIED)** |
| 3 | **MCP Server 启动失败 (缺失依赖)** | `lib/discover.js` 探针检查 `import mcp` 失败，`apply()` 捕获错误并进入降级运行。 | **宿主免死**：仅发布 `solidworks_status` 诊断工具，直接输出环境修复指导。 | **实机验证 (REAL_VERIFIED)** |
| 4 | **DSH 客户端断开 / 崩溃** | Node.js 宿主进程退出时触发 `client.close()`，清理管道并向子进程发送终止信号。 | Python 子进程随 stdio EOF 正常退出，无孤儿无头后台进程驻留。 | **实机验证 (REAL_VERIFIED)** |
| 5 | **Python 进程异常退出 / 崩溃** | Node.js `lib/mcp.js` 监听子进程 `exit` 与 `error` 事件；若在调用中崩溃，将错误码与 `stderr` 最后 10 行提取返回。 | 返回 `SERVER_UNAVAILABLE`，并保留 Python 崩溃堆栈以供排查。 | **代码与测试验证 (CODE_VERIFIED)** |
| 6 | **COM 调用超时 (长耗时重构)** | `lib/mcp.js` 与 `Policy` 设置单次调用超时（默认 300 秒），超时触发 AbortSignal。 | 终止等待，记录审计日志，防止 Agent 会话永久死锁。 | **测试验证 (TEST_VERIFIED)** |
| 7 | **活动文档意外关闭 / 类型不匹配** | 在工程图打开时调用零件特征工具，COM 返回空指针或类型错误，接口防御性检查拦截。 | 抛出结构化提示：“活动文档类型不匹配 (需为 .SLDPRT)”，杜绝段错误崩溃。 | **实机验证 (REAL_VERIFIED)** |
| 8 | **用户在对话中取消操作** | DSH 宿主发送 `AbortSignal`，`McpClient` 捕获后取消等待并在日志记录 `aborted`。 | 停止后续任务编排，保持当前文档状态。 | **测试验证 (TEST_VERIFIED)** |
| 9 | **Agent 重复调用高风险工具 (重放)** | Agent 试图复用此前的 `solidworks_confirm` 授权再次执行高风险保存。 | **防重放拦截**：首次调用已立即消费授权，第二次调用直接拒绝 (`CONFIRM_REQUIRED`)。 | **测试验证 (TEST_VERIFIED)** |
| 10 | **Agent 提供非法/畸形参数** | 传入负数尺寸（如 `radius = -10`）或非法类型参数，Pydantic Schema 或 `updates` 检查率先拦截。 | 直接抛出 `ValueError`，未触碰 CAD 引擎，底座模型零污染。 | **实机验证 (REAL_VERIFIED)** |

---

## 三、文档防破坏与数据安全机制评估

在 NIGHT-04 攻关成果加持下，插件已建立双重防脏化闭环：
1. **轻量级尺寸修改场景**：
   - 依托 [`vendor/.../scripts/dimension_manager.py`](file:///<WORKSPACE_ROOT>/DeepSeek%20Harness工作区/dsh-solidworks-plugin/vendor/solidworks-automation-skill/scripts/dimension_manager.py) 与 `ShadowBackupManager`；
   - 在写入前建立影子副本；
   - 遇到几何破损或 `EditRebuild3` 失败时，抛出 `DimensionUpdateError` 并**无损还原影子副本**。
2. **复杂工程建模编排场景**：
   - 依托 [`CADTaskRollbackManager`](file:///<WORKSPACE_ROOT>/DeepSeek%20Harness工作区/dsh-solidworks-plugin/vendor/solidworks-automation-skill/scripts/cad_task_context.py) 与 `FeatureCleanupManager`；
   - 遇求解异常自动执行 Level 3 特征树逆序物理删除，实体数与体积恢复为 0，初始基准面完好保留。

---

## 四、可靠性审计结论

- **异常识别与可读性报错**：**PASS**（结构化错误代码与业务提示，彻底摒弃 COM 原生晦涩数字错误代码）；
- **危险重放与非法参数拦截**：**PASS**（单次授权与 Pydantic 校验无死角）；
- **宿主崩溃免疫**：**PASS**（环境异常时自动降级发布诊断工具，不影响宿主主进程运行）；
- **数据与模型自愈**：**PASS**（双重真实回滚经过实机反向核验）。
