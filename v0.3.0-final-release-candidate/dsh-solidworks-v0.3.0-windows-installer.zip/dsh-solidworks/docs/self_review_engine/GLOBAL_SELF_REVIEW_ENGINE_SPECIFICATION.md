# dsh-solidworks 全局自我审查、自我诊断与自我修复系统技术规范与设计方案
# (Global Self-Review, Self-Diagnostics and Safe Self-Healing Engine Specification)

> **版本**：1.0.0-PROPOSAL  
> **状态**：研究与架构设计规范（只读设计，不修改生产代码）  
> **适用范围**：`dsh-solidworks` 跨平台 CAD 智能体全系统（草图、建模、工程图、装配体、参数化、MCP 与宿主全链路）

---

## 一、核心问题裁决与工程定位

针对任务书提出的最高核心问题，本方案给出严肃、客观、证据驱动的技术裁决：

### 1.1 当前项目是否已经具有真正的全局自我审查能力？
**裁决结论：尚未具备。**  
当前项目在前三阶段及极限工程攻关中，建立了一系列优秀的**局部专项检查与事后度量工具**（如 `ModelQualityInspector` 几何质量审查、`drawing_workflow` 图纸视图校验、`CADTaskRollbackManager` 逆序特征清理、`lib/policy.js` 权限网关）。然而，这些工具彼此孤立、接口各异、生命周期割裂，本质上是“离散的检查点”，而非“全局的审查系统”。

### 1.2 当前系统缺少哪些关键环节？
1. **统一审查协议（Unified Review Protocol, URP）缺失**：不同模块返回的数据结构极不一致（布尔值、自定义字典、状态码字符串、Pydantic 模型混杂），无法由系统级中枢进行统一研判；
2. **审查生命周期不完整**：严重依赖事后（Post-flight）检查，缺乏执行前（Pre-flight）的几何前置预测与执行中（In-flight）的 COM 死锁阻塞监控；
3. **审查独立性不足**：部分关键操作（如草图拉伸、装配配合、文件读写）仍然存在“以 API 返回非空或未抛异常即代表成功”的假定，缺乏脱离执行器的独立交叉核验物证；
4. **根因分析（RCA）能力匮乏**：发生错误时，系统多数直接透传底层 COM HRESULT（如 `0x80004005`）或输出粗粒度信息，无法自动定位到具体是哪个参数、哪个依赖实体或哪条制图标准被打破；
5. **自我修复缺乏安全分级与闭环控制**：现有修复多为局部即时重试或特征删除，缺乏“低/中/高风险分级、副作用探测、修复后重核验、防无限重试熔断”的完整安全闭环；
6. **质量历史与自愈回归断层**：缺少轻量持久化的质量缺陷账本，历史偶发故障无法沉淀为自动化回归用例。

### 1.3 怎样以最低风险建立完整体系？
**核心策略：采用“非侵入式审查适配器中枢（Non-invasive Review Adapter Hub）”架构。**
- **不重写既有模块**：不替代 `FeatureGraph`、`CADTaskContext`、`Policy Gateway` 或底层 CAD 建模函数；
- **分层挂接**：在 MCP 工具层与 STA 执行层之间植入全局审查中枢，各专业模块以标准化适配器（Review Adapter）形式插拔接入；
- **严格遵守零信任与安全边界**：审查引擎只负责“检查、诊断、建议与受控协调”，任何修复动作均通过原有的 Policy 授权与事务回滚管道执行，绝不绕过安全网关。

### 1.4 工程图作为首个落地适配器的定位
工程图（Engineering Drawing）业务链条长、标准严苛（GB/T 14689、GB/T 4458.1）、涉及三维到二维投影转换、视图排布防重叠、尺寸标注与字体图框碰撞等极高难度挑战，是检验审查独立性与自愈能力的绝佳试金石。**工程图必须作为第一个完整实现 Pre-flight / In-flight / Post-flight、根因诊断与安全微调修复的标准参考实现（Reference Implementation），并以此沉淀通用规范，逐步推广至其余 15 个模块。**

---

## 二、全系统 16 大模块自检能力清单与验证缺口矩阵

| 序号 | 核心模块 / 领域 | 当前已具备的自检与度量能力 | 关键验证缺口与结构性风险 | 独立验证方案 (消除“声明即成功”) |
| :---: | :--- | :--- | :--- | :--- |
| **1** | **草图 (Sketch)** | • `sw_sketch_quality.py` 检查草图闭合与自交；<br>• `GetConstrainedStatus` 读取欠定义/完全定义/过定义状态码。 | • 无法预警微小断线或悬空线；<br>• 未检测与基准原点的绝对定位距离；<br>• 缺少对绘制后图元被其它操作误修改的校验。 | 独立提取草图曲线拓扑（Curve Segments），回读边界顶点哈希并进行物理连通性验算。 |
| **2** | **三维建模 (3D Modeling)** | • `sw_measure.py` 读取体积、表面积、包围盒；<br>• `ModelQualityInspector` 检查长宽比与零体积。 | • 无法在成型前预测曲面相切收缩引起的实体分裂；<br>• 缺乏对极小退化面（Degenerate Faces）与自交面检测。 | 独立通过 `GetBodies2` 遍历实体，执行布尔流形核验（Manifold Verification）与欧拉示性数校验。 |
| **3** | **特征操作 (Feature)** | • `cad_graph_executor.py` 增加了对圆角/倒角返回值与 `GetErrorCode2` 校验。 | • 拉伸、切除、抽壳等众多基础特征仍存在直接放行；<br>• 特征警告标记（Warning Flags）未做语义降级处理。 | 通过特征管理器前置/后置差集（Feature Diff），读取每个新特征的拓扑面数与错误码。 |
| **4** | **几何测量 (Measure)** | • 能够计算包围盒尺寸跨度与质心坐标。 | • 依赖缓存数据，SolidWorks 未执行 ForceRebuild 时可能读出旧几何；<br>• 缺乏单位系混淆检测（米与毫米误配）。 | 调用 `ForceRebuild3(True)` 后提取网格数据（Tessellation），与解析积分体积进行交叉校验。 |
| **5** | **参数修改 (Dimension)** | • `dimension_validator.py` 验证数值范围与类型；<br>• `dimension_dependency_graph.py` 校验循环依赖。 | • 只验证了尺寸值已被写入，未验证几何实体是否产生了物理形变响应（可能因草图过约束未发生几何更新）。 | 修改前后比对实体的局部包围盒跨度与顶点坐标，确保几何产生符合导数预期的真实形变。 |
| **6** | **工程图 (Drawing)** | • `drawing_workflow.py` 校验视图数量与边界；<br>• `sw_review.py` 通过 PyMuPDF 检查矢量文字重叠。 | • 依赖静态边界框，未检测源零件处于关闭状态引发的静默投影失败；<br>• 缺乏剖面线与公差符号完整性检查。 | 导出矢量 PDF / 高清位图，离线重新打开 `.SLDDRW`，遍历图纸所有 Sheet 与 View 对象核实几何存在性。 |
| **7** | **装配体 (Assembly)** | • `sw_assembly.py` 支持组件插入与基础配合添加。 | • 缺乏配合冲突（Over-constrained）的自动诊断；<br>• 无装配体静态干涉检查（Interference Detection）。 | 调用 `InterferenceDetectionManager` 进行全局物理干涉扫描，核对各零件配合自由度（DOF）。 |
| **8** | **文件读写 (File I/O)** | • `sw_file_load.py` 检查文件存在性与扩展名；<br>• Policy 校验白名单与沙箱目录。 | • 保存后未进行文件指纹（SHA-256）与非空字节比对；<br>• 缺乏磁盘满、锁死、并发写入冲突预检。 | 落盘后执行物理读取与完整性校验，并调用独立静默加载接口验证文件可重开性。 |
| **9** | **FeatureGraph IR** | • `feature_graph_ir.py` 实现了静态拓扑排序与环检测。 | • 执行期未动态跟踪节点健康，前面的轻微几何偏差导致后续节点失效时无法溯源依赖链路。 | 建立动态节点执行追踪上下文，记录每个 Feature Node 输入/输出拓扑版本指纹。 |
| **10** | **MCP 工具暴露** | • `probe-server.mjs` 验证 71 项工具同构注册；<br>• Schema 包装层校验入参结构。 | • 只做语法校验，未做语义前置检查（如负深度、超大尺寸等合法类型但非法业务值的参数）。 | 工具层部署语义拦截器（Semantic Validator），在派发至 Python 前拦截逻辑矛盾入参。 |
| **11** | **COM / STA Worker** | • 单线程单元隔离 SolidWorks COM API；<br>• 具备桌面环境与进程存活探测。 | • 缺乏 COM 调用微秒级挂起/死锁探针；<br>• 弹窗阻塞时无法主动识别与脱困；<br>• 内存/句柄增长缺少动态熔断阈值。 | 引入看门狗心跳（Watchdog Heartbeat）与 GDI/内存监控器，超时阈值触发告警与优雅降级。 |
| **12** | **任务队列 (Queue)** | • `core/state.py` 维护了运行状态迁移白名单。 | • 队列缺乏持久化，崩溃后无法从中断点恢复任务上下文；<br>• 任务依赖未做 DAG 有向无环校验。 | 引入轻量级本地任务状态日志，记录原子操作执行序列与断点指纹。 |
| **13** | **超时与取消** | • Node 侧支持 AbortSignal 与超时定时器。 | • 操作系统无法强杀单线程中阻塞的同步 COM 调用；<br>• 强行取消易造成 SolidWorks 内部文档锁死。 | 建立两阶段取消协议：优先通知 CAD 任务取消标志位；若超时则触发隔离 Worker 优雅重启。 |
| **14** | **事务与回滚** | • `CADTaskRollbackManager` 支持 Level 3 逆序特征树物理回滚。 | • 仅覆盖单零件特征，未纳管工程图图纸页、装配体配合关系的跨文档联合事务。 | 扩展回滚管理器，引入多文档全局快照（Global Document State Snapshot）机制。 |
| **15** | **安全策略网关** | • `lib/policy.js` 具备三级权限、单次 Grant、白名单硬拦截。 | • 安全策略仅部署在 Node.js 宿主端，Python MCP 侧缺少二次防绕过护栏。 | 在 Python MCP 端设立双重策略镜像，对直接传入的参数做同构 Policy 防御。 |
| **16** | **DSH Agent 链路** | • 打通工具发现、自然语言调度与确认授权闭环。 | • Agent 判定任务成功完全依据工具返回的文本，无法独立判断用户高阶工程意图是否真正达成。 | 将 `VerificationResult` 结构化呈现给 Agent 决策核心，强化“意图达成度（Intent Fulfillment）”裁决。 |

---

## 三、统一审查协议规范 (Unified Review Protocol, URP)

全局审查引擎的所有输入、输出、监控事件与质量判定，必须统一遵循标准化数据结构，严禁自定义离散字典。

### 3.1 核心数据结构字段定义

```json
{
  "$schema": "https://dsh-solidworks.org/schemas/urp-v1.json",
  "task_id": "task_20261105_9f8e",
  "operation_id": "op_04_create_drawing_views",
  "target_object": {
    "type": "drawing_view",
    "name": "工程图视图1",
    "document_path": "tests/real_cad/sandbox/extreme_eng/extreme_shaft_drawing.SLDDRW"
  },
  "expected_state": {
    "view_count": 3,
    "views_must_include": ["front", "top", "right"],
    "overlap_free": true
  },
  "actual_state": {
    "view_count": 3,
    "views_found": ["*前视", "*俯视", "*右视"],
    "max_overlap_area_pt2": 0.0
  },
  "check_id": "CHK_DRW_PROJECTION_01",
  "check_method": "cross_reopen_and_pdf_ast",
  "result": "PASS",
  "severity": "CRITICAL",
  "evidence": [
    {
      "source": "native_drawing_doc",
      "metric": "view_count",
      "value": 3
    },
    {
      "source": "vector_pdf_parser",
      "metric": "text_collision_count",
      "value": 0
    }
  ],
  "confidence": "HIGH",
  "repairability": "NOT_REQUIRED",
  "recommended_action": null,
  "timestamp": "2026-11-05T22:30:15Z"
}
```

### 3.2 字段语义与取值规范
1. **`result`（审查结论状态）**：
   - `PASS`：证据充分且所有断言 100% 满足，绝对杜绝“缺乏证据当 PASS”；
   - `FAIL`：明确违反设计目标、机械规范或物理完整性，并伴有硬性物证；
   - `CONDITIONAL`：核心功能满足，但伴随非关键警告（如存在局部欠定义草图或次要标注重叠）；
   - `UNVERIFIED`：环境不支持（如缺少可选依赖）或调用被外部打断，缺乏充分证据；
   - `BLOCKED`：前置条件缺失（如源零件不存在或 CAD 挂起），审查无法继续开展。
2. **`severity`（严重等级）**：
   - `CRITICAL`：阻断性致命错误（模型损坏、零体积、实体分离、文件损坏）；
   - `MAJOR`：严重功能缺陷（尺寸超差、缺少关键特征、视图未生成）；
   - `MINOR`：轻微工艺或规范偏差（非关键图元未完全定义、标题栏微小错位）；
   - `INFO`：信息性统计与度量参考。
3. **`confidence`（置信度）**：
   - `HIGH`：由脱离执行器的独立第三方物理证据证实（如重新读取文件、PDF 几何分析、网格拓扑）；
   - `MEDIUM`：由 SolidWorks 原生只读 COM API 交叉比对得出；
   - `LOW`：仅来源于执行工具自身返回值或内存缓存。
4. **`repairability`（可修复性分级）**：
   - `AUTO_SAFE`：确定性、可逆、低风险错误，允许系统自动安全自愈；
   - `PLAN_REQUIRED`：中风险错误，需生成明确自愈计划并经过二次校验；
   - `USER_AUTH_REQUIRED`：高风险破坏性操作，必须上报 DSH 宿主请求用户确认；
   - `UNREPAIRABLE`：逻辑或环境物理不可修复，必须阻断报错并回滚。

---

## 四、全局自我审查引擎架构设计 (Global Architecture)

审查引擎采用分层解耦的流水线架构，涵盖 **Pre-flight（执行前预测）**、**In-flight（执行中监控）** 与 **Post-flight（执行后独立交叉验证）** 全生命周期。

```mermaid
flowchart TD
    User["DSH 宿主 / 用户意图"] --> IntentParser["设计意图与目标提取 (DesignIntentTarget)"]
    IntentParser --> PreFlight["【阶段一: Pre-flight】执行前审查"]
    
    subgraph PreFlightGroup ["Pre-flight 预测与环境核准"]
        PreFlight --> ChkEnv["环境与 CAD 状态探针 (cad_doctor)"]
        PreFlight --> ChkPolicy["Policy 零信任权限与沙箱审查 (policy.js)"]
        PreFlight --> ChkGeom["几何前置干涉与参数合法性预测"]
    end
    
    PreFlightGroup --> GatewayDecision{"Pre-flight 通过?"}
    GatewayDecision -- "否 (BLOCKED)" --> RejectOutput["阻断请求并输出明确前置原因"]
    GatewayDecision -- "是" --> TaskContext["初始化 CADTaskContext 事务与快照"]
    
    TaskContext --> InFlight["【阶段二: In-flight】执行期监控"]
    
    subgraph InFlightGroup ["In-flight 实时监控与熔断"]
        InFlight --> STAExec["STAWorker 隔离调用 SolidWorks COM API"]
        InFlight --> Watchdog["看门狗心跳探针 (COM挂起/弹窗/超时监测)"]
        InFlight --> MemMonitor["内存与 GDI 资源泄漏监控"]
    end
    
    InFlightGroup --> PostFlight["【阶段三: Post-flight】独立双通道核验"]
    
    subgraph PostFlightGroup ["Post-flight 独立交叉审查"]
        PostFlight --> IndepChannel["独立验证通道 (Independent Channel)"]
        IndepChannel --> MQI["全景质量检查器 (ModelQualityInspector)"]
        IndepChannel --> DrwReview["工程图/PDF 矢量拓扑检查器"]
        IndepChannel --> FileReopen["物理落盘与离线二次重新打开 (Re-open)"]
    end
    
    PostFlightGroup --> URPGen["生成统一审查协议数据 (URP Record)"]
    URPGen --> Judge{"综合判定 Result"}
    
    Judge -- "PASS" --> OutputSuccess["交付成果: 实体+工程图+质量评分卡片"]
    Judge -- "FAIL / CONDITIONAL" --> RCACore["【阶段四: 自我诊断】RCA 根因分析引擎"]
    
    subgraph DiagnosticGroup ["根因溯源与修复策略"]
        RCACore --> LocateError["精准定位: 操作->对象->参数->API->规则"]
        LocateError --> ClassifyRepair["可修复性分级 (L1 / L2 / L3)"]
    end
    
    ClassifyRepair --> RepairDispatch{"修复级别判定"}
    RepairDispatch -- "L1 (低风险自愈)" --> AutoHeal["自动安全修复 (如补全草图约束/重排尺寸)"]
    RepairDispatch -- "L2 (中风险重试)" --> PlanHeal["执行带副作用校验的修复计划"]
    RepairDispatch -- "L3 (高风险回滚)" --> RollbackMgr["触发 Level 3 逆序特征树物理回滚"]
    
    AutoHeal --> ReVerify["修复后重验 (Re-verification)"]
    PlanHeal --> ReVerify
    ReVerify --> Judge
    
    RollbackMgr --> QualityLedger["记录质量历史账本并上报用户"]
```

---

## 五、自我诊断与根因分析 (RCA) 引擎设计

当 Post-flight 核验未通过时，禁止仅输出“建模失败”或“生成工程图失败”等无价值结论，系统必须沿依赖拓扑进行七维精准归因：

### 5.1 根因溯源七维定位链
1. **定位操作（Operation）**：指明是在特征拉伸、切除、视图投影、尺寸修改还是保存阶段发生；
2. **定位对象（Target Object）**：精确到哪个草图（如 `草图2`）、哪个端面（如 `FACE at Y=40mm`）或哪个工程图视图（如 `工程图视图3`）；
3. **定位参数（Parameter）**：具体是哪个数值超差或方向错误（如 `direction=True` 导致反向内凹拉伸，或 `X=35mm` 超出曲面收缩边界）；
4. **定位阶段（Phase）**：确定是参数传入阶段、草图绘制阶段、COM 调用求解阶段、还是落盘持久化阶段；
5. **定位依赖（Dependency）**：指明由于哪个父特征（Parent Feature）的缺失或被破坏引发级联失败；
6. **定位 API 调用（API Call）**：记录直接失败的 COM 成员或 HRESULT（如 `Create3rdAngleViews2 returned False`）；
7. **定位违反规则（Rule / Standard）**：指明违反了哪项机械制图或 CAD 规范（如 GB/T 1095 键槽标准、SolidWorks 单实体流形准则）。

### 5.2 典型故障根因映射字典 (RCA Knowledge Base)

```mermaid
graph LR
    A["现象: 实体数 = 2 (分裂)"] --> B["直接原因: 筋板与主体未熔合"]
    B --> C["几何根本原因: 圆柱曲面远离对称面处凹缩，切线草图悬空脱开"]
    C --> D["修复方案: 垂直边伸入壁厚 X=28mm，使用 extrude_midplane 双向对称拉伸"]

    E["现象: 工程图视图数为 0"] --> F["直接原因: Create3rdAngleViews2 返回 False"]
    F --> G["生命周期根本原因: 源零件已被 close_document，COM 句柄无法静默读取几何"]
    G --> H["修复方案: 保持源零件在前台会话中处于打开状态，投影并保存后再协同释放"]

    I["现象: MQI 评分扣除 40分"] --> J["直接原因: 草图状态码为 2 (Underconstrained)"]
    J --> K["规范根本原因: 草图图元仅有坐标无几何关系，违反机械 CAD 完全定义标准"]
    K --> L["修复方案: 自动注入 sgFIXED 几何约束或调用 FullyDefineSketch"]
```

---

## 六、安全自我修复 (Self-Healing) 分级权限与闭环控制

严禁未授权修改用户模型，严禁通过降低标准或销毁错误证据制造虚假 PASS。所有自动修复必须严格分级并遵守 8 步闭环控制。

### 6.1 修复风险分级矩阵

| 风险级别 | 适用错误场景与行为特征 | 自动化策略 | 授权机制 | 副作用检查与熔断条件 |
| :---: | :--- | :--- | :--- | :--- |
| **L1 (低风险)**<br>Zero-Risk & Reversible | • 绘制图元后草图处于欠定义状态；<br>• 二维工程图尺寸重排与对齐；<br>• 中心线/中心标记（Center Mark）遗漏补齐。 | **全自动自愈** | 静默放行，记入审计日志 | 检查是否改变了零件宏观外形尺寸；若改变立即中止。 |
| **L2 (中风险)**<br>Plan-Gated Remediation | • 复杂零件筋板相切脱开（需自动扩展草图深入壁厚）；<br>• 视图因图纸尺寸溢出需微调比例（如 1:1 改为 1:2）；<br>• 尺寸微调后依赖特征重建失败。 | **受控计划自愈** | 生成清晰修复 Plan，内部 Policy 核准 | 严格限制单次任务最大重试次数（`MaxRetries = 2`），禁止无限重试。 |
| **L3 (高风险)**<br>Destructive & Rollback | • 破坏性物理回滚与特征删除；<br>• 覆盖已存在的磁盘文件；<br>• 尝试修改外部导入的未知零件。 | **严格阻断拦截** | 必须上报 DSH 宿主请求用户确认 (`solidworks_confirm`) | 若用户拒绝或超时，立即执行 Level 3 逆序清理并保持只读退出。 |

### 6.2 修复闭环 8 步规范 (Eight-Step Remediation Loop)
1. **保留原始失败现场（Preserve Raw Evidence）**：将当前失败模型几何参数、特征树快照及 URP 记录存盘，严禁覆盖或删除原始证据；
2. **记录根因与诊断结论（Log Root Cause）**：由 RCA 引擎输出七维根因结构体；
3. **生成确定性修复方案（Formulate Repair Plan）**：明确本次修复修改哪个参数、调用哪个 API，预期达到的几何目标；
4. **权限与风险等级审查（Verify Remediation Tier）**：校验当前修复是否处于允许的风险层级；
5. **执行原子修复操作（Execute Atomic Action）**：在受控事务内执行修改；
6. **副作用与不变量核查（Inspect Side Effects & Invariants）**：核实修复是否破坏了模型的其它不变量（如外形总长、原有孔位、物理体积）；
7. **重新运行全量核查（Re-run Full Verification）**：重新执行 Post-flight 独立核验通道；
8. **输出终态与更新历史（Commit Final State）**：更新质量账本，若修复成功标记为 `PASS (HEALED)`，若失败且达到重试上限则标记 `FAIL` 并触发彻底回滚。

---

## 七、轻量化结构化质量历史账本 (Quality Ledger)

为防止生成大量无序临时垃圾日志，系统设计轻量化、单一持久化质量账本：
`<SANDBOX_DIR>/quality_ledger.jsonl`

### 7.1 账本记录规范 (JSON-Lines 结构)
每行代表一次自检与自愈事件，格式如下：

```json
{"timestamp":"2026-11-05T22:35:10Z","run_id":"run_9f8e","module":"drawing","check_id":"CHK_DRW_PROJECTION_01","result":"PASS","healed":true,"heal_tier":"L1","root_cause":"source_part_closed_prematurely","action":"reopen_source_part_before_projection","duration_ms":214.5}
```

### 7.2 基于质量账本的自愈回归测试映射
1. **指纹去重（Deduplication）**：对于相同 `module` + `root_cause` 的问题，账本仅更新命中计数器（`hit_count`）与最后发生时间，避免日志膨胀；
2. **反向回归用例映射（Regression Test Mapping）**：
   - 账本中记录的每一个典型根因，自动对应到 `tests/regression/` 中的一条反向测试用例；
   - 每次代码提交或版本构建（`npm test`）时，自动重放这些历史踩坑场景，确保已知缺陷永不复发。

---

## 八、与现有系统的兼容性与架构边界定义

全局自我审查引擎严格遵循“单一职责与最小特权原则”，绝不越俎代庖：

```
+---------------------------------------------------------------------------------------+
|                                  DSH 桌面宿主 / 用户界面                               |
+---------------------------------------------------------------------------------------+
                                           │
                                           ▼
+───────────────────────────────────────────────────────────────────────────────────────+
|               lib/policy.js (安全网关层 —— 拥有绝对权限，决定“允许/拦截”)                |
+───────────────────────────────────────────────────────────────────────────────────────+
                                           │
                                           ▼
+───────────────────────────────────────────────────────────────────────────────────────+
|       Global Self-Review Engine (全局审查引擎 —— 拥有“核验、诊断与建议”权，无越权修改权)       |
|   ┌────────────────────────┐  ┌────────────────────────┐  ┌────────────────────────┐  |
|   │ Pre-flight Check Hub   │  │ In-flight Watchdog     │  │ Post-flight URP Hub    │  |
|   └────────────────────────┘  └────────────────────────┘  └────────────────────────┘  |
+───────────────────────────────────────────────────────────────────────────────────────+
         │                                   │                                   │
         ▼                                   ▼                                   ▼
+──────────────────+               +──────────────────+                +──────────────────+
|  FeatureGraph IR |               |  CADTaskContext  |                |  STAWorker COM   |
| (负责特征拓扑编译) |               | (负责事务状态机与 |                | (负责单线程底层  |
|                  |               |  Level 3物理回滚) |                |  SolidWorks调度) |
+──────────────────+               +──────────────────+                +──────────────────+
```

1. **不取代 `Policy Gateway`**：审查引擎不能越过 Policy 擅自放行写操作，需要授权的自愈动作必须再次向 Policy 请求 Grant；
2. **不取代 `FeatureGraph`**：审查引擎不负责重写拓扑树，仅对 FeatureGraph 编译后的节点可达性与错误码做独立评估；
3. **不取代 `CADTaskContext`**：破坏性回滚依然由 `CADTaskRollbackManager` 执行，审查引擎仅向事务上下文发出 `transition_to(TaskStatus.ROLLING_BACK)` 协调信号；
4. **不取代 CAD 专业算法**：具体的三维拉伸、切削、工程图投影算法依然由 `sw_part.py`、`drawing_workflow.py` 承载，审查引擎仅作为外部监听与裁判。

---

## 九、分阶段实施路线图 (Phased Implementation Roadmap)

```
2026-Q4                       2026-Q4+                      2027-Q1                       2027-Q1+
阶段 0: 架构与规范冻结   -->   阶段 1: 工程图适配器落地 -->   阶段 2: 建模与特征适配器 -->   阶段 3: 全系统闭环与看板
• 完成 URP 协议设计            • 首个完整落地适配器           • 草图/建模/特征操作集成       • 装配体/文件/任务集成
• 本规范文档正式发布           • 视图排布与重叠自愈           • 尺寸依赖形变双重核验         • DSH 桌面端质量看板卡片
• 只读研究与设计(已完成)       • 离线重开闭环自愈             • L1/L2 安全自愈闭环           • 质量历史账本回归套件
```

### 9.1 阶段 0：规范冻结与契约确立（当前阶段交付）
- **目标**：完成全系统自检能力盘点、确立统一审查协议 URP、设计全局审查架构、制定安全分级与回归策略；
- **交付物**：本规范文档（`GLOBAL_SELF_REVIEW_ENGINE_SPECIFICATION.md`），不改动生产代码。

### 9.2 阶段 1：工程图专业审查适配器落地（首个参考实现）
- **目标**：以工程图为突破口，完整实现 `DrawingReviewAdapter`；
- **具体工作**：
  1. 封装 `Pre-flight` 源零件状态预检，彻底根治因源零件关闭导致的空图纸问题；
  2. 实现基于 URP 协议的视图与尺寸文字重叠自动诊断；
  3. 接入 L1 级尺寸对齐（`AlignDimensions`）与视图间距微调安全自愈；
  4. 验证生成、导出、关闭、重新打开的物理全流程。

### 9.3 阶段 2：草图、建模与特征操作适配器集成
- **目标**：将审查中枢接入三维几何成型核心；
- **具体工作**：
  1. 封装 `SketchReviewAdapter`，实现草图欠定义自动补全（L1 级自愈）；
  2. 封装 `ModelingReviewAdapter`，实现圆柱曲面相切收缩防脱开预警（L2 级自愈）；
  3. 完善特征树错误码（`GetErrorCode2`）动态拦截与精确归因。

### 9.4 阶段 3：全系统闭环、回归套件与 DSH 看板呈现
- **目标**：打通装配体、参数化、文件 I/O 与 DSH 宿主前端，实现全链路覆盖；
- **具体工作**：
  1. 部署全局质量账本 `quality_ledger.jsonl`；
  2. 建立从历史失败到反向回归测试的自动化触发管线；
  3. 在 DSH 桌面端呈现包含“物理符合度、MQI 评分、自愈记录”的交互式质量卡片，达成工业级产品交付。
