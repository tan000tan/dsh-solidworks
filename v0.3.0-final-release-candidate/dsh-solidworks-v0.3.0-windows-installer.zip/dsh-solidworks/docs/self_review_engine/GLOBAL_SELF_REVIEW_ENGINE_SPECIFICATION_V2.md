# dsh-solidworks 全局自我审查、自我诊断与自我修复系统技术规范与设计方案 (V2 修订版)
# (Global Self-Review, Self-Diagnostics and Safe Self-Healing Engine Specification - Revision 2)

> **文档版本**：2.0.0-REVISED (基线修订版，原 V1 规范完整保留作为技术推演参照)  
> **审查基准**：严格响应对抗式独立终审意见与 ChatGPT 技术核查要求  
> **适用范围**：`dsh-solidworks` 跨平台 CAD 智能体全系统（草图、建模、工程图、装配体、参数化、MCP 与 DSH 宿主全链路）  
> **编制原则**：客观真实、代码核对、物理证据驱动、最高工程标准、严禁虚假判定  

---

## 一、重大技术裁决与 V1 规范核心缺陷修正

针对前期审查与 ChatGPT 独立核查提出的关键技术问题，本修订版（V2）作出严肃的技术核验与架构修正，明确彻底纠正以下七大缺陷：

### 1.1 修正草图自愈缺陷：严禁将任意欠定义草图自动施加固定约束 (`sgFIXED`)
- **历史缺陷分析**：在前期测试中，为了单纯满足 `ModelQualityInspector` 对草图完全定义（Fully Defined）的考核，出现了对欠定义草图图元全选并调用 `SketchAddConstraints('sgFIXED')` 的做法。这种做法在机械工程上属于“**伪定义**”——固定约束只是将草图图元在当前视口局部坐标系中的绝对坐标值强行锚死（Dead Coordinates），彻底切断了几何基元之间的几何关联与参数化驱动弹性。一旦后续需要通过尺寸修改（`DimensionModifier`）驱动零件变形，或者上游基准面与父特征发生微小位移，被锁死的草图将直接爆发严重的过定义（Over-defined）与几何求解崩溃。
- **V2 规范强制禁令**：
  1. **严禁在 L1/L2 自动修复策略中默认施加 `sgFIXED` 约束**；
  2. 草图自愈必须优先基于**几何关系推理**（推导水平、垂直、共线、同心、相切、重合）与**设计意图参数化尺寸驱动**；
  3. 若草图确实存在欠定义自由度（DOF > 0），必须通过结构化诊断输出自由度明细（如“圆心缺少水平定位尺寸”、“矩形右边界缺少宽度约束”），并在自愈策略中推荐添加显式参数化尺寸，严禁隐式坐标锁定；
  4. 绝对固定约束（`sgFIXED`）被严格归类为 **L3 级高风险修改**，仅限用户明确指令（如“锁死非参参考轮廓”）且经过 Policy Gateway 单次授权批准后方可执行，并在生成的物证中显著标明“该特征已丧失参数化重构能力”。

### 1.2 明确四类变更的 Policy 授权门禁与风险定级
V2 规范彻底摒弃“所有修改一刀切”的粗放划分，将系统内部的自我修复与模型变更细化为四类清晰的授权门禁：
1. **只读探测与审查度量 (Inspection)**：
   - 包含：草图拓扑提取、几何质量读取（`GetMassProperties2`）、特征树遍历、工程图图纸核验、日志审计；
   - 策略权限：`READ` 级；无需授权，可随时独立执行。
2. **非破坏性参数尺寸与排版微调 (Dimension & Layout Self-Healing)**：
   - 包含：驱动尺寸数值在公差范围内的微调、工程图三视图间距对齐（`AlignDimensions`）、图框边界安全缩进；
   - 策略权限：`WRITE` 级；在沙箱独立路径中自动放行并记录审计账本。
3. **几何拓扑与约束逻辑自愈 (Constraint & Topology Auto-Repair)**：
   - 包含：草图图元补充几何关系、缺失驱动尺寸注入、剖切线法向反向校正；
   - 策略权限：`WRITE / CONFIRMATION_REQUIRED` 混合级；若操作可能影响下游特征依赖，必须在事务日志中记录前置检查点（Checkpoint）。
4. **特征依赖重排、特征破坏性删除与物理回滚 (Feature Mutation & Rollback)**：
   - 包含：特征树逆序删除特征、布尔组合分离、草图删除重建、跨文档事务恢复；
   - 策略权限：`HIGH` 级；强制挂起执行并向 DSH 宿主请求单次绑定防重放 Grant（`solidworks_confirm` 鉴权），全程受 `CADTaskContext` 强事务守护。

### 1.3 重新论证欧拉示性数、网格离散体积与解析几何属性的适用条件与容差
- **广义欧拉-庞加莱公式在 SolidWorks B-Rep 中的适用边界**：
  - 经典多面体公式 $V - E + F = 2$ 仅适用于无通孔、无内腔的单一简单凸实体。
  - 对于通用机械零件，必须采用广义流形公式：
    $$V - E + F = 2(S - H) + 2P$$
    其中 $S$ 为连通外壳数（Shells，通常单一实体 $S=1$），$H$ 为贯穿孔数（Genus/Through-holes，如通孔、环形槽），$P$ 为封闭内腔数（Voids/Cavities）。
  - **SolidWorks B-Rep 特殊性**：SolidWorks 曲面几何（如圆柱面、圆锥面、旋转曲面）在底层拓扑内核中通常由纵向缝合边（Seam Edges）和退化极点（Poles）闭合。若审查器仅统计可见轮廓边，将导致 $E$ 与 $V$ 统计失真。因此，V2 规范规定：**拓扑流形合法性审查必须调用 SolidWorks 官方拓扑遍历接口（`IBody2.GetFaceCount()`, `IBody2.GetEdgeCount()`, `IBody2.GetVertexCount()`），且必须将亏格 $H$ 与内腔 $P$ 纳入验算方程，禁止无条件套用 $V-E+F=2$ 进行武断拦截。**
- **几何体积与质量属性的容差体系**：
  - **解析几何基准（Analytic B-Rep）**：SolidWorks COM API `GetMassProperties2` 计算的是精确解析体积分，理论误差 $< 10^{-6}\text{ mm}^3$。当审查器与解析基准（如圆柱、圆台、长方体的理论积分）比对时，**相对容差阈值设定为 $\delta \le 0.2\%$**（轴类实机实测相对误差仅 0.13%）。
  - **离散网格/三角面逼近基准（Tessellated Mesh）**：若通过导出 STL 或三角离散计算网格体积，由于曲面弦高差（Chordal Height）引起的“削角”效应，体积必然系统性偏小。对此类离散比对，**相对容差放宽至 $\delta \le 1.0\%$**，且必须在报告中声明采用了离散网格度量，禁止将网格误差与解析误差混淆。

### 1.4 澄清工具数量统计真相 (66 vs 68 vs 71 vs 73)
为消除历史报告中关于工具数量的混淆与争议，V2 规范通过代码实测与契约比对，给出完全精确的口径澄清：
| 工具数量统计口径 | 涉及组件 / 接口 | 具体构成与技术事实 |
| :---: | :--- | :--- |
| **66** | 旧版 `dsh-plugin.json` (v0.2.0 初期) | 历史遗留数字。当时未收录 P0.4/P1 批次新增的 5 个参数化核心工具（`execute_feature_graph`, `query_feature_graph`, `modify_dimension`, `read_dimension_tree`, `rollback_features`）。 |
| **68** | `npm test` 契约断言总数 | 测试套件通过总数：`policy.test.js` (27 项) + `mcp.test.js` (13 项) + `schema.test.js` (16 项) + `package.test.js` (12 项) = **68 项断言全部 PASS**。历史曾被误传为工具数。 |
| **71** | Python FastMCP 服务端 (`server.py`) | **服务端实际通过 `@mcp.tool()` 暴露的真实 CAD 底层工具总数**。包含 19 个只读工具、26 个修改工具、26 个高风险工具（19+26+26=71）。 |
| **73** | DSH 宿主前端完整暴露工具总数 | **Node.js 宿主向 DSH 桌面端呈现的全部可用工具**。由 Python 端的 71 个底层 CAD 工具 + Node.js 宿主特权元工具 2 个（`solidworks_confirm` 授权门禁、`solidworks_status` 进程探测）构成（71 + 2 = **73 项全量工具**）。`package.test.js` 已断言 `declared.length === 73`。 |

### 1.5 完善统一审查协议 (URP) 元数据字段
V2 规范对 URP 数据契约进行扩充，系统性加入 7 大核心元数据字段：
- `rule_version`: 审查规则版本标识（如 `GB/T-2024-v2.0`）；
- `validator_identity`: 审查器独立身份标识与防伪哈希（防止被测模块自我汇报）；
- `cad_version`: SolidWorks 宿主主版本与 Service Pack（如 `SolidWorks 2024 SP2.0`）；
- `unit_system`: 统一计量单位制（严格声明 `MMGS`，毫米-克-秒）；
- `tolerance`: 明确的绝对容差与相对容差配置（如 `{"rel": 0.002, "abs_len_mm": 0.01}`）；
- `evidence_independence`: 物证独立性评级（L1 内存句柄 $\to$ L2 独立 COM API $\to$ L3 物理落盘与离线重开 $\to$ L4 跨引擎/第三方交叉验证）；
- `reproducibility`: 可复现性保证参数（包含执行时间戳、环境快照哈希与无状态隔离标识）。

### 1.6 建立多层次验收模型：消除“局部 PASS 冒充整体交付”
V2 规范严格区分三个不同层次的状态评定：
1. **原子执行状态 (Atomic Execution Status)**：`SUCCESS` / `FAILED`。仅代表单次 COM API 或 MCP 工具调用未抛出未捕获异常。
2. **制品质量审查状态 (Artifact Quality Status)**：`VERIFIED` / `PARTIALLY VERIFIED` / `UNVERIFIED` / `BLOCKED`。由独立审查器依据 URP 协议核验模型几何、特征树、投影视图及持久化闭环后的物理判定。
3. **任务工程交付等级 (Task Engineering Delivery Level)**：严格对应工业成熟度标准：
   - **L1 (Connectivity)**: 进程连通与接口响应；
   - **L2 (Discrete Modeling)**: 基础特征无报错生成；
   - **L3 (Parametric Mod)**: 参数化尺寸联动与无损重构；
   - **L4 (Physical Closed-Loop & Rollback)**: 具备物理回滚保护、图纸离线重开且质量达标；
   - **L5 (DSH Host End-to-End)**: 宿主全流程打通，具备权限网关防护；
   - **L6 (Industrial Resilient Autonomous CAD)**: 具备自审、自诊断、受控自愈闭环，形成不可伪造的物证哈希链。
**原则声明：任何单一工具或局部的 `SUCCESS`，绝不能直接等同于制品的 `VERIFIED`，更不能跨级等同于工程交付的 `L6 ACCEPTED`。**

### 1.7 调整实施路线：随行融入，不阻塞第四阶段核心建模
V2 规范明确确立“**审查引擎作为伴生守卫，随行融入核心建模**”的实施原则：
- 不设立“等待全局自审引擎所有 16 个适配器全部开发完毕才允许开始建模”的阻断性前置条件；
- 全局自审引擎以**渐进式、敏捷式接入**，首先将建模必需的“草图约束合规性检查器”与“精确几何质量度量器”直接注入第四阶段开发流水线；
- 建模开发、自审接入与 DSH 链路验证三位一体同步推进。

---

## 二、统一审查协议 V2 规范 (Unified Review Protocol v2)

```json
{
  "$schema": "https://dsh-solidworks.org/schemas/urp-v2.json",
  "rule_version": "GB/T-2024-v2.0",
  "validator_identity": "urn:dsh-validator:cad-geometry:v2.1#hash-7a9f",
  "cad_version": "SolidWorks 2024 SP2.0",
  "unit_system": "MMGS",
  "tolerance": {
    "relative_volume_tol": 0.002,
    "absolute_linear_mm": 0.01,
    "angular_deg": 0.05
  },
  "evidence_independence": "L3_OFFLINE_REOPEN",
  "reproducibility": {
    "deterministic": true,
    "environment_hash": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    "timestamp_iso": "2026-11-06T00:15:00Z"
  },
  "task_id": "task_20261106_eng_04",
  "operation_id": "op_01_create_revolved_boss",
  "target_object": {
    "type": "part_feature",
    "name": "Boss-Revolve1",
    "document_path": "sandbox/extreme_eng/part_shaft.sldprt"
  },
  "verdict": "VERIFIED",
  "checks": [
    {
      "name": "sketch_constraint_check",
      "status": "PASS",
      "score": 100.0,
      "details": "草图完全定义，无自由度漂移，未施加死坐标固定约束 sgFIXED"
    },
    {
      "name": "manifold_topology_check",
      "status": "PASS",
      "score": 100.0,
      "details": "实体数为 1，拓扑流形闭合，广义欧拉公式检验通过 (V=16, E=24, F=10, S=1, H=0, P=0)"
    },
    {
      "name": "mass_properties_deviation",
      "status": "PASS",
      "score": 99.8,
      "details": "实测体积 128600.19 mm3 与理论解析值 128433.62 mm3 相对偏差 0.13%，优于 0.2% 容差上限"
    }
  ],
  "root_cause": null,
  "healing_plan": null
}
```

---

## 三、全局自审系统分级自愈控制矩阵 (Self-Healing Control Matrix)

| 自愈层级 | 允许的操作类别 | 典型触发场景 | 授权门禁机制 | 熔断与防震荡约束 |
| :---: | :--- | :--- | :--- | :--- |
| **L1 (微调自愈)** | ?视图间距等比例缩放；<br>?尺寸标注标注引线自动防重叠重排（`AlignDimensions`）；<br>?草图基元几何关系推导（水平/垂直/相切拟合）。 | 图纸标注文字轻微干涉、草图绘制存在微小角度倾斜误差（$<0.05^\circ$）。 | 引擎内部自动批准；记录质量账本日志。 | 最大尝试次数：**2 次**；若仍干涉，升级至 L2。 |
| **L2 (结构化自愈)** | ?根据设计规范补齐草图缺失的定位/尺寸驱动约束；<br>?调整特征草图内边深入实体内部（消除曲面相切收缩脱开）；<br>?修正工程图剖切方向（反转法向投影）。 | 草图欠定义（DOF > 0）、三维拉伸后实体意外分裂为多实体（Bodies > 1）。 | 需要 Policy Gateway 放行 `WRITE` 权限；自动生成修复差分说明。 | 最大尝试次数：**1 次**；若拓扑重构失败，立即触发 L3 回滚。 |
| **L3 (重构与回滚)** | ?绝对死坐标固定约束（`sgFIXED`）；<br>?删除失败特征并逆序回滚特征树；<br>?从影子物理备份中恢复原模型。 | 上游核心参数破坏性形变、特征严重相交报错、COM 几何内核死锁。 | **必须经 DSH 宿主前端由用户或 Agent 显式授权（签发 One-Shot Grant）**。 | **绝对禁止递归自愈**；回滚后立即置为 `RECOVERY_REQUIRED` 终止任务。 |

---

## 四、全局自审引擎在后续阶段的敏捷融入路线

```mermaid
flowchart TD
    subgraph S1 ["第 1 阶段：轻量验证核 (第四阶段即刻启用)"]
        K1["草图约束合规性检查器 (杜绝 sgFIXED 滥用)"]
        K2["B-Rep 解析质量属性实测核验器 (0.2% 容差)"]
        K3["特征级逆序物理回滚管理器接入"]
    end

    subgraph S2 ["第 2 阶段：工程图专业审查中枢 (重构专项)"]
        D1["Pre-flight: 源零件会话与几何拓扑强预检"]
        D2["In-flight: 投影生成微秒级看门狗心跳"]
        D3["Post-flight: 离线重开 + 矢量 PDF 拓扑重叠扫描"]
        D4["L1 级视图间距与尺寸标注自适应避让"]
    end

    subgraph S3 ["第 3 阶段：全系统质量总账本 (工业级闭环)"]
        H1["URP v2 契约全工具链沉淀"]
        H2["quality_ledger.jsonl 持久化与回归测试沉淀"]
        H3["DSH 桌面端可视化质量卡片与一键授权"]
    end

    S1 --> S2 --> S3
```

- **实施准则**：在当前任务中，第 1 阶段轻量验证核随第四阶段 CAD 核心建模直接启用，确保所有高难度建模实验均在 V2 自审协议守护下完成，彻底打消“为了做自审而停滞业务开发”的顾虑。
