# NIGHT-ENGINEERING-03 五级故障回滚与恢复机制专项审查报告 (ROLLBACK_AUDIT.md)

**审计代号**: NIGHT-ENGINEERING-03  
**审查模块**: `cad_task_context.py`, `dimension_modifier.py`, `cad_graph_executor.py`  
**审查重点**: 区分静态拦截与物理回滚、特征树删除、参数原位恢复与二次兜底保护  
**审计时间**: 2026-11-05  
**总体验收判定**: **[CODE VERIFIED with CRITICAL CONCEPTUAL CORRECTIONS] (参数恢复与二次保护真实有效；但历史报告存在将编译拦截混淆为物理回滚的严重概念包装)**  

---

## 一、五级回滚与恢复机制逐级解构矩阵

为消除“把静态校验包装为物理回滚”的模糊表述，本审计将系统中的回滚能力严格切分为五级物理边界：

```
Level 1: 编译前依赖/参数拦截  ── (零 CAD 操作，纳秒级内存校验)
Level 2: 运行过程中止与跳过  ── (阻断下游，模型停留在半成品)
Level 3: 特征树反向物理删除  ── (LIFO 选中并物理 DeleteSelection2)
Level 4: 参数原位数值恢复    ── (SetSystemValue3 原值写回 + 强制重构)
Level 5: 二次销毁与安全隔离  ── (强制不保存关闭文档 + 磁盘物理覆盖)
```

| 级别 | 机制名称 | 核心实现代码与入口 | 物理对 CAD 产生的影响 | 真实实机证据支撑 | 终审定性结论 |
| :---: | :--- | :--- | :--- | :---: | :---: |
| **Level 1** | **执行前静态依赖/参数拦截** | `DesignIntent.validate()`<br>`FeatureGraphIR.validate()` | **零影响**。完全在 Python 内存中由拓扑排序或数学包围盒抛出异常，SolidWorks 完全未感知。 | 充沛 (`tests/cad_task_planner_test.py`) | **属于静态预检，严禁称为回滚**。E17 实质仅属于此类。 |
| **Level 2** | **执行过程中止与级联跳过** | `cad_graph_executor.py`<br>`_execute_internal()` | **部分影响**。中途节点报错后停止执行，下游标记为 `SKIPPED`，模型残留已建好的健康特征。 | 充沛 (`real_cad_benchmark_suite.py` E09/E10) | **属于执行熔断与跳过，非回滚**。 |
| **Level 3** | **特征树反向物理删除** | `FeatureCleanupManager`<br>`.cleanup_features()` | **物理逆转**。逆序（LIFO）调用 `Feature.Select2` 并通过 `DeleteSelection2` 物理删除失败会话中已建特征。 | **证据不足**。仅在 Mock 单元测试中有模拟，E01-E18 基准套件中**无此项实机测试**。 | **代码已实现，但实机基准套件缺乏独立覆盖**。 |
| **Level 4** | **参数原位数值恢复** | `DimensionModifier`<br>`.modify_batch()` 异常恢复 | **物理恢复**。重建报错时取出 `before_snapshot`，通过 `SetSystemValue3` 写回原物理数值并重新重构。 | **充分验证** (`real_cad_ddg_stress_test.py` Gate-05) | **真正的原位物理恢复，验证充分**。 |
| **Level 5** | **二次销毁与安全隔离** | `CADTaskRollbackManager`<br>`close_document(save=False)` | **强行隔离**。在特征删除失败或模型坏死时，强制丢弃并关闭文档（`save_changes=False`），丢弃脏实体。 | **充分验证** (`tests/real_cad/real_cad_fault_injection_test.py`) | **终极兜底有效，有效保护了白名单文件**。 |

---

## 二、E17“虚假回滚”深度剖析

- **现象还原**:
  - 基准测试套件宣称：“E17 (Fault Injection & Automatic Rollback) 验证了故障注入与安全回滚，耗时 0.17ms，判定 PASS”。
- **穿透代码事实**:
  - `E17` 构建了孤立特征 `depends_on=["non_existent_sketch"]`。
  - 调用 `executor.execute(fg)` 时，执行引擎在第一阶段拓扑分析中发现节点依赖缺失，直接在 Python 进程抛出 `UndefinedDependencyError`。
  - 全过程耗时 0.174 毫秒，**未调用过任何 COM 接口，未向 SolidWorks 发送任何创建命令，未在特征树生成任何实体，更没有任何特征被反向删除**。
- **终审裁定**:
  - 将编译期参数预检（Level 1）命名为“故障注入与安全自动回滚 (Fault Rollback)”属于**明显的概念包装与不当定性**。
  - 该项测试仅证明了**“执行引擎具备前置依赖校验防御能力”**，完全未证明**“特征中途创建失败后的物理删除与特征树自愈能力（Level 3）”**。

---

## 三、回滚机制的核心缺陷与待加固点

1. **Level 3 特征物理删除的脆弱性**:
   - SolidWorks 特征之间具有复杂的父子关系（Parent-Child Relations）。若一个草图被后续多个凸台或切除特征吸收引用，逆序调用 `DeleteSelection2` 时极易弹出 SolidWorks 模态确认对话框（“是否同时删除吸收的特征？”），该对话框会直接卡死无无人值守的自动化脚本。
2. **缺乏特征树快照（Checkpoint）能力**:
   - 系统目前无法像 Git Commit 那样对特征树状态做纳秒级快照，当前仅通过记录新增特征名称列表进行逆向删除。一旦 SolidWorks 内部特征更名或被吸收，名称匹配即告失效。
3. **参数修改原位恢复的边界限制**:
   - Level 4 参数恢复目前仅适用于尺寸驱动（Dimension Drive）。若尺寸修改触发了拓扑结构的突变（例如孔完全跑出实体导致面消失），即使数值改回原位，丢失的拓扑面引用（Dangling Face ID）在 SolidWorks 内部可能无法自动修复，特征树依然会变黄变红报错。
