# NIGHT-ENGINEERING-03 COM 与 STA Worker 架构专项审查报告 (COM_STA_AUDIT.md)

**审计代号**: NIGHT-ENGINEERING-03  
**审查模块**: `vendor/.../scripts/sw_connect.py`, `cad_task_context.py`  
**审查重点**: STA 线程套间模型、跨线程 COM 传递、锁重入、资源泄露与并发安全边界  
**审计时间**: 2026-11-05  
**总体验收判定**: **[CODE VERIFIED with ARCHITECTURAL RISKS] (STA 单线程隔离设计方向正确，有效消除了多线程直调崩溃，但存在锁语义边界混淆、跨线程封送缺口与伪自愈隐患)**  

---

## 一、STA Worker 线程模型现状与设计机制

### 1. 线程拓扑结构
```
[外部调用者 / FastMCP 服务进程 (MTA / asyncio)]
                   │
                   ▼  (提交 WorkerTask)
┌────────────────────────────────────────────────────────┐
│  DesktopPinnedStaWorker                                │
│  - 永久钉扎在 Windows Interactive 'Default' 桌面       │
│  - 独立专用线程，初始化调用 pythoncom.CoInitialize()   │
│  - 队列式顺序串行执行 WorkerTask                        │
│  - 内部生命周期锁: threading.RLock()                   │
└──────────────────┬─────────────────────────────────────┘
                   │ COM 调用 (win32com.client)
                   ▼
┌────────────────────────────────────────────────────────┐
│  SolidWorks 进程 (SLDWORKS.exe, Out-of-Process COM)    │
└────────────────────────────────────────────────────────┘
```

### 2. 核心源码审查 (`sw_connect.py`)
- **STA 初始化**: 专有线程启动时显式调用 `pythoncom.CoInitialize()`，退出时调用 `pythoncom.CoUninitialize()`。
- **任务分发保护**: `get_com_member` 在检测到 `threading.current_thread() != worker._thread` 时，将调用封装为 Lambda 表达式推入 `worker.execute()`，强制在 STA 线程内部执行。

---

## 二、六大专项架构安全审查

### 1. 所有 SolidWorks COM 调用是否都在正确的 STA 线程执行？
- **审查结论**: **[大部分合规，部分历史脚本存在旁路泄漏]**
- **证据与分析**:
  - `cad_graph_executor.py` 与 `dimension_modifier.py` 的顶层调度均通过 `worker.execute` 运行，核心 COM 访问收敛于 STA 线程。
  - **旁路隐患**: 在历史工具库（如 `vendor/solidworks-automation-skill/scripts/` 下的部分历史小工具，如 `sw_document_data.py`）中，仍存在直接调用 `win32com.client.Dispatch` 或裸调用属性的代码，未被全局拦截器统一包裹。如果在非主线程直接调用这些历史工具，仍可能破坏 STA 约束。

### 2. 是否存在跨线程传递 COM 对象的风险？
- **审查结论**: **[存在隐式缺陷，缺乏显式 COM 接口封送机制]**
- **证据与分析**:
  - 在标准的 Windows COM 规范中，跨线程套间传递 COM 接口指针必须通过 `CoMarshalInterThreadInterfaceInStream` / `CoGetInterfaceAndReleaseStream` 进行封送（Marshaling）。
  - 目前代码中，部分调用将外部线程持有的 `model`（COM Dispatch 对象）作为参数直接传入 `worker.execute(lambda: ...)`。虽然在部分简易 IDispatch 调用中操作系统会提供默认伪封送，但在遇到复杂非自动化接口（如工程图视图对象、非双重接口）时，极易触发 `RPC_E_WRONG_THREAD (0x8001010E)` 或导致 RPC 调用挂死。
  - **历史教训佐证**: Gate-07/08 中工程图生成挂死 54 分钟的根本原因，正是因为闭包捕获了跨线程的 `self.sw`，最终依靠“在 Worker 内部重新调用 `connect_solidworks()`”才临时绕过。这表明系统缺乏系统性的 COM 接口流封送保障。

### 3. RLock 是否被错误地当成了外部线程安全保证？
- **审查结论**: **[存在概念混淆与锁范围局限]**
- **证据与分析**:
  - 代码中将 `self._lifecycle_lock = threading.Lock()` 改为了 `threading.RLock()`，解决了同一个线程在自愈重启时自锁死锁的问题。
  - **严重误区**: `RLock` 仅仅是 Python 进程内的**线程重入互斥锁**，它**绝对不能**保证外部 SolidWorks COM 进程的事务安全！
  - 当 SolidWorks 进程发生阻塞（如弹出未处理的模态保存确认窗、几何求解死循环、操作系统 DCOM RPC 挂起）时，`RLock` 完全无能为力，整个 STA Worker 线程依然会永久阻塞，导致后续所有请求堆积并触发超时熔断。

### 4. Worker 异常退出后能否真正实现“可靠自愈”？
- **审查结论**: **[伪自愈风险：可能残留僵尸线程与孤儿进程]**
- **证据与分析**:
  - 代码在 `_ensure_worker_alive()` 中检测到线程停止时会尝试启动新线程。
  - **缺陷**: 若 Worker 线程是因为 COM RPC 阻塞而卡死（线程并未终止，但处于无限等待），`thread.is_alive()` 依然返回 `True`！此时系统无法感知 Worker 已经实质性僵死，无法自愈，也不会创建新 Worker，后续所有 `worker.execute()` 将全部超时崩溃。

### 5. 是否存在 COM 代理与文档引用未释放的问题？
- **审查结论**: **[存在依赖 Python GC 的非确定性延迟释放风险]**
- **证据与分析**:
  - Python 没有类似 .NET 的 `Marshal.ReleaseComObject(obj)` 显式确定性释放机制，COM 对象的生命周期完全依赖 Python 变量的引用计数与周期性垃圾回收（GC）。
  - 在复杂特征遍历和尺寸内省中，大量局部变量（如 `dim_obj`, `feat_obj`, `sub_feat`）在函数返回前未显式赋 `None`。如果由于内部闭包或异常追踪栈（traceback）保留了这些局部帧，底层 COM 引用计数将无法归零，导致 SolidWorks 内部虽然执行了 `CloseDoc`，但文档由于仍有外部 COM 引用存活而在内存中处于“幽灵驻留”状态。

### 6. 最终架构防线评估
- 当前 STA Worker 能够满足单用户单线程顺次调度的开发与测试场景；但在面向生产级的高并发、网络波动、长程无人值守时，仍需引入独立的**外部看门狗守护进程（Out-of-Process Watchdog）**与进程级硬 Kill 重启机制。
