# NIGHT-ENGINEERING-03 源代码与文件变更深度审查报告 (CODE_AUDIT.md)

**审计代号**: NIGHT-ENGINEERING-03  
**审查基准**: NIGHT-ENGINEERING-02 交付源码与 `FILE_CHANGE_LEDGER.md`  
**审查方式**: 源码级静态分析、AST 语法树穿透审查、接口签名与调用链追踪  
**审计时间**: 2026-11-05  
**总体验收判定**: **[CODE VERIFIED] (核心算法与架构代码真实完备，存在局部双轨技术债务与数量描述偏差)**  

---

## 一、核心被审模块物理属性与指纹清册

| 文件物理相对路径 | 文件大小 (Bytes) | SHA256 指纹 | 顶层关键类与核心函数 | 对应工程任务 | 存在性 |
| :--- | :---: | :---: | :--- | :---: | :---: |
| `vendor/.../scripts/cad_graph_executor.py` | 38,355 | `f621ebb7ffd2f3791f49a27d065fe5457314591959f494c91558c6a529d4d475` | `CADGraphExecutor`, `ExecutionResult`, `NodeExecutionRecord` | TASK-02/05 | 真实存在 |
| `vendor/.../scripts/cad_task_planner.py` | 17,101 | `68b62314b986e87177a5f097d4dc3d5f974a47d42313953054912d5ba8e696f4` | `CADTaskPlanner`, `IntentValidationError` | TASK-04 | 真实存在 |
| `vendor/.../scripts/design_intent.py` | 10,321 | `7a9029abc33fd893a8caac134bf6f55b993402a7ccfd43318495e38a782a4abb` | `DesignIntent`, `BasePlateIntent`, `HoleIntent`, `BossFeatureIntent` | TASK-04 | 真实存在 |
| `vendor/.../scripts/dimension_dependency_graph.py` | 13,019 | `1da8b22ea5b413e00882e701c79f7aba28f71293f8853e6855215819bd08e060` | `DimensionDependencyGraph`, `DDGEdge`, `DDGImpactReport` | TASK-07 | 真实存在 |
| `vendor/.../scripts/dimension_modifier.py` | 11,100 | `f84c8c29b02904602a196b48808e88e941e2f53e87a54a3593046a3825826d64` | `DimensionModifier`, `ModificationResult`, `ModificationDetail` | P1 / Gate-05 | 真实存在 |
| `vendor/.../scripts/dimension_reader.py` | 8,104 | `60a9d8c0fe2f801d321a7b6e4292734645ae59c40cf1a1e65ead2cc529334abe` | `read_model_dimensions`, `walk_all_features`, `infer_dimension_type` | P1 / Gate-05 | 真实存在 |
| `vendor/.../scripts/dimension_resolver.py` | 10,583 | `7f4e90b8a8cf0b63d4a4b775ca61a4577d633c39dbf80792a6fd24c5ce98d6f6` | `DimensionResolver`, `ResolutionResult`, `ResolvedDimensionTarget` | P1 | 真实存在 |
| `vendor/.../scripts/dimension_validator.py` | 5,984 | `dbe004c7909ccf067403debbc31a78bab1a868b50f97aaa925d195d0143196f0` | `DimensionValidator`, `DimensionValidationReport` | P1 | 真实存在 |
| `vendor/.../scripts/model_quality_inspector.py` | 13,863 | `1c7801e51315feabdf1e0b99d6d3ecfffe8641bf429ff17c421ffd05e7ab6828` | `ModelQualityInspector`, `MQIReport`, `MQIDeduction` | TASK-09 | 真实存在 |
| `vendor/.../scripts/model_rebuilder.py` | 6,457 | `befca560e56b6f26a535eb9d61d9bf617cb4e9176a1d4e2f52a1d78fa46d778c` | `ModelRebuilder`, `RebuildReport` | P1 | 真实存在 |
| `vendor/.../scripts/cad_task_context.py` | 34,134 | `e740b4277ec90e9ebb15f0b8837992aaca270e60f6b969e24c40558b3c066fe4` | `CADTaskContext`, `CADTaskRollbackManager`, `RollbackResult` | TASK-08 | 真实存在 |
| `vendor/.../scripts/feature_graph_ir.py` | 11,156 | `8f3e5ccfd8f1809919f571d13b742d51db7865cfb16dcc4b172a7a96b05d5777` | `FeatureGraphIR`, `FeatureNode`, `FeatureType` | P0.4/TASK-06 | 真实存在 |
| `vendor/.../scripts/sw_connect.py` | 27,272 | `6067b5871221b6d17df7ea955f2d65028aa6ce8d28c31cb86807869389270104` | `DesktopPinnedStaWorker`, `close_document`, `get_com_member` | TASK-08 | 真实存在 |
| `vendor/.../scripts/sw_drawing.py` | 993 | `5f0b88c1f03bb7efc75ff3bb895e7b5a889fa6e5b22572b83c5e886d34e6f477` | 动态转发桥接层 (Shim) | TASK-09 | 真实存在 |
| `vendor/.../mcp-server/server.py` | 51,570 | `c8ca27181f08cb6706e23ca754bf2b498f3c39fe3d289aa894458dfae24c96e6` | 66 个标准 `@mcp.tool` 注册函数 | 协议集成 | 真实存在 |
| `lib/discover.js` | 9,012 | `819864cb69b5e622d4a107acadd7e3b18481e2efea2a4d4fe5b052b0cf975bd2` | Python 运行时发现器 (DEF-01) | 产品化 | 真实存在 |
| `lib/index.js` | 14,805 | `b75b31af923b82dd26ead7b125ba9169a368cc57d7c03bc2e319aedc28a14480` | 插件入口与生命周期管理 (DEF-03) | 产品化 | 真实存在 |
| `lib/policy.js` | 18,819 | `c6060c555d2f68dea5c0c88d61ab2e3fa0d36ff0c49b47d1af0c1872bcbbe789` | 安全策略评估器、路径白名单规范化 | 安全基座 | 真实存在 |

---

## 二、关键模块深度实现审计

### 1. 特征图执行引擎 (`cad_graph_executor.py`)
- **拓扑排序与依赖规划**: 实现了严格的 Kahn 算法拓扑排序，并在执行前执行前置校验，对环路与缺失前置报错拦截。
- **草图与特征命名绑定**: 在特征生成时显式设置实体名称（如 `BaseSketch`, `BaseBoss`），支持下游特征通过依赖映射表反查上游几何引用。
- **高级特征支持**: 增加了 `REVOLVE_BOSS`（旋转凸台，支持以草图构造线作为旋转轴）与 `LINEAR_PATTERN`（线性阵列特征调度），代码逻辑完整且非空桩。

### 2. 意图解析与规划器 (`cad_task_planner.py` & `design_intent.py`)
- **反例拦截严苛性**: `DesignIntent.validate()` 实现了 6 类几何与工艺反例审查：
  1. `NEGATIVE_DIMENSION`: 负尺寸与零尺寸拦截；
  2. `OUT_OF_BOUNDS`: 孔位中心与半径超出基板包围盒物理越界拦截；
  3. `EDGE_MARGIN_VIOLATION`: 孔边到基板边界余量不足安全余量拦截；
  4. `HOLE_OVERLAP`: 孔与孔之间物理自交重叠拦截；
  5. `ASPECT_RATIO_EXTREME`: 基板长宽比畸变（$> 10.0$）拦截；
  6. `THICKNESS_DISPROPORTION`: 厚度与基板平面尺度严重失调拦截。
- **DAG 自动编译**: 审查通过后，自动将结构化意图编译为强类型的 `FeatureGraphIR`。

### 3. 原位尺寸参数驱动体系 (`dimension_modifier.py` 等)
- **真原位 vs 伪参数化审查**:
  - 经深入代码审计，`DimensionModifier` **绝非**删除特征重新建模。
  - 核心驱动链条：`Parameter(dim_name)` $\to$ 检查 `DrivenState != 1` (排除从动尺寸) $\to$ `SetSystemValue3(val_m, 1, None)` 写入物理米制数值 $\to$ 调用 `ModelRebuilder.rebuild(force_all=True)` 触发 `ForceRebuild3` 并检查实体数 $\to$ 回读 `SystemValue` 验证更新结果。
- **参数级事务回滚**: 修改失败时，从内存快照中取出原始数值 `before_snapshot`，再次调用 `SetSystemValue3` 并强制重建，确保模型不留脏状态。

### 4. 2D 工程图生成实现 (`sw_drawing.py`)
- **架构穿透审计发现**:
  - `vendor/.../scripts/sw_drawing.py` 本身仅有 29 行，是一个动态兼容转发桥接层。
  - 实际完整的工程图自动化实现位于：`vendor/.../subskills/solidworks-engineering-drawing/scripts/drawing_workflow.py`，代码量达 **2039 行**。
  - 核心实现包含了图纸规范选择（A4-A0）、主/俯/左/轴测视图投影生成、`InsertModelAnnotations3` 尺寸标注导入、自动对齐排列及 `.SLDDRW` 落盘，具备完整的工业级实现深度。

### 5. FastMCP 服务端工具注册审计 (`server.py`)
- **工具数量核查与数字偏差澄清**:
  - AST 穿透解析 `server.py`，共有 **66 个** `@mcp.tool` 注册函数。
  - 插件原生注册 Meta Tools（位于 `package.test.js` 和 `dsh-plugin.json`）：`['solidworks_status', 'solidworks_confirm']`（2 个）。
  - 两者合计受控工具总数为 **68 个**。
  - **终审纠偏**: 上一轮交付报告（`GATE_01.md` 与 `FINAL_REPORT.md`）中多处提及“穿透审计 71 个 MCP 工具”，经本次代码物理清查，实际注册工具数为 66 个（加 Meta Tools 为 68 个）。71 为过往早期计划草案残留的夸大表述，需在交付决算中予以正式更正。

---

## 三、代码债务与架构隐患分析

1. **新旧尺寸模块双轨并存 (Dual-Track Dimension Managers)**:
   - 系统中同时保留了历史模块 `dimension_manager.py` (325 行) 与全新 P1 尺寸体系 (`dimension_modifier.py` 等)。
   - `server.py` 中历史接口 `solidworks_update_dimension` 调用旧模块，而高级接口 `solidworks_modify_dimension_safe` 与新基准测试调用新模块。两套逻辑并存，未来存在维护分歧风险。
2. **`sw_drawing.py` 动态跨目录寻址依赖**:
   - `sw_drawing.py` 通过 `importlib.util.spec_from_file_location` 相对路径动态加载子技能脚本。若打包过程中漏发 `subskills/` 目录，该模块将立即抛出 `ImportError`。
3. **`RollbackResult` 早期未布尔化引发的序列化风险**:
   - 之前在 `cad_task_context.py` 中 `cleanup_verified` 返回了 `RollbackResult` 对象，导致在 `json.dumps` 时抛出 `TypeError`。当前虽然在 `server.py` 增加了 `default=str` 兜底，但底层应进一步统一返回基础数据类型（Primitive Types）。
