# NIGHT-ENGINEERING-03 终审证据矩阵总表 (EVIDENCE_MATRIX.md)

**审计代号**: NIGHT-ENGINEERING-03  
**评定基准**: 严格证据分级标准（`VERIFIED`, `PARTIALLY VERIFIED`, `CODE VERIFIED`, `MOCK VERIFIED`, `UNVERIFIED`, `FAILED`）  
**审计时间**: 2026-11-05  
**矩阵汇总**: 共核验 17 项核心工程能力，其中 **VERIFIED: 8 项**，**PARTIALLY VERIFIED: 5 项**，**UNVERIFIED: 4 项**，**FAILED: 0 项**。  

---

## 一、十七项关键工程能力证据矩阵

| 序号 | 核心工程能力 | 终审定性评级 | 关键真实证据支持 | 证据缺口与定性依据 |
| :---: | :--- | :---: | :--- | :--- |
| **01** | **基础建模 (Basic Modeling)** | **VERIFIED** | E01, E02, E04 实测体积与解析理论值误差 $< 10^{-6}\text{ mm}^3$；沙箱实体存在。 | 无。几何测量与模型落盘双闭环。 |
| **02** | **高级特征 (Advanced Features)** | **VERIFIED** | E03 旋转凸台与 E05 线性阵列真实落盘于 `e03_revolve.SLDPRT`, `e05_linear_pattern.SLDPRT`。 | 无。构造线驱动与阵列特征健康度 100%。 |
| **03** | **FeatureGraph DAG (DAG Execution)** | **VERIFIED** | E09 (6级长链) 与 E10 (双支柱汇聚) 实体落盘，Kahn 拓扑排序与参数继承按序执行。 | 无。特征拓扑结构正确。 |
| **04** | **尺寸发现 (Dimension Discovery)** | **VERIFIED** | E12 遍历读取物理尺寸捕获 3 个参数，`dim.FullName` 解析严格消除吸收草图别名。 | 无。物理尺寸回读正确。 |
| **05** | **参数化修改 (Parametric Modification)** | **VERIFIED** | E13 原位调用 `SetSystemValue3` 驱动 `ForceRebuild3` 重建，体积更新精准吻合。 | 无。彻底告别“重建模冒充参数修改”。 |
| **06** | **连续修改 (Consecutive Modifications)** | **VERIFIED** | E14 连续 5 步步进修改；Gate-05 20 轮大跨度高压连续参数驱动 100% 成功，零非受控参数漂移。 | 无。多次重建特征树无损坏。 |
| **07** | **失败恢复 (Failure Recovery)** | **PARTIALLY VERIFIED** | 参数修改失败时原值原位回写恢复验证充分；二次保护强制关闭未保存文档验证充分。 | 特征创建中途求解崩溃后的特征树反向自愈缺乏实机用例支撑。 |
| **08** | **物理回滚 (Physical Feature Rollback)** | **UNVERIFIED** | `cad_task_context.py` 中有反向 `DeleteSelection2` 代码实现。 | **【重大缺口】** E17 实质为编译期前置拦截（耗时 0.17ms），缺少真实实机物理删除回滚证据。 |
| **09** | **STA/COM 生命周期 (STA/COM Lifecycle)** | **PARTIALLY VERIFIED** | `DesktopPinnedStaWorker` 单线程套间运行，解决多线程直调崩溃；内部升级 `RLock`。 | 缺乏显式跨线程 COM 接口流封送；Worker RPC 阻塞时无法自愈且易掩盖死锁。 |
| **10** | **MQI 质量审查 (MQI Inspection)** | **VERIFIED** | E15 成功输出可制造性得分 97.0，等级 A；7 项工程规则严密打分。 | 无。模型质量指标完整。 |
| **11** | **工程图生成 (2D Drawing Automation)** | **PARTIALLY VERIFIED** | `e16_drawing.SLDDRW` (87.4 KB) 等 3 份图纸真实落盘，生成了三视图与轴测图并导入标注。 | **【缺口】** 缺少保存后独立的 Re-open（重新打开）校验与高分辨率视觉渲染可读性证据。 |
| **12** | **FastMCP 协议集成 (MCP Integration)** | **VERIFIED** | `real_cad_mcp_dialogue_test.mjs` 通过真实 stdio 管道完成建模 $\to$ 测量 $\to$ 修改 3 轮完整闭环。 | 无。JSON-RPC 2.0 双向传输契约完备。 |
| **13** | **DSH Agent 端到端调用 (Agent E2E)** | **UNVERIFIED** | 规则规划器与反例校验代码就绪；MCP 工具清单完备。 | **【缺口】** 当前为脚本预设调用，缺少真实 DSH 桌面环境中大模型动态决策调用的实测证据。 |
| **14** | **测试稳定性 (Test Stability)** | **PARTIALLY VERIFIED** | Node.js (68/68) 与 Python 离线 (51/51) 持续绿灯，无构建机路径泄漏。 | **【瑕疵】** E07 存在弱断言（倒角未成依然 PASS），E11 存在质心偏移未校正。 |
| **15** | **资源管理 (Resource Management)** | **PARTIALLY VERIFIED** | E18 测得短周期 3 轮文档关闭净增量 $\Delta=0$；白名单受保护文件完好。 | **【缺口】** 3 轮样本量过轻，不能等同于工业级长程无 COM 句柄与物理内存泄漏。 |
| **16** | **发布包完整性 (Packaging Integrity)** | **VERIFIED** | `package.test.js` 12 项断言全过，NOTICE 190 个 vendored 文件严格吻合，零路径泄漏。 | 无。打包规范性达标。 |
| **17** | **长期运行可靠性 (Long-term Reliability)** | **UNVERIFIED** | 188s 基准测试与短周期压力测试通过。 | **【缺口】** 尚未进行过跨数小时、数千次调用的连续无人值守实机耐力可靠性压测。 |

---

## 二、评级统计与质量成熟度裁决

```
┌────────────────────────────────────────────────────────┐
│  VERIFIED (充分核验)        : 8 项 (47.1%)             │
│  PARTIALLY VERIFIED (部分核验): 5 项 (29.4%)             │
│  UNVERIFIED (缺少证据)       : 4 项 (23.5%)             │
│  FAILED (明确失效)          : 0 项 (0.0%)              │
└────────────────────────────────────────────────────────┘
```
- **核心结论**: 系统在**底层工业 CAD 几何成型、原位参数化驱动、FastMCP 协议管道与打包规范**上具备坚实、高度可信的物理证据；但在**物理特征回滚（E17 概念纠偏）、工程图重新打开验证、COM 长程抗死锁韧性与上层 Agent 全自主闭环**上仍有明确的证据缺口需要下一阶段专项补齐。
