# NIGHT-ENGINEERING-03 全链路端到端调用链分层审计报告 (END_TO_END_AUDIT.md)

**审计代号**: NIGHT-ENGINEERING-03  
**审查重点**: 区分 Python 单元调用、Node.js 契约、FastMCP 协议、DSH 插件发现与 DSH Agent 自主交互  
**审计时间**: 2026-11-05  
**总体验收判定**: **[PARTIALLY VERIFIED] (底层 Python 核心、Node.js 策略与 FastMCP 协议管道真实打通；但上位 DSH Agent 自主决策与自然语言全闭环缺乏实境证据)**  

---

## 一、七层调用链路解构与证据矩阵

为严格防范将“协议连通性”或“脚本预设调用”偷换为“Agent 端到端自主闭环”，本审计确立七层调用链判定标准：

```
Level 7: DSH Agent 全自主自然语言端到端闭环    ── [UNVERIFIED] (需真实宿主桌面环境)
Level 6: DSH Agent 动态自主决策与工具编排      ── [UNVERIFIED] (当前为脚本预设)
Level 5: 自然语言设计意图结构化转译            ── [PARTIALLY VERIFIED] (规则规划器代码在)
Level 4: DSH 宿主插件与工具发现规范            ── [VERIFIED] (符合 DSH v0.15 规范)
Level 3: FastMCP JSON-RPC 2.0 协议管道通信     ── [VERIFIED] (stdio 真实管道三轮往返)
Level 2: Node.js 策略评估与权限拦截            ── [VERIFIED] (68/68 测试全绿)
Level 1: Python 底层模块直调与实机 CAD 执行   ── [VERIFIED] (E01-E18 基准测试 100%)
```

---

## 二、逐层深度穿透审查意见

### Level 1: Python 底层模块直调 (`real_cad_benchmark_suite.py`)
- **审计事实**: Python 进程直接通过 `from dsh_solidworks... import ...` 调用底层 COM 与执行引擎。
- **证据级别**: **[VERIFIED]**。18 个基准测试在 SolidWorks 进程中真实成型并落盘。

### Level 2: Node.js 策略评估与权限拦截 (`policy.test.js`)
- **审计事实**: Node.js 运行时执行策略计算、路径重写规范化（Normalized Path Rewriting）与越界拦截。
- **证据级别**: **[VERIFIED]**。测试覆盖全面，防穿透规则严密。

### Level 3: FastMCP JSON-RPC 2.0 协议往返 (`real_cad_mcp_dialogue_test.mjs`)
- **审计事实**:
  - Node.js 脚本通过 `child_process.spawn` 启动 Python FastMCP 服务进程。
  - 通过标准 stdio 管道发送符合 JSON-RPC 2.0 规范的请求报文，成功调用了 `solidworks_execute_feature_graph`, `solidworks_get_mass_properties`, `solidworks_modify_dimension`, `solidworks_close_documents`。
  - 成功接收并解析了服务器的真实返回数据。
- **证据级别**: **[VERIFIED]**。证实了 MCP 服务端协议实现的完整性。

### Level 4: DSH 插件宿主契约与工具发现 (`dsh-plugin.json`)
- **审计事实**:
  - `dsh-plugin.json` 声明了 `manifestVersion: 0.15`，声明了 66 个 CAD 工具及权限需求。
  - `lib/discover.js` 实现了 Python 发现优先级 `config.pythonPath > DSH_SOLIDWORKS_PYTHON > .venv > py > PATH`。
- **证据级别**: **[VERIFIED]**。契约测试完全吻合。

### Level 5: 自然语言意图结构化转译 (`cad_task_planner.py`)
- **审计事实**:
  - `CADTaskPlanner` 实现了基于规则匹配与参数提取的初步意图解析器，并具备严苛的几何反例审查能力。
  - **证据局限**: 现有测试均直接输入预先构造好的 JSON/Dict 对象，缺乏真实大模型非结构化自然语言提示词（Prompt）泛化实测。
- **证据级别**: **[PARTIALLY VERIFIED]**。

### Level 6: DSH Agent 动态自主决策与工具编排
- **审计事实**:
  - `real_cad_mcp_dialogue_test.mjs` 中的“三轮对话”实质是由测试脚本按硬编码的步骤（第一步调建模、第二步调测量、第三步调修改）顺次发起的。
  - **根本差异**: 并非由大语言模型观察每一步的返回结果后，**动态自主决定**下一步该调用哪个工具。
- **证据级别**: **[UNVERIFIED / SCRIPTED ONLY]**。严禁将脚本自动化编排等同于 Agent 自主决策。

### Level 7: DSH Agent 真实桌面端到端闭环
- **审计事实**:
  - 当前测试环境没有运行完整的 DeepSeek Harness 桌面应用客户端（Cordis Host），也没有真实的人机聊天交互界面接入。
- **证据级别**: **[UNVERIFIED]**。当前无法证实真实终端用户在 DSH Agent 输入自然语言能够无缝跑通全流程。

---

## 三、端到端终审裁定

系统成功打通了 **Level 1 至 Level 4** 的完整工业控制与协议传输链路，**FastMCP 协议管道级真实有效**。但对于 **Level 5 至 Level 7** 的自主 Agent 全闭环，目前处于“算法就绪但缺乏真实环境集成实测”阶段。
