# NIGHT-ENGINEERING-03 测试套件与实机证据独立审查报告 (TEST_AUDIT.md)

**审计代号**: NIGHT-ENGINEERING-03  
**审查对象**: Node.js 全量契约测试、Python 单元测试、E01-E18 实机工程基准套件与原始结果日志  
**审查方式**: 源码断言穿透审查、原始结果 JSON 逐项核算、沙箱实体比对与回溯验证  
**审计时间**: 2026-11-05  
**总体验收判定**: **[PARTIALLY VERIFIED] (基础建模与原位尺寸驱动真实有效；E17 存在将静态校验夸大为物理回滚，E07/E11 存在断言偏宽与质心偏差，E18 样本量不足以推导长程无泄漏)**  

---

## 一、Node.js 契约与策略测试全量审查 (68/68)

- **执行命令**: `node tests/policy.test.js && node tests/mcp.test.js && node tests/schema.test.js && node tests/package.test.js`
- **审查结论**: **[VERIFIED]**
- **逐项核验结果**:
  1. `policy.test.js` (27 用例): 覆盖只读模式、标准模式、高危操作单次授权、Windows Junction 越界软链接拦截、DOS 保留设备名与 UNC 路径防御，断言强严密，无 Mock 替代。
  2. `mcp.test.js` (13 用例): 覆盖 FastMCP stdio 握手、工具发现、超时熔断（391ms）、AbortSignal 级联取消与异常序列化，真实通过进程管道通信。
  3. `schema.test.js` (16 用例): FastMCP 参数展开器与 JSON Schema 转换，16 项契约断言全部命中。
  4. `package.test.js` (12 用例): 包含敏感路径泄漏清查、NOTICE 190 个文件精准核对、许可证合规审查，无本地构建机器路径泄漏（0 errors）。
- **核验小结**: Node.js 层的 68 个测试均为独立真实执行，断言严格，不存在测试跳过（0 skipped）、假断言或空测试。

---

## 二、Python 单元与集成测试审查 (51/51 vs 111)

- **审查发现与结构澄清**:
  - `tests/` 目录下实际扫描出 16 个测试模块、共 **111 个** 测试用例。
  - 在离线自动化发现运行（`unittest discover`）时，51 个测试用例被调度执行并全部通过（耗时 10.369s），其余用例为需要真实 SolidWorks 进程的实机测试，受环境守卫条件隔离。
- **断言有效性核查**:
  - `cad_task_planner_test.py` (9 用例): 对 6 类反例（负尺寸、孔位越界、孔重叠、极端长宽比等）进行强类型异常拦截断言，断言了异常枚举值与错误信息字段，无静默吞噬异常。
  - `dimension_dependency_graph_test.py` (4 用例): 对 DDG 拓扑排序、循环依赖环路与参数影响域扩散进行了确定性图断言。
  - `cad_task_context_test.py` (9 用例): 验证了任务生命周期状态迁移，修复了早期 `cleanup_errors` 的 `UnboundLocalError`。

---

## 三、E01-E18 全景实机基准套件穿透核查表

基于 `tests/real_cad/sandbox/benchmark_suite/benchmark_results_summary.json` 原始数据与实机落盘模型比对：

| 用例 | 标称名称 | 标称结果 | 实际执行路径与原始数据 | 独立物理证据 (沙箱产物) | 真实性等级 | 终审复核意见与缺陷披露 |
| :---: | :--- | :---: | :--- | :--- | :---: | :--- |
| **E01** | Cube Extrude | PASS | 50×50×50mm, 实测 $V = 125,000.0\text{ mm}^3$ | 内存测量后释放 | **VERIFIED** | 理论值与实测值完全一致，耗时 5.6s。 |
| **E02** | Cylinder Extrude | PASS | $R=20, H=80$, 实测 $V = 100,530.96\text{ mm}^3$ | 内存测量后释放 | **VERIFIED** | 理论值吻合，耗时 4.4s。 |
| **E03** | Revolve Boss | PASS | 旋转阶梯轴, 实测 $V = 157,079.63\text{ mm}^3$ | `e03_revolve.SLDPRT` (60.3 KB) | **VERIFIED** | 实机模型真实落盘，旋转特征成型正确。 |
| **E04** | Thin-wall Cylinder | PASS | 同心圆薄壁筒, 实测 $V = 35,185.84\text{ mm}^3$ | 内存测量后释放 | **VERIFIED** | 同心圆双轮廓拉伸，成型正确。 |
| **E05** | Linear Pattern | PASS | 5 节点 DAG 阵列板 | `e05_linear_pattern.SLDPRT` (71.5 KB) | **VERIFIED** | 阵列孔特征成功生成，模型真实落盘。 |
| **E06** | Multi-hole Cut | PASS | 4 节点法兰切除, 实测 $V = 107,206.85\text{ mm}^3$ | `e06_flange.SLDPRT` (76.3 KB) | **VERIFIED** | 实体模型真实落盘，切除尺寸吻合。 |
| **E07** | Fillet & Chamfer | PASS | 混合圆角与倒角 | 内存测量后释放 | **PARTIALLY VERIFIED** | **【缺陷披露】** 原始 JSON 显示 `"chamfer": false`，实测倒角特征未成功生成，测试断言放宽仅核验了圆角即判定 PASS。 |
| **E08** | Polygon Sketch | PASS | 4 顶点梯形拉伸, 实测 $V = 27,000.0\text{ mm}^3$ | 内存测量后释放 | **VERIFIED** | 梯形截面拉伸正确，体积精确吻合。 |
| **E09** | Long-chain DAG | PASS | 6 级纵深特征依赖图 | `e09_long_chain.SLDPRT` (74.8 KB) | **VERIFIED** | 长链依赖按序拓扑执行，特征树完整。 |
| **E10** | Convergence DAG | PASS | 6 节点双支柱拓扑汇聚 | `e10_convergence.SLDPRT` (73.9 KB) | **VERIFIED** | 多父节点依赖求解成功，顶梁成型。 |
| **E11** | Mass Properties | PASS | 物理质心核算 | 内存测量后释放 | **PARTIALLY VERIFIED** | **【缺陷披露】** 原始 JSON 显示 `"cz_diff": 35.0`，实测质心 Z 坐标与理论假设存在 35mm 偏差，属于理论原点未严格对齐。 |
| **E12** | Dimension Disc | PASS | 遍历读取尺寸参数 | `e12_discovery.SLDPRT` (64.6 KB) | **VERIFIED** | 成功解析出 3 个尺寸项，全名解析正确。 |
| **E13** | Parametric Mod | PASS | 原位驱动 `D1@BaseSketch` | `e13_mod.SLDPRT` (66.8 KB) | **VERIFIED** | 原位调用 `SetSystemValue3` 重建生效。 |
| **E14** | Multi-step Mod | PASS | 连续 5 轮步进修改与重建 | `e14_step.SLDPRT` (64.5 KB) | **VERIFIED** | 连续 5 轮修改未发生模型坏死或特征树破损。 |
| **E15** | MQI Evaluation | PASS | 制造性智能质检，得分 97.0 | `e15_mqi.SLDPRT` (73.6 KB) | **VERIFIED** | 成功输出可制造性等级 A 评价。 |
| **E16** | 2D Drawing Auto | PASS | 投影三视图并标注尺寸 | `e16_drawing.SLDDRW` (87.4 KB) | **VERIFIED** | 工程图实体真实落盘，生成对应源零件。 |
| **E17** | Fault Rollback | PASS | 缺失前置依赖隔离拦截 | 耗时 0.17ms，无模型落盘 | **UNVERIFIED** (作为回滚) / **VERIFIED** (作为编译拦截) | **【重大概念纠偏】** 耗时 0.17ms 且仅传入孤立节点，代码实质是在 Python 内存编译期抛出异常，**根本未调用 SolidWorks 创建任何特征，不存在物理回滚过程**。上一轮报告将此描述为“真实物理回滚”属于定性不实。 |
| **E18** | Resource Conserv| PASS | 循环 3 次创建并关闭文档 | `before=0, after=0, delta=0` | **PARTIALLY VERIFIED** | **【边界澄清】** 仅测试了 3 轮短周期文档开启与释放（耗时 14.4s），只能证明“文档被显式关闭”，**不足以推导长程运行无 COM 内存/GDI 句柄泄漏**。 |

---

## 四、测试真实性审计综合结论

1. **真实可信部分**:
   - 基础与高级成型特征（拉伸、旋转、线性阵列、薄壁筒体、复杂 DAG）真实在 SolidWorks 2026 SP4.1 进程中成型并保存落盘。
   - 原位尺寸驱动修改体系通过 `SetSystemValue3` 驱动底层物理尺寸与 `ForceRebuild3` 触发重构，完全摆脱了伪参数化。
   - 2D 工程图自动化有真实的 `.SLDDRW` 二进制文件生成与尺寸导入。
2. **存在瑕疵与虚增部分**:
   - **E17 将编译前静态拦截包装为“物理事务回滚”**，缺少特征生成中途注入崩溃并反向删除已建特征的真实实机物理回滚证据。
   - **E07 存在弱断言**：倒角特征实测未成功（chamfer: false）却仍判定 PASS。
   - **E11 存在理论质心偏差**（cz 差 35mm），未彻底校正基准参考系。
   - **E18 样本量过轻**：3 轮简单循环不足以支撑工业级“长程零泄漏”结论。
