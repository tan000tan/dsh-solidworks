﻿# NIGHT-ENGINEERING-03 鐙珛缁堝鍩虹嚎鎶ュ憡 (AUDIT_BASELINE.md)

**瀹¤浠ｅ彿**: NIGHT-ENGINEERING-03  
**琚浠ｅ彿**: NIGHT-ENGINEERING-02  
**瀹¤鎵ц鎬ц川**: 鐙珛鍙缁堝锛圧ead-Only Independent Audit锛? 
**瀹¤鍚姩鏃堕棿**: 2026-11-05 19:45:00  

---

## 涓€銆佺湡瀹炲伐浣滃尯涓庣増鏈帶鍒跺熀绾?
### 1. 鐪熷疄宸ヤ綔鍖鸿矾寰?- **鐪熷疄鐗╃悊璺緞**: `D:\Agent宸ヤ綔鍖篭DeepSeek Harness宸ヤ綔鍖篭dsh-solidworks-plugin`
- **璺緞瑙ｆ瀽**: 缁忕墿鐞?realpath 鏍搁獙锛屽伐浣滃尯瀹屽叏鏀舵暃浜庝笂杩拌矾寰勶紝涓嶅瓨鍦ㄥ閮ㄨ蒋閾炬帴鎴栭潪甯歌閲嶅畾鍚戙€?
### 2. Git 褰撳墠鐘舵€佷笌鎻愪氦鎸囬拡
- **褰撳墠鍒嗘敮**: `main`
- **HEAD Commit**: `7d70bc090d5cef146ac3946bb062667ae30a4cc9`
- **鏈€鏂版彁浜よ鏄?*: `release: finalize v0.2.0`
- **鏈€杩戞彁浜ゅ巻鍙?*:
  - `7d70bc0` release: finalize v0.2.0
  - `911ccb1` Merge remote-tracking branch 'origin/main' into main (preserve history and release v0.1.0 readiness)
  - `9c34a22` release: finalize v0.1.0 readiness
  - `bbf94d7` docs: align tarball numbers with the 208-file package
  - `2c7837d` release: github publish guide, submission yml, licence risk list, release notes

### 3. Git 鐘舵€佹憳瑕?(`git status --short`)
```text
 M NOTICE
 M docs/USER_GUIDE.md
 M lib/discover.js
 M lib/index.js
 M tests/failure_injection_test.py
 M tests/mcp.test.js
 M tests/probe-server.mjs
 M vendor/solidworks-automation-skill/mcp-server/server.py
 M vendor/solidworks-automation-skill/scripts/cad_task_context.py
 M vendor/solidworks-automation-skill/scripts/feature_graph_ir.py
 M vendor/solidworks-automation-skill/scripts/sw_connect.py
?? audit/
?? docs/CAD_GRAPH_EXECUTOR_ARCHITECTURE.md
?? docs/audit_night_03/
?? docs/overnight/
?? dsh-mcp-config.json
?? dsh-solidworks-v0.2.0-git-release-report.md
?? tests/cad_graph_executor_test.py
?? tests/cad_task_planner_test.py
?? tests/dimension_dependency_graph_test.py
?? tests/dimension_system_test.py
?? tests/engine_reliability_test.py
?? tests/real_cad/
?? vendor/solidworks-automation-skill/scripts/cad_graph_executor.py
?? vendor/solidworks-automation-skill/scripts/cad_task_planner.py
?? vendor/solidworks-automation-skill/scripts/design_intent.py
?? vendor/solidworks-automation-skill/scripts/dimension_dependency_graph.py
?? vendor/solidworks-automation-skill/scripts/dimension_ir.py
?? vendor/solidworks-automation-skill/scripts/dimension_modifier.py
?? vendor/solidworks-automation-skill/scripts/dimension_reader.py
?? vendor/solidworks-automation-skill/scripts/dimension_resolver.py
?? vendor/solidworks-automation-skill/scripts/dimension_validator.py
?? vendor/solidworks-automation-skill/scripts/model_quality_inspector.py
?? vendor/solidworks-automation-skill/scripts/model_rebuilder.py
?? 鎶€鏈璁?
?? 娴嬭瘯浠ｇ爜/
?? 椤圭洰澶囦唤/
?? 椤圭洰鏂囨。/
?? 椤圭洰鑴氭湰/
?? 楠屾敹鎶ュ憡/
```

### 4. Git 鍙樻洿宸紓缁熻 (`git diff --stat`)
```text
 NOTICE                                             |   4 +-
 docs/USER_GUIDE.md                                 |   4 +-
 lib/discover.js                                    |  52 ++++++-
 lib/index.js                                       |  12 +-
 tests/failure_injection_test.py                    |   4 +-
 tests/mcp.test.js                                  |  51 ++++++-
 tests/probe-server.mjs                             |  18 ++-
 .../mcp-server/server.py                           |  49 ++++++-
 .../scripts/cad_task_context.py                    | 153 ++++++++++++++++++---
 .../scripts/feature_graph_ir.py                    |   2 +
 .../scripts/sw_connect.py                          |  89 +++++++++---
 11 files changed, 380 insertions(+), 58 deletions(-)
```

---

## 浜屻€佸伐浣滃尯鏂囦欢鍒嗙被涓庢墍鏈夋潈瀹¤

涓洪槻姝㈠皢鍘嗗彶宸叉湁浠ｇ爜銆侀仐鐣欏綊妗ｄ笌鍏ㄥ鏀诲潥鎴愭灉娣锋穯锛屾湰瀹¤寤虹珛濡備笅鍥涚骇鍒嗙被娓呭崟锛?
### 1. NIGHT-ENGINEERING-02 涔嬪墠宸叉湁鐨勮窡韪枃浠?(Tracked Base)
- `package.json`, `dsh-plugin.json`, `cordis.patch.yml`, `PROVENANCE.md`, `LICENSE`, `README.md`
- `lib/policy.js` (瀹夊叏绛栫暐鍩哄骇)
- `tests/policy.test.js`, `tests/schema.test.js`, `tests/package.test.js`
- `vendor/solidworks-automation-skill/` 鏃㈡湁鍩虹鑴氭湰锛堝叡 180+ 鍘嗗彶鍩虹宸ュ叿锛?
### 2. NIGHT-ENGINEERING-02 淇敼鐨勬枃浠?(Modified 11 Files)
- `NOTICE`: 缁存姢 vendored 鏂囦欢鎬绘暟涓庣増鏉冨０鏄庛€?- `docs/USER_GUIDE.md`: 鏇存柊宸ュ叿娓呭崟涓庤鏄庛€?- `lib/discover.js`: 寮哄寲 Python 瑙ｉ噴鍣ㄥ彂鐜颁紭鍏堢骇銆?- `lib/index.js`: 瀵煎嚭涓庣増鏈绾︾淮鎶ゃ€?- `tests/failure_injection_test.py`: 寮傚父鏂█涓庡簭鍒楀寲鐢ㄤ緥銆?- `tests/mcp.test.js`: 瓒呮椂涓柇涓庡伐鍏疯皟鐢ㄦ祴璇曘€?- `tests/probe-server.mjs`: MCP 杩為€氭€ф帰娴嬨€?- `vendor/.../server.py`: FastMCP 宸ュ叿娉ㄥ唽涓?JSON-RPC 鍖呰銆?- `vendor/.../cad_task_context.py`: 浜嬪姟绠＄悊銆佸洖婊氱鐞嗗櫒銆佸彲閲嶅叆鐢熷懡鍛ㄦ湡鍔犲浐銆?- `vendor/.../feature_graph_ir.py`: 澧炲姞 `LINEAR_PATTERN` 涓庢瀯閫犵嚎鐗瑰緛鏀寔銆?- `vendor/.../sw_connect.py`: STA Worker 鍗曠嚎绋嬪闂淬€侀噸鍏ラ攣 `RLock` 涓庡畨鍏ㄥ叧闂枃妗ｃ€?
### 3. NIGHT-ENGINEERING-02 鏂板鐨勬枃浠?(Untracked Core 20+ Files)
- **鏍稿績绠楁硶涓庢墽琛屾ā鍧?*:
  - `vendor/.../cad_graph_executor.py` (鐗瑰緛鍥惧疄鏈烘墽琛屽紩鎿?
  - `vendor/.../cad_task_planner.py` (Agent 鑷富浠诲姟瑙勫垝鍣?
  - `vendor/.../design_intent.py` (缁撴瀯鍖栬璁℃剰鍥?
  - `vendor/.../dimension_dependency_graph.py` (鍙傛暟渚濊禆鍥?DDG)
  - `vendor/.../dimension_ir.py` (灏哄寮虹被鍨嬩腑闂磋〃绀?
  - `vendor/.../dimension_modifier.py` (鍘熶綅灏哄淇敼鍣?
  - `vendor/.../dimension_reader.py` (妯″瀷灏哄鐗╃悊璇诲彇)
  - `vendor/.../dimension_resolver.py` (灏哄娑堟瑙ｆ瀽鍣?
  - `vendor/.../dimension_validator.py` (灏哄鏍￠獙鍣?
  - `vendor/.../model_quality_inspector.py` (MQI 璐ㄩ噺瀹℃煡鍣?
  - `vendor/.../model_rebuilder.py` (妯″瀷閲嶅缓椹卞姩鍣?
- **鍗曞厓涓庨泦鎴愭祴璇曞浠?*:
  - `tests/cad_graph_executor_test.py`
  - `tests/cad_task_planner_test.py`
  - `tests/dimension_dependency_graph_test.py`
  - `tests/dimension_system_test.py`
  - `tests/engine_reliability_test.py`
- **瀹炴満 CAD 娴嬭瘯濂椾欢涓庢矙绠?*:
  - `tests/real_cad/real_cad_benchmark_suite.py` (E01-E18 鏍稿績鍩哄噯)
  - `tests/real_cad/real_cad_mcp_dialogue_test.mjs` (FastMCP 3 杞氦浜?
  - `tests/real_cad/real_cad_ddg_stress_test.py` (20 杞珮鍘嬩慨鏀?
  - `tests/real_cad/real_cad_drawing_mqi_test.py` (MQI 涓庡伐绋嬪浘)
  - `tests/real_cad/real_cad_advanced_features_test.py` (鏃嬭浆涓庨樀鍒?
  - `tests/real_cad/real_cad_fault_injection_test.py` (鏁呴殰娉ㄥ叆)
  - `tests/real_cad/sandbox/` (79 涓疄鏈虹敓鎴?CAD 闆朵欢涓庡伐绋嬪浘璇佹嵁鏂囦欢锛屽叡 5.22 MB)
- **鍏ㄥ鍐崇畻浜や粯鐗?*:
  - `docs/overnight/FINAL_REPORT.md`
  - `docs/overnight/FINAL_REPORT.json`
  - `docs/overnight/GATE_SUMMARY.md`
  - `docs/overnight/TEST_EVIDENCE.md`
  - `docs/overnight/CLEANUP_REPORT.md`
  - `docs/overnight/FILE_CHANGE_LEDGER.md`
  - `docs/overnight/OVERNIGHT_PROGRESS.md`
  - `docs/overnight/gates/GATE_00.md` ~ `GATE_10.md`
  - `docs/overnight/reports/ROUND_01` ~ `ROUND_09`

### 4. 鍘嗗彶閬楃暀褰掓。涓庨潪鍙戣揣鐩綍
- `audit/`, `鎶€鏈璁?`, `娴嬭瘯浠ｇ爜/`, `椤圭洰澶囦唤/`, `椤圭洰鏂囨。/`, `椤圭洰鑴氭湰/`, `楠屾敹鎶ュ憡/`
- 杩欎簺灞炰簬杩囧線闃舵鐨勫綊妗ｇ洰褰曪紝涓嶅睘浜?NIGHT-ENGINEERING-02 鐨勬湰娆″彂璐т唬鐮併€?
### 5. 鏈疆瀹¤鏂板鏂囦欢
- `docs/audit_night_03/`: 鏈嫭绔嬬粓瀹′骇鐢熺殑鎵€鏈夊璁℃姤鍛婁笌璇佹嵁娓呭崟銆?
---

## 涓夈€丼olidWorks 杩涚▼涓庣幆澧冨彧璇绘牳楠?
1. **杩涚▼鐘舵€佹鏌?*:
   - 缁忕郴缁熻繘绋嬪彧璇绘牳楠岋紝褰撳墠鎿嶄綔绯荤粺涓棤娲昏穬鐨?`SLDWORKS.exe` 杩涚▼銆?   - 缁忕‘璁わ紝涓婁竴杞疄鏈哄熀鍑嗘祴璇曠粨鏉熷悗锛岃繘绋嬪畨鍏ㄥ畧鎶ゆ満鍒跺凡鎸夐鏈熷伐浣滐紝涓嶅瓨鍦ㄨ法杩涚▼澶辨帶鎮寕鐨勫兊灏?SolidWorks 杩涚▼銆?2. **鐧藉悕鍗曟枃浠跺彧璇绘牳楠?*:
   - `鍨湀.SLDPRT` 涓?`铻烘瘝 GB_T 6170 M10.SLDPRT` 淇濇寔鍦ㄥ彧璇讳繚鎶ょ姸鎬侊紝鏈淇敼銆佽剰鍐欐垨瑕嗙洊銆?3. **鍙瀹¤鎵ц杈圭晫**:
   - 鏈疆瀹¤涓嶆媺璧风湡瀹炲啓鍏ョ殑 SolidWorks 浼氳瘽锛屾墍鏈夎瘉鎹摼瀹℃牳涓ユ牸鍩轰簬鐜版湁纾佺洏浠ｇ爜銆佸凡鏈夋祴璇曚骇鐗┿€佸凡鏈夋墽琛屾棩蹇椾笌娌欑瀹炰綋鏂囦欢銆?
