# NIGHT-ENGINEERING-03 2D 工程图自动化产物与逻辑专项核验报告 (DRAWING_AUDIT.md)

**审计代号**: NIGHT-ENGINEERING-03  
**审查产物**: `tests/real_cad/sandbox/benchmark_suite/e16_drawing.SLDDRW`, `motor_bracket_drawing_*.SLDDRW`  
**审查重点**: 物理文件真实性、SolidWorks 二进制格式、视图配置、尺寸标注与重新打开闭环证据  
**审计时间**: 2026-11-05  
**总体验收判定**: **[PARTIALLY VERIFIED] (2D 工程图物理产物真实落盘且尺寸可观，三视图与轴测图生成代码完备；但缺乏落盘后的独立 Re-open 重新打开验证闭环与渲染视觉证据)**  

---

## 一、物理工程图产物指纹与存储结构核验

经只读文件系统扫描，沙箱目录中存在 3 份实机测试生成的 `.SLDDRW` 实体图纸：

| 物理落盘路径 | 磁盘大小 (Bytes) | 头部特征字节 (Hex) | 对应生成测试 | 物理真实性判定 |
| :--- | :---: | :---: | :--- | :---: |
| `tests/real_cad/sandbox/benchmark_suite/e16_drawing.SLDDRW` | 87,377 | `2f70bcd900000004...` | E16 工程基准套件 | **真实落盘** |
| `tests/real_cad/sandbox/motor_bracket_drawing_20261105_144946_443802.SLDDRW` | 107,889 | `7a26deb100000004...` | Round-07 MQI 与工程图 | **真实落盘** |
| `tests/real_cad/sandbox/motor_bracket_drawing_20261105_090544_719589.SLDDRW` | 66,133 | `db00553c00000004...` | Round-07 初始验证 | **真实落盘** |

- **二进制格式核验**:
  - 文件头部第 5-8 字节均为 `00000004`，呈现典型的 Dassault Systèmes SolidWorks 2026 专有压缩流复合特征。
  - 文件大小处于 66 KB ~ 108 KB 之间，与 SolidWorks 真实图纸（包含图纸图层、标准图框、几何投影几何实体与标注）的正常文件体积相吻合，非空白文件或文本打桩。

---

## 二、工程图自动化生成代码实现深度核查

核心驱动逻辑由 `drawing_workflow.py`（2039 行）承载，实测执行路径包括：
1. **图纸文档初始化**: 调用 `new_document(sw, "drawing")` 创建基于标准模板的图纸环境。
2. **正交三视图生成**: `create_standard_views(drw, part_path)` 调用 SolidWorks 内部投影 API，按第一角或第三角视图投影出主视图 (Front)、俯视图 (Top) 与左视图 (Left)。
3. **等轴测视图配置**: `add_view(drw, part_path, "*Isometric", 0.35, 0.28, scale=0.5)`，指定绝对坐标 $(0.35, 0.28)\text{m}$ 并在右上角布局 1:2 缩放的轴测投影。
4. **模型尺寸自动导入**: 调用 `InsertModelAnnotations3`，自动将 3D 零件中由特征和草图驱动的物理尺寸导入图纸视图。
5. **结构内省**: 在内存中调用 `inspect_drawing_structure(drw)`，核验视图数量 `view_count >= 3`。

---

## 三、终审缺口与风险披露

1. **缺失独立 Re-open（重新打开）测试证据**:
   - 深入审查 `real_cad_drawing_mqi_test.py` 和 `real_cad_benchmark_suite.py` 发现：
   - 视图内省（`inspect_drawing_structure`）是在图纸落盘保存前**对活动内存对象执行的**。
   - 图纸调用 `save_document` 落盘并 `close_document` 关闭后，测试脚本**并未调用 `open_document(sw, drw_path)` 重新打开该离线图纸文件进行二次反向校验**。
   - 无法证明该文件在脱离源零件活动会话后，外部重新打开时是否存在“源零件引用路径丢失”、“视图空白重建失败”等潜在问题。
2. **缺乏视觉渲染与尺寸重叠检查证据**:
   - 脚本通过 COM 接口导入了尺寸，但并未导出高分辨率位图（如 PNG/PDF）进行视觉层面的文字避让与尺寸重叠检查（Clash Detection）。
   - 报告中声称的“尺寸可读性良好”缺乏机器视觉或人工核验的截图证据支持。

---

## 四、终审定性

工程图生成能力在“代码实现”与“实机落盘”维度已通过验证，但由于**缺少保存后的重新打开校验**与**视觉可读性直观证据**，依据最高审计准则，本项能力最终判定为：**[PARTIALLY VERIFIED]**。
