# DSH-SolidWorks v0.3.0 执行架构与 COM 隔离重构设计

## 一、架构重构背景与根因定位

在 v0.2.0 及更早版本中，CAD 自动化插件面临以下核心工程挑战：
1. **`CO_E_SERVER_EXEC_FAILURE` (0x80080005)**：当 SolidWorks 尚未完全启动、ROT（Running Object Table）注册存在延迟、或系统以不同权限（如管理员 vs 普通权限）启动时，调用 `win32com.client.Dispatch` 会触发服务执行超时或拒绝，产生未处理的崩溃。
2. **COM 与 DSH 事件循环耦合**：SolidWorks COM 对象要求在单线程单元（STA, Single-Threaded Apartment）中初始化并定期泵送 Windows 消息（`PumpWaitingMessages`）。如果直接在 DSH 宿主或主异步事件循环中调用，耗时 CAD 操作（如几何布尔切除、网格重构）会导致宿主完全失去响应。
3. **多实例冲突与选择盲区**：当用户后台运行着批处理或另一个工程实例时，历史逻辑只能盲目连接到 ROT 中的第一个实例，无法感知其它实例的存活、窗口标题或健康状态。
4. **孤儿进程滞留**：如果宿主异常终止或被杀，后台拉起的辅助 Python 进程可能成为孤儿留在系统中占用句柄与内存。

---

## 二、进程与隔离模型方案对比

| 评估维度 | 方案 A：嵌入式 STA 线程池 | 方案 B：独立 Worker 进程模型（推荐） |
| :--- | :--- | :--- |
| **故障隔离性** | 中等。若 COM 在 C++ 原生层发生非法访问（Access Violation），整个宿主进程崩溃。 | **极高**。Worker 进程崩溃完全不影响 DSH 宿主与用户界面。 |
| **STA 消息泵解耦** | 在专用线程中泵送，但与主环境共享 GIL。 | **彻底解耦**。专用子进程独享 STA 单元和消息循环。 |
| **内存与句柄泄漏** | 长期运行累积大量 COM 引用，Python 垃圾回收难以及时释放。 | **操作边界重置**。可通过 Worker 重启完全归还操作系统内存。 |
| **孤儿进程清理** | 同进程无需额外清理，但僵死时无法自愈。 | **采用 Windows Job Object**（`JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE`），操作系统内核级自动销毁。 |
| **跨进程通信开销** | 0 序列化开销（内存直传）。 | 极低（本地 stdio 极简 JSON-RPC 2.0，单次往返 < 1.2ms）。 |

**结论与选型决策**：
采用 **分层独立 Worker 进程模型**：
- **上层**：DSH 宿主通过轻量 `lib/mcp.js` (stdio JSON-RPC) 与 `server.py` 通信；
- **底层**：`server.py` 内嵌 `_STAWorker` 与 Windows Job Object 守护，通过专用 STA 线程队列串行化所有 COM 操作，并在进程外围配置内核级退出清理。

---

## 三、关键重构模块与实现细节

### 1. 0x80080005 智能捕获与自愈
在 `sw_connect.py` 中实现了 `is_co_e_server_exec_failure(exc)` 过滤器，能够识别 PyIDispatch 的 `hresult == -2146959355`、字符串形式 `0x80080005` 及 `CO_E_SERVER_EXEC_FAILURE`。当捕获该错误时，系统不抛出未捕获崩溃，而是自动记录诊断日志、等待已有进程完成 ROT 注册，并在 1.5 秒后自动重试。

### 2. 多实例发现与结构化元数据提取
在 `sw_process.py` 中实现了 `list_solidworks_instances()`，通过 Windows Toolhelp32 与 `QueryFullProcessImageNameW`、`EnumWindows`、`IsHungAppWindow` 直接提取：
- `pid`: 实例进程 ID
- `year`: 真实发布版本年份（如 2026）
- `exe_path`: 物理可执行文件路径
- `window_title`: 当前打开的主窗口标题
- `responding`: 界面是否响应（避免死锁于挂起窗口）

### 3. Windows Job Object 防孤儿进程守护
通过 `sw_job_object.py` 调用 Windows 原生 API 创建带有 `JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE` 标志的 Job Object，将主进程与拉起的 Worker 进程绑定。一旦主进程关闭，操作系统内核强制清理所有子进程。

---

## 四、验证结果与证据索引

- **测试套件**：`tests/phase2_architecture_test.py`
- **测试结果**：5 项用例全部 PASS，运行时间 0.230 秒。
- **实机表现**：成功在物理 SolidWorks 2026 (PID: 32216) 上完成响应性检测与安全连接，未触碰或修改用户已打开的 20 个工程文档。
