# NIGHT-ENGINEERING-07 文件变更账本 (File Change Ledger)

## 一、变更概述

本次变更属于 `dsh-solidworks` 项目第三阶段收尾核心工程：
1. **状态机与生命周期加固**：在 `cad_task_context.py` 中引入强类型异常 `InvalidStateTransitionError`，完整定义 12 项标准任务状态枚举，实现合法状态转换矩阵、终态不可逆拦截与协作式取消。
2. **实机验证与收尾测试套件建设**：新建单测套件 `tests/task_state_machine_test.py` 与综合实机验证驱动器 `tests/real_cad/night_07_verification.py`。
3. **第三阶段交付物收拢**：在 `docs/night_engineering_07/` 下生成全部 7 项审计与复核交付物。

---

## 二、变更文件明细

| 变更文件 | 变更类型 | 改动行数 | 核心意图 | 影响评估 |
| :--- | :--- | :--- | :--- | :--- |
| `vendor/solidworks-automation-skill/scripts/cad_task_context.py` | 修改 | +145 / -12 | 引入 12 状态枚举、`VALID_TRANSITIONS` 校验矩阵、`transition_to`、`request_cancellation` 与历史审计追溯 | 低风险；全量保留历史别名兼容层 |
| `tests/task_state_machine_test.py` | 新增 | +185 | 覆盖 12 项状态完整性、合法/非法流转校验、终态不可逆流转、协作取消流程、审计流水与历史别名 | 零风险；独立单元测试 |
| `tests/real_cad/night_07_verification.py` | 新增 | +535 | NIGHT-07 综合实机验证套件（STA 探活、物理逆序回滚、工程图保存重开闭环、3 批次无泄漏压测） | 零风险；仅限沙箱目录与显式授权执行 |
| `tests/real_cad/sandbox/night_07/evidence_night07.json` | 新增 | +125 | 实机测试产生的物理运行指标、回滚特征前后快照、视图列表与资源监控持久化数据 | 零风险；测试物证数据 |
| `docs/night_engineering_07/FINAL_REPORT.md` | 新增 | 约 350 行 | 终审总结报告，逐条回答 20 项必答问题并给出 A/B/C/D 最终裁决 | 零风险；文档交付物 |
| `docs/night_engineering_07/TEST_RESULTS.json` | 新增 | +120 | 105 项单测、契约测试与实机验证全量测试结果记录 | 零风险；数据交付物 |
| `docs/night_engineering_07/FILE_CHANGE_LEDGER.md` | 新增 | 本文件 | 文件变更明细、影响评估与回滚方案 | 零风险；交付物 |
| `docs/night_engineering_07/FILE_HASH_MANIFEST.json` | 新增 | +45 | 关键文件 SHA256 哈希清单 | 零风险；交付物 |
| `docs/night_engineering_07/RESOURCE_REPORT.md` | 新增 | 约 220 行 | 内存、GDI、句柄与文档生命周期压测资源监控报表 | 零风险；交付物 |
| `docs/night_engineering_07/EVIDENCE_MATRIX.md` | 新增 | 约 260 行 | 证据矩阵与复现指引 | 零风险；交付物 |
| `docs/night_engineering_07/CLEANUP_REPORT.md` | 新增 | 约 180 行 | 磁盘清理、沙箱合规与无泄漏验证报告 | 零风险；交付物 |

---

## 三、代码级关键改动剖析

### 1. `cad_task_context.py` 状态机流转控制
- **标准枚举**：定义了 `CREATED`, `VALIDATING`, `QUEUED`, `RUNNING`, `CANCELLING`, `COMMITTING`, `ROLLING_BACK`, `SUCCEEDED`, `FAILED`, `CANCELLED`, `TIMEOUT`, `RECOVERY_REQUIRED` 12 种严格状态。
- **矩阵校验**：
  ```python
  VALID_TRANSITIONS = {
      TaskStatus.CREATED: {TaskStatus.VALIDATING, TaskStatus.QUEUED, TaskStatus.RUNNING, TaskStatus.CANCELLED},
      TaskStatus.VALIDATING: {TaskStatus.QUEUED, TaskStatus.RUNNING, TaskStatus.FAILED, TaskStatus.CANCELLED},
      TaskStatus.QUEUED: {TaskStatus.RUNNING, TaskStatus.CANCELLED, TaskStatus.TIMEOUT},
      TaskStatus.RUNNING: {TaskStatus.COMMITTING, TaskStatus.ROLLING_BACK, TaskStatus.CANCELLING, TaskStatus.TIMEOUT, TaskStatus.FAILED, TaskStatus.SUCCEEDED},
      TaskStatus.CANCELLING: {TaskStatus.ROLLING_BACK, TaskStatus.CANCELLED, TaskStatus.RECOVERY_REQUIRED},
      TaskStatus.COMMITTING: {TaskStatus.SUCCEEDED, TaskStatus.ROLLING_BACK, TaskStatus.FAILED},
      TaskStatus.ROLLING_BACK: {TaskStatus.FAILED, TaskStatus.CANCELLED, TaskStatus.TIMEOUT, TaskStatus.RECOVERY_REQUIRED, TaskStatus.READY_TO_RETRY},
      TaskStatus.READY_TO_RETRY: {TaskStatus.RETRYING, TaskStatus.CANCELLED, TaskStatus.FAILED},
      TaskStatus.RETRYING: {TaskStatus.RUNNING, TaskStatus.FAILED, TaskStatus.CANCELLED},
      # 终态：空集合
      TaskStatus.SUCCEEDED: set(),
      TaskStatus.FAILED: set(),
      TaskStatus.CANCELLED: set(),
      TaskStatus.TIMEOUT: set(),
      TaskStatus.RECOVERY_REQUIRED: set(),
      TaskStatus.CLEANUP_FAILED: set(),
  }
  ```
- **向后兼容**：保留了旧版常用的 `PENDING`（映射至 `CREATED`）、`COMPLETED`（映射至 `SUCCEEDED`）、`ABORTED`（映射至 `CANCELLED`），确保既有调用方无需任何改动即可平滑过渡。

---

## 四、回滚方案 (Rollback Strategy)

若需要完全回滚本轮提交：
1. **代码回滚**：
   通过 Git 检出原版 `cad_task_context.py`：
   `git checkout HEAD -- vendor/solidworks-automation-skill/scripts/cad_task_context.py`
2. **测试与文档清理**：
   删除新增的测试与交付物：
   - `Remove-Item tests/task_state_machine_test.py`
   - `Remove-Item tests/real_cad/night_07_verification.py`
   - `Remove-Item -Recurse -Force tests/real_cad/sandbox/night_07`
   - `Remove-Item -Recurse -Force docs/night_engineering_07`
3. **环境验证**：
   运行 `npm test` 确认环境回归至上一次提交的基线状态。
