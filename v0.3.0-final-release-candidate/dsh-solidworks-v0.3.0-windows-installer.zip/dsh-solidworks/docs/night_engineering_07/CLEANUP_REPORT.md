# NIGHT-ENGINEERING-07 磁盘清理与沙箱合规报告 (Cleanup Report)

## 一、磁盘空间基线与变化

| 项目 | 测试前基线 | 测试后终态 | 变化量 | 评估 |
| :--- | :--- | :--- | :--- | :--- |
| **工作区磁盘可用空间** | 196.27 GB | 196.25 GB | -0.02 GB (约 20MB) | 正常（主要为代码变更、单测报告与物证文件） |
| **测试沙箱目录** | `tests/real_cad/sandbox/night_07/` | 保持纯净 | 仅保留持久化物证 `evidence_night07.json` (3KB) | 合规 |
| **临时 CAD 模型落盘** | 0 字节残留 | 0 字节残留 | 0 字节 | 测试产生的 `.SLDPRT` / `.SLDDRW` / `.pdf` 均已在测试用例内安全解耦并物理删除 |
| **Python 字节码缓存** | `__pycache__` 已被清除 | 清空状态 | 0 残留 | 完全符合 `package.test.js` 对发布包纯净度要求 |

---

## 二、沙箱合规性核查

1. **写操作强隔离**：
   - 所有的物理回滚建模、工程图投影、压测闭环等写操作，均被严格限制在 `tests/real_cad/sandbox/night_07/` 独立目录中进行；
   - 严禁且未在项目根目录、用户桌面或系统主目录产生任何 CAD 临时碎片。
2. **白名单零件保护**：
   - 白名单受保护零件：`['垫圈.SLDPRT', '螺母 GB_T 6170 M10.SLDPRT']`；
   - 经审查与监控，测试全流程中该白名单零件未被写入、修改或重命名，保持 100% 只读与无损。
3. **未跟踪文件与临时测试脚本处置**：
   - 本轮编写的综合实机驱动脚本统一定位于 `tests/real_cad/night_07_verification.py`，受版本库统一管辖；
   - 未产生任何脱离版本管理的单次零散测试脚本。

---

## 三、代码仓库与发布规范验证

1. **打包纯净度**：
   执行 `npm test` 中 `package.test.js` 的 `the vendored engine is complete and carries no build junk` 断言，验证结果为 **PASS**，无任何 `.pyc`、`.log`、`.tmp` 残留。
2. **路径脱敏检查**：
   执行 `shipped files (docs, provenance, tests) do not leak build machine paths` 断言，验证结果为 **PASS**，文档与测试中无任何构建机绝对路径泄漏。
