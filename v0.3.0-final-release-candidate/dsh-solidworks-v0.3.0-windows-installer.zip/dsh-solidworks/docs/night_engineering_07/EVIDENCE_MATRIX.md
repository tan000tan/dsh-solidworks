# NIGHT-ENGINEERING-07 证据矩阵与复现指引 (Evidence Matrix)

## 一、证据矩阵总表

| 序号 | 验证模块 / 阶段 | 执行层级 | 验证目标 | 核心断言 / 判定标准 | 物证来源与持久化文件 | 状态 |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **E01** | CAD 任务有限状态机 | L1 (单元测试) | 12 项标准状态与流转矩阵校验 | 终态不可逆流转，非法跳转抛出 `InvalidStateTransitionError` | `tests/task_state_machine_test.py` | **PASS** |
| **E02** | 协作式取消与超时响应 | L1/L3 (实机调度) | 超时与取消请求能够安全切断后续执行并流转至 CANCELLED | `ctx.is_cancelled() == True`, 终态 `CANCELLED`，审计历史流水条数 $\ge 5$ | `tests/real_cad/sandbox/night_07/evidence_night07.json` | **PASS** |
| **E03** | STA Worker 探活机制 | L3 (实机 COM) | 检测工作线程健康度与响应性 | `worker.is_healthy() == True`，单线程单元无死锁 | `tests/real_cad/sandbox/night_07/evidence_night07.json` | **PASS** |
| **E04** | Level 3 真实特征树物理回滚 | L3 (实机 CAD) | 注入故障后，逆序删除已建特征并强制重建 | 回滚后实体数精确为 0，物理体积精确为 0，特征树上已建特征彻底抹除，初始基准面与原点完好保存 | `tests/real_cad/sandbox/night_07/evidence_night07.json` (Phase 04) | **PASS** |
| **E05** | 离线物理回滚重开一致性 | L3 (实机 CAD) | 保存回滚后的零件并重新打开，检验磁盘物理真实性 | `reopened_bodies == 0`, `reopened_volume == 0.0` | `tests/real_cad/sandbox/night_07/evidence_night07.json` | **PASS** |
| **E06** | 2D 工程图正交三视图生成 | L3 (实机 CAD) | 基于真实源零件自动投影前/俯/左正交视图 | 主视图、俯视图、左视图投影成功，`views_before >= 3` | `tests/real_cad/sandbox/night_07/evidence_night07.json` (Phase 05) | **PASS** |
| **E07** | 2D 工程图保存与重开闭环 | L3 (实机 CAD) | 工程图物理落盘并彻底关闭后，重新打开 (Re-open) 校验结构 | 重新打开耗时约 1.9s，重开后视图列表存在且 `status == "pass"` | `tests/real_cad/sandbox/night_07/evidence_night07.json` | **PASS** |
| **E08** | 矢量工程图 PDF 导出 | L3 (实机 CAD) | 导出标准矢量 PDF 文件并检验有效性 | PDF 文件大小为 50,684 字节 ($>1\text{ KB}$)，渲染结构完整 | `tests/real_cad/sandbox/night_07/evidence_night07.json` | **PASS** |
| **E09** | 分批资源无泄漏压测 | L3 (实机压测) | 3 批次连续建模循环，监控内存与 GDI 稳定性 | 批次间内存波动 $<2\text{ MB}$，GDI 对象完全恒定 (887)，每批次后文档计数均精准归位 | `tests/real_cad/sandbox/night_07/evidence_night07.json` (Phase 06) | **PASS** |
| **E10** | 文档计数基线保护 | L3 (实机调度) | 确保无未保存新文档残留，测试前后文档计数一致 | `baseline_doc_count == 0`, `final_doc_count == 0`，残留增量为 0 | `tests/real_cad/sandbox/night_07/evidence_night07.json` | **PASS** |
| **E11** | 尺寸驱动参数化统一门面兼容 | L1 (单元测试) | 统一门面支持旧调用与新 IR 架构无缝切换 | 24 项尺寸系统单测 100% 通过，无破坏性变更 | `tests/TEST_RESULTS.json` | **PASS** |
| **E12** | 宿主安全策略与契约全量覆盖 | L1/L4 (宿主契约) | 覆盖 Zero-Trust 权限阻断、参数提取、路径遍历拦截与打包纯净度 | 68 项 Node.js 测试 100% 通过 | `npm test` 控制台输出 | **PASS** |

---

## 二、复现指引 (Step-by-Step Reproduction)

所有测试均可使用项目内置命令在交互式 Windows 环境下完全无损复现：

### 1. 运行任务状态机单元测试
```powershell
python tests/task_state_machine_test.py
```
**期望结果**：Ran 7 tests in 0.000s, OK.

### 2. 运行尺寸参数化统一门面测试
```powershell
python tests/unified_dimension_migration_test.py
python tests/dimension_system_test.py
python tests/dimension_manager_test.py
python tests/dimension_dependency_graph_test.py
```
**期望结果**：总计 24 项单测全部 OK.

### 3. 运行宿主契约与打包规范测试
```powershell
npm test
```
**期望结果**：68 项契约测试全部 PASS (policy: 27, mcp: 13, schema: 16, package: 12).

### 4. 运行 SolidWorks 真实综合实机验证套件
> **前置条件**：SolidWorks 前台处于就绪状态，已连接单线程单元 STA。
```powershell
python tests/real_cad/night_07_verification.py --authorize-cad-write
```
**期望结果**：
- 阶段二/三 状态机与STA隔离: PASS
- 阶段四 真实特征树物理回滚: PASS
- 阶段五 工程图生成与重开闭环: PASS
- 阶段六 分批资源压测无泄漏: PASS
- 基线文档归位与零残留: PASS
- 进程退出码 0，全量物证保存于 `tests/real_cad/sandbox/night_07/evidence_night07.json`。
