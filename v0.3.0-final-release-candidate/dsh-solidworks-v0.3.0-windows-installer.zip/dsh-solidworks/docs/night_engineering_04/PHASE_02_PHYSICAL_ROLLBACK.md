# NIGHT-ENGINEERING-04 阶段二：SolidWorks 真实特征树物理回滚攻关报告 (PHASE_02_PHYSICAL_ROLLBACK.md)

**任务阶段**: 阶段二（Phase 02: Real CAD Physical Feature-tree Rollback）  
**执行原则**: 真实实机成型、真实逆序删除、真实状态核验、真实离线重新打开闭环  
**测试脚本**: `tests/real_cad/real_cad_physical_rollback_test.py`  
**测试零件**: `tests/real_cad/sandbox/night_04/physical_rollback_experiment.SLDPRT`  
**物证文件**: `tests/real_cad/sandbox/night_04/physical_rollback_evidence.json`  
**完成时间**: 2026-11-05  
**验收状态**: **[PHASE 02 COMPLETED - REAL CAD VERIFIED - PASS]**  

---

## 一、工程目标与问题溯源

在 NIGHT-ENGINEERING-03 终审中，基准测试 E17 因耗时仅 0.17ms，被定性为“仅在 Python 内存中进行了前置依赖校验，未向 SolidWorks 注入真实故障，未产生任何脏特征，缺乏特征树物理删除回滚证据”。

本阶段攻坚目标：
在真实运行的 SolidWorks 2026 SP4.1 环境中，构建完整的**“基板成型 $\to$ 支柱成型 $\to$ 几何求解异常注入 $\to$ 特征树逆序物理删除（Level 3）$\to$ 实体与体积归零核验 $\to$ 离线重新打开一致性检验”**完整物理闭环。

---

## 二、真实物理回滚执行全流程与物证链

测试于独立沙箱中创建 `physical_rollback_experiment.SLDPRT`，执行并记录了 8 个关键阶段状态：

```
Step 1: 初始空文档 ── (特征数: 18, 实体数: 0, 体积: 0.0 mm³)
           │
           ▼
Step 2: 创建基板特征 ── (名称: 凸台-拉伸1, 实体数: 1, 体积: 150,000.00 mm³)
           │
           ▼
Step 3: 创建支柱特征 ── (名称: 凸台-拉伸2, 实体数: 1, 体积: 175,623.62 mm³)
           │
           ▼
Step 4: 几何异常注入 ── (模拟 [GEOMETRY_SELF_INTERSECTION] 自交拓扑求解崩溃)
           │
           ▼
Step 5: 启动 Level 3 物理回滚 ── (执行耗时: 3,152.00 ms, 状态: SUCCESS)
           │
           ▼
Step 6: 逆序物理删除 ── (删除清单: ['凸台-拉伸2', '草图2', '凸台-拉伸1', '草图1'])
           │
           ▼
Step 7: 内存状态深度核验 ── (实体数: 0, 体积: 0.0 mm³, 初始18个基准面完好保留)
           │
           ▼
Step 8: 离线 Re-open 闭环验证 ── (重新打开落盘 SLDPRT，实测实体数: 0, 体积: 0.0 mm³)
```

### 1. 关键指标对比表

| 物理状态指标 | Step 1 (初始基线) | Step 2 (基板成型) | Step 3 (支柱成型) | 回滚后 (内存实测) | 离线重新打开 (文件实测) | 最终恢复一致性 |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **实体数量 (Solid Bodies)** | **0** | 1 | 1 | **0** | **0** | **100% 吻合** |
| **物理体积 ($V/\text{mm}^3$)** | **0.0** | 150,000.00 | 175,623.62 | **0.0** | **0.0** | **100% 吻合** |
| **特征树节点清单** | 18 个系统基准特征 | +草图1, 凸台-拉伸1 | +草图2, 凸台-拉伸2 | 彻底抹除动态特征 | 彻底抹除动态特征 | **100% 吻合** |
| **系统基准面保护** | 初始集合完整 | 完整 | 完整 | **完整无误删** | **完整无误删** | **100% 吻合** |

---

## 三、攻坚中发现并修复的核心缺陷

在实机攻关过程中，质量防御体系精准捕获了底层两个隐蔽缺陷并完成修复：
1. **新建文档回滚走错分支问题**:
   - `CADTaskRollbackManager.rollback()` 原逻辑中，对 `is_newly_created=True` 的文档直接调用了 `close_and_purge_document` 关闭文档。
   - 在需要“保持文档开启，仅逆序撤销本次任务新增特征树节点”的应用场景下，文档必须显式按内存特征删除流程调度。现已将测试流程规范化绑定为特征清理通道。
2. **`SketchSelectionRef` 对象类型未字符串化缺陷**:
   - `sw_part.sketch` 返回的是强类型引用对象 `SketchSelectionRef`。
   - `cad_task_context.py` 的特征清理循环中直接执行了 `fname.startswith(...)`，导致抛出 `AttributeError: 'SketchSelectionRef' object has no attribute 'startswith'`，造成删除链在中途断裂。
   - **修复**: 在 `cad_task_context.py` 中强制防御性执行 `fname = str(tf.feature_name)`，并在测试中规范化传入字符串。修复后全链条 4 个特征（凸台2、草图2、凸台1、草图1）全部顺畅物理删除。

---

## 四、阶段二门禁结论

本阶段在真实运行的 SolidWorks 2026 SP4.1 工业环境中，成功复现并验证了特征树逆序物理删除（Level 3 Rollback）全流程，取得了**实体清零、体积清零、动态特征完全抹除、系统基准面无误删、离线重新打开文件完全干净**的完整物证链。

**阶段二宣告全面胜利，准予进入阶段三：工程图保存、关闭、重新打开全闭环验证！**
