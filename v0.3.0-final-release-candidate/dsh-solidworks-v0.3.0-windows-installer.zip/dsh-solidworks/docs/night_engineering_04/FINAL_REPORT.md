# NIGHT-ENGINEERING-04: 测试可信度修复与真实物理回滚攻关最终总结报告

## 一、项目与任务概况

- **项目名称**：`dsh-solidworks` (`dsh-solidworks-plugin`)
- **任务编号**：`NIGHT-ENGINEERING-04`
- **执行目标**：基于 NIGHT-03 终审提出的关键质疑，攻克测试可信度弱断言、实现并验证 SolidWorks 真实特征树物理回滚、闭环 2D 工程图重新打开反向核验、统一新旧尺寸管理体系。
- **环境信息**：Windows 11 Pro 64-bit / SolidWorks 2026 SP4.1 Real CAD / Python 3.13.1 (STA Worker) / Node.js v24.21.0
- **执行结论**：**全阶段验收全量通过 (ALL PASS)**。

---

## 二、四大攻关阶段完成情况与核心证据

### 1. 阶段一：测试断言可信度修复与口径澄清 (Phase 01)
- **E07 混合加工修复**：
  - **历史缺陷**：原测试中 `chamfer: false` 却依然判定为 PASS，断言只检查了 `v_act > 0`。
  - **工程修复**：接入 `sw_edge_select.select_edges`，分别独立选择平行于 X 轴与 Z 轴的直边，独立调用 `fillet` 与 `chamfer`；建立独立严格断言：`res['fillet'] is True`、`res['chamfer'] is True` 以及实际体积必须严格小于毛坯体积且在合理公差内（$95000 < V_{\text{act}} < 100000\text{ mm}^3$）。
  - **实机运行结果**：实机 4 条边圆角生成、4 条边倒角生成，毛坯体积 $100,000.0\text{ mm}^3$，实际体积 $99,239.19\text{ mm}^3$，体积削减 $760.81\text{ mm}^3$，实机判定 **[✔ PASS]** (耗时 11939.1ms)。
- **E11 质心偏差修复**：
  - **历史缺陷**：`cz_diff = 35.0mm` 却判定 PASS，测试断言故意漏写了 `cz_diff`。
  - **根因查清**：SolidWorks `Top Plane` 的拉伸法向沿 Y 轴，厚度理论质心在 $c_y = -10.0\text{ mm}$，原作者误将其作为 $c_z$ 的理论值。
  - **工程修复**：校正三维理论空间模型（$c_x = 50.0, c_y = -10.0, c_z = -25.0$），全面断言三轴对称绝对误差与体积误差均严格 $< 1.0\text{ mm}$。
  - **实机运行结果**：$c_x$ 误差 $0.0\text{ mm}$，$c_y$ 误差 $0.0\text{ mm}$，$c_z$ 误差 $0.0\text{ mm}$，体积误差 $0.0\text{ mm}^3$，实机判定 **[✔ PASS]** (耗时 5444.5ms)。
- **Python 51 vs 111 统计口径全景查清**：
  - 查实项目 `tests/` 目录现有 16 个测试模块共 111 个用例。历史日志 `task-2281.log` 证实全量运行记录为 `Ran 111 tests in 553.758s OK`。历史报告中“51/51”源于 P1.0 早期阶段性基线快照残留，已澄清统一口径。

### 2. 阶段二：SolidWorks 真实特征树物理回滚攻关 (Phase 02)
- **攻关难点**：历史测试仅在代码编译期或文档关闭层面做拦截，缺乏在单文档运行过程中对已生成的几何特征执行真实逆向物理删除的证据。
- **实机攻关方案**：编写独立测试 `tests/real_cad/real_cad_physical_rollback_test.py`。
  1. 新建零件文档，记录初始系统基准特征数（18 个），实体数（0），体积（0.0）；
  2. 真实创建基板 `凸台-拉伸1`（体积 $150,000.0\text{ mm}^3$）；
  3. 真实创建支柱 `凸台-拉伸2`（体积增至 $175,623.62\text{ mm}^3$）；
  4. 故意注入几何拓扑自交与无法求解异常并精确捕获；
  5. 触发 `CADTaskRollbackManager` 与 `FeatureCleanupManager.cleanup_document_features` 执行 Level 3 特征树逆序物理删除；
  6. 耗时 3152.0ms，成功逆序物理删除 `['凸台-拉伸2', '草图2', '凸台-拉伸1', '草图1']`。
- **双重核验判定**：
  - **内存运行时物理核验**：实体数归零（0），体积归零（0.0），初始 18 个基准特征完好无误删；
  - **离线重新打开反向核验**：将回滚后模型落盘为 `physical_rollback_experiment.SLDPRT` 并断开会话重新载入，实体数依然为 0，体积依然为 0.0，清洁度一致性 100% 通过！判定 **[PASS]**。
- **物理物证**：`tests/real_cad/sandbox/night_04/physical_rollback_evidence.json`。

### 3. 阶段三：2D 工程图重新打开闭环与渲染验证 (Phase 03)
- **攻关难点**：历史工程图测试未验证离线重新打开能力，且缺少离线审阅物证。
- **实机攻关方案**：编写独立测试 `tests/real_cad/real_cad_drawing_reopen_test.py`。
  1. 建立源零件 `drawing_source_bracket.SLDPRT` 并保持会话活动；
  2. 新建工程图并投影标准正交三视图（主视图、俯视图、侧视图）；
  3. 调用 `sw_drawing.export_sheet_to_pdf`，通过强类型 VARIANT 封送导出 50,402 Bytes 的矢量 PDF 渲染证据 `drawing_render_preview.pdf`；
  4. 落盘保存工程图 `reopen_verified_drawing.SLDDRW`（82,647 Bytes）；
  5. 彻底关闭工程图与零件，切断所有内存缓存；
  6. **核心闭环反向验证**：调用 `open_document` 从磁盘重新载入工程图，内省核验重新打开后的视图结构。
- **核验数据**：
  - 重新打开耗时：2070.0ms；
  - 重新打开后视图列表：`['工程图视图1', '工程图视图2', '工程图视图3']`；
  - 视图总数 3/3，视图包围盒读取率 3/3，模板与图幅完整识别，判定 **[PASS]**。
- **物理物证**：`tests/real_cad/sandbox/night_04/drawing_reopen_evidence.json`。

### 4. 阶段四：新旧尺寸管理体系安全迁移与统一门面 (Phase 04)
- **架构融合设计**：
  - 确立统一门面与委托代理架构（Unified Façade & Delegation Architecture）；
  - `dimension_manager.py` 对外保持现有 API 签名与字典结构 100% 不变；
  - 内部核心全面依托新 P1 引擎：
    - `identify_dimensions` 优先调用 `dimension_reader.read_model_dimensions`，生成 `DimensionModelIR`，并平滑转为兼容字典；
    - `inspect_dimension_impact` 引入 `DimensionDependencyGraph`（DDG），提供有向拓扑偏序、从动特征链与循环依赖检测；
    - `modify_dimensions_safe` 保留影子备份与参数级快照双保险事务，严格调用 `SetSystemValue3`，遇到几何重构失败抛出 `DimensionUpdateError` 并无损恢复；
  - 统一 SI（米）与工程（毫米）换算，无缝兼容。
- **测试回归验证**：
  - 历史 21 项尺寸系统单测 100% 全部通过；
  - 新增 `tests/unified_dimension_migration_test.py` 3 项迁移测试全部通过；
  - 累计 24 项尺寸测试全绿通过。

---

## 三、代码规范与打包契约保持

运行 Node.js 完整测试套件：
```powershell
npm.cmd test
```
- `tests/policy.test.js`: 27/27 PASS
- `tests/mcp.test.js`: 13/13 PASS
- `tests/schema.test.js`: 16/16 ALL PASS
- `tests/package.test.js`: 12/12 PASS
- **总计**：**68 项测试 100% 全部通过 (0 failures, 0 errors)**。
- **打包安全检查**：
  - 构建机绝对路径泄漏：**0 处**；
  - 临时构建垃圾残留：**0 处**；
  - 文件白名单与 `NOTICE` 计数契约保持 100% 一致。

---

## 四、权威回答用户关心的核心问题

### Q1: NIGHT-ENGINEERING-02 与历史测试中的断言缺陷是否彻底修复？
**答：是，彻底修复并经实机验证。**
- E07 不再允许部分成功冒充整体成功：显式选边执行圆角与倒角，独立断言两个特征的存在，并断言实际体积小于毛坯体积（体积真实削减 760.81 mm³），实机 100% 通过。
- E11 质心 35mm 偏差彻底查清：查明系 Top Plane 沿 -Y 轴拉伸导致的空间坐标系方向偏差，现已校正三维理论模型，严格断言 $c_x, c_y, c_z$ 三轴对称绝对误差与体积误差均 $< 1.0\text{ mm}$，实机误差全部为 $0.0\text{ mm}$，真实通过。
- Python 测试数量统计澄清统一：全量用例为 111 项，历史快照 51 项系早期基线，全量回归无遗漏。

### Q2: SolidWorks 真实物理回滚是否真正实现？
**答：是，实现了单文档会话内特征树的真实逆序物理删除。**
- 在活动文档中真实建立了基板与支柱两级特征，在注入故障后，`CADTaskRollbackManager` 与 `FeatureCleanupManager` 成功逆序删除了 `['凸台-拉伸2', '草图2', '凸台-拉伸1', '草图1']`。
- 内存核验实体数归零、体积归零；落盘并重新打开核验实体数依然为 0。有落盘 `.SLDPRT` 模型和 JSON 审计时序物证为凭。

### Q3: 2D 工程图是否真正生成并且能够重新打开？
**答：是，完成了保存、关闭、离线重新打开的反向核验证据闭环。**
- 真实导出了 50,402 Bytes 的矢量 PDF 离线审阅证据。
- 将工程图落盘为 82,647 Bytes 的 `.SLDDRW` 文件并关闭所有文档句柄。
- 调用 `open_document` 重新载入，内省核验重新打开后的主视图、俯视图、侧视图完整无损，视图包围盒读取率 100%，模板与图幅识别完好。

### Q4: 新旧尺寸管理体系是否已统一且无破坏性变更？
**答：是，采用统一门面与委托代理架构。**
- `dimension_manager.py` 保持现有 API 签名与输出字段 100% 向后兼容，历史调用方无需改动任何代码。
- 内部全面委托新版 `dimension_reader`, `DDG`, `dimension_modifier`，输出高保真 `DimensionModelIR` 与拓扑偏序分析。
- 严格遵循 SI（米）与毫米换算规范，所有 24 项尺寸测试全绿通过。

### Q5: 当前代码是否达到发布与继续开发的工程标准？
**答：达到。**
- 真实 CAD 写入严格隔离在独立沙箱中，白名单零件零写入；
- Node.js 打包契约、MCP 协议、安全策略层与 Python 业务层全绿（68 + 24 + 实机用例全部通过）；
- 0 路径泄漏、0 构建垃圾、物证链与哈希清单齐备。

---

## 五、交付物与物证索引

1. `docs/night_engineering_04/PHASE_01_TEST_CREDIBILITY.md`
2. `docs/night_engineering_04/PHASE_02_PHYSICAL_ROLLBACK.md`
3. `docs/night_engineering_04/PHASE_03_DRAWING_REOPEN.md`
4. `docs/night_engineering_04/PHASE_04_DIMENSION_MIGRATION.md`
5. `docs/night_engineering_04/TEST_RESULTS.json`
6. `docs/night_engineering_04/FILE_CHANGE_LEDGER.md`
7. `docs/night_engineering_04/FILE_HASH_MANIFEST.json`
8. `docs/night_engineering_04/FINAL_REPORT.md` (本报告)
9. 沙箱物证：`tests/real_cad/sandbox/night_04/`（含回滚模型、工程图模型、渲染 PDF 及物证 JSON）
