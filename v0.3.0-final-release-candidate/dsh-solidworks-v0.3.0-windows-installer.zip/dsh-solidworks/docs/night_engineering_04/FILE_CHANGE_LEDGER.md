# NIGHT-ENGINEERING-04: 文件变更总台账 (File Change Ledger)

本文档记录在 NIGHT-ENGINEERING-04（测试可信度修复与真实物理回滚攻关）执行周期内涉及的所有文件变更，严格遵循变更可追溯原则与只读保护约束。

---

## 1. 变更摘要

- **涉及核心源码修改**：3 个
- **涉及测试套件新增/修改**：3 个
- **交付文档与物证新增**：9 个
- **白名单只读模型受保护情况**：`垫圈.SLDPRT`, `螺母 GB_T 6170 M10.SLDPRT` 零写入、零篡改。
- **Git 树完整性**：严禁并未使用 `git reset`、`git clean` 或任何破坏性指令。

---

## 2. 变更详细明细

| 序号 | 文件路径 | 变更类型 | 变更原因与工程影响 |
| :--- | :--- | :--- | :--- |
| 1 | `vendor/solidworks-automation-skill/scripts/sw_connect.py` | 修改 | 在 `connect_solidworks` 入口处增加 STA Worker 线程路由判断，避免主线程获取的 COM 接口在封送至 Worker 时产生 `0x8001010E` 代理错误与卡死。 |
| 2 | `vendor/solidworks-automation-skill/scripts/cad_task_context.py` | 修改 | 在 `cleanup_document_features` 中对 `tf.feature_name` 进行 `str()` 防御性转换，解决草图强类型对象直接传入时的 `.startswith` 异常。 |
| 3 | `vendor/solidworks-automation-skill/scripts/dimension_manager.py` | 重构修改 | 统一新旧尺寸管理体系，建立统一门面与委托代理架构。保持原有 API 契约 100% 兼容，内部委托给 `dimension_reader`, `DDG`, `dimension_modifier`。 |
| 4 | `tests/real_cad/real_cad_benchmark_suite.py` | 修改 | 修复 E07 选边与严格双重断言（圆角+倒角独立校验，体积削减断言）；校正 E11 Top Plane 理论质心坐标系（沿 -Y 轴），严格断言三轴对称绝对误差 $< 1.0\text{ mm}$。 |
| 5 | `tests/real_cad/real_cad_physical_rollback_test.py` | 新增 | Phase 02 独立实机真实物理回滚测试脚本。完成基板+支柱创建、故障注入、特征树逆序物理删除与离线重开反向核验。 |
| 6 | `tests/real_cad/real_cad_drawing_reopen_test.py` | 新增 | Phase 03 独立实机工程图生命周期验证脚本。完成工程图建立、正交三视图投影、PDF 矢量渲染导出、关闭落盘与离线重新打开反向核验。 |
| 7 | `tests/unified_dimension_migration_test.py` | 新增 | Phase 04 新旧尺寸管理体系平滑迁移单元测试，验证门面类导出、DDG 依赖图支持与 SI/mm 单位换算。 |
| 8 | `docs/night_engineering_04/PHASE_01_TEST_CREDIBILITY.md` | 新增 | Phase 01 测试可信度修复审计与断言加固技术报告。 |
| 9 | `docs/night_engineering_04/PHASE_02_PHYSICAL_ROLLBACK.md` | 新增 | Phase 02 SolidWorks 真实物理回滚攻关与反向核验证据报告。 |
| 10 | `docs/night_engineering_04/PHASE_03_DRAWING_REOPEN.md` | 新增 | Phase 03 2D 工程图保存、关闭、重新打开与渲染验证闭环报告。 |
| 11 | `docs/night_engineering_04/PHASE_04_DIMENSION_MIGRATION.md` | 新增 | Phase 04 新旧尺寸管理体系平滑迁移与统一门面兼容性报告。 |
| 12 | `docs/night_engineering_04/TEST_RESULTS.json` | 新增 | NIGHT-04 全量结构化测试数据、持续时间与断言判定汇总。 |
| 13 | `docs/night_engineering_04/FILE_CHANGE_LEDGER.md` | 新增 | 本文件，全流程变更总台账。 |
| 14 | `docs/night_engineering_04/FILE_HASH_MANIFEST.json` | 新增 | 包含所有交付物与修改文件的 SHA-256 哈希清单与字节大小。 |
| 15 | `docs/night_engineering_04/FINAL_REPORT.md` | 新增 | NIGHT-ENGINEERING-04 最终技术验收与决策响应终审报告。 |

---

## 3. 独立沙箱实机物理物证

所有真实 CAD 写入均限制在独立沙箱目录 `tests/real_cad/sandbox/night_04/` 中：
- `physical_rollback_experiment.SLDPRT`：物理回滚后落盘验证模型（实体数为 0，初始基准特征完好）。
- `physical_rollback_evidence.json`：实机物理回滚全量时序与内存核验数据。
- `drawing_source_bracket.SLDPRT`：工程图投影源零件。
- `reopen_verified_drawing.SLDDRW`：重新打开验证成功的工程图文件（82,647 Bytes）。
- `drawing_render_preview.pdf`：工程图导出的离线审阅矢量 PDF（50,402 Bytes）。
- `drawing_reopen_evidence.json`：重新打开前后视图结构对比物证。
