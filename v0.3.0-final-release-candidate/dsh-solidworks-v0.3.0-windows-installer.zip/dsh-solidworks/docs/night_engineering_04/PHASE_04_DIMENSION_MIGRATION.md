# NIGHT-ENGINEERING-04 Phase 04: 新旧尺寸管理体系安全迁移与统一架构报告

## 1. 迁移背景与核心目标

在 NIGHT-03 终审与历史代码梳理中发现，项目中并存两套尺寸管理逻辑：
1. **历史旧体系**：`vendor/solidworks-automation-skill/scripts/dimension_manager.py` 与 `sw_document_data.py`。
   - 优点：被多个 MCP 工具和历史测试直接引用，契约成熟；
   - 缺陷：采用松散字典结构，缺乏草图尺寸与特征尺寸语义类型推断，影响面分析仅基于特征线性链表，无循环依赖检测。
2. **P1 阶段六大新模块**：
   - `dimension_ir.py`：Pydantic 驱动的强类型中间表示 `DimensionModelIR` 与 `DimensionIRNode`；
   - `dimension_reader.py`：递归遍历特征与子特征，自动推断几何语义类型（拉伸深度、切除深度、草图尺寸等）；
   - `dimension_dependency_graph.py` (DDG)：参数与特征双向有向依赖图，支持拓扑排序与零漂移验证；
   - `dimension_modifier.py`：具备内存参数逆向自愈与磁盘影子还原双重保险的原位参数修改器；
   - `model_rebuilder.py`：三级渐进式几何重构与实体数健康核验；
   - `dimension_validator.py`：容差核对与修改漂移验证。

**本阶段核心目标**：
采用**统一门面与委托代理架构 (Unified Façade & Delegation Architecture)**，将 `dimension_manager.py` 升级为面向全工程的统一入口：
- 保证旧接口、参数签名、返回值字典结构 **100% 向后兼容**；
- 内部核心实现全面依托并代理新版 P1 模块的强类型与高阶算法；
- 统一 SI（米）与工程（毫米）单位换算标准，杜绝数值偏差；
- 消除两套代码并存造成的维护脱节与行为不一致。

---

## 2. 统一架构设计与委托关系

```
[外部调用方: FastMCP Server / Benchmark / Agent Skill]
                        │
                        ▼
   ┌──────────────────────────────────────────────┐
   │ vendor/.../scripts/dimension_manager.py      │
   │ (Unified Façade & Backward-Compatible API)   │
   └──────┬───────────────┬────────────────┬──────┘
          │ (识别)         │ (影响面分析)    │ (就地修改)
          ▼               ▼                ▼
   ┌──────────────┐ ┌──────────────┐ ┌────────────────┐
   │DimensionReader│ │     DDG      │ │DimensionModifier│
   │ & ModelIR    │ │ & Topo Order │ │& ShadowBackup  │
   └──────────────┘ └──────────────┘ └────────────────┘
```

### 2.1 接口映射与平滑委托规范

| 统一门面接口 | 委托代理目标 | 兼容保证机制 | 高阶扩展字段 |
| :--- | :--- | :--- | :--- |
| `identify_dimensions(model)` | `dimension_reader.read_model_dimensions` | 返回标准 `dimensions` 列表与 `dimension_map`，异常时自动降级兼容引擎 | `model_ir`, `ir_available: True` |
| `inspect_dimension_impact(model, dim)` | `DimensionDependencyGraph` (DDG) | 返回 `owner_feature`, `potential_impacted_features`, `impact_count` 等原有字段 | `ddg_supported`, `has_cycles`, `topological_rebuild_order` |
| `modify_dimensions_safe(model, updates, ...)` | `update_dimension_mm` + `ShadowBackupManager` + `ForceRebuild3` | 失败抛出标准 `DimensionUpdateError` 并无损恢复影子备份；成功返回原装字典 | `architecture: "unified_p1_façade"` |

### 2.2 单位制与原位修改原则
- **SI 单位统一**：内部与 COM 交互严格使用 SI 单位（米/弧度），外部输入输出严格统一使用毫米（$\text{mm} = \text{m} \times 1000.0$）。
- **杜绝伪修改**：所有尺寸修改严格调用 `SetSystemValue3`，绝对禁止通过删除已有特征并重新建模冒充原位修改。

---

## 3. 验证结果与物证

### 3.1 单元测试全量回归
运行命令：
```powershell
python -m unittest discover -s tests -p "*dimension*"
```
测试结果：
- `tests/dimension_manager_test.py`: 5 项测试 全部通过 [PASS]
- `tests/dimension_system_test.py`: 6 项测试 全部通过 [PASS]
- `tests/dimension_dependency_graph_test.py`: 10 项测试 全部通过 [PASS]
- `tests/unified_dimension_migration_test.py`: 3 项新增迁移测试 全部通过 [PASS]
- **总计**：**24 项尺寸系统测试 100% 全部通过 (0 errors, 0 failures)**。

---

## 4. 结论

旧体系与新 P1 尺寸体系已通过门面适配模式彻底融合，历史测试 100% 保持绿色，且任何新功能均可直接通过 `dimension_manager` 访问 `DimensionModelIR`、`DDG` 与高精度重构能力。
