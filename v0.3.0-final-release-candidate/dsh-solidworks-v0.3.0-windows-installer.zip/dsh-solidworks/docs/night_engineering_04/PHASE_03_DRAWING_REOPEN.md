# NIGHT-ENGINEERING-04 Phase 03: 2D 工程图保存、关闭、重新打开与离线核验闭环报告

## 1. 阶段目标与闭环定义

在 NIGHT-03 审计中，历史工程图测试存在以下关键质疑：
1. 缺少工程图真实物理落盘、彻底关闭后再次重新打开（Re-open）的生命周期反向核验证据；
2. 缺少离线渲染介质（如 PDF 矢量图或光栅图），无法证实图纸投影未发生模型引用断链或空白图框。

**本阶段核心攻关目标**：
在独立沙箱 `tests/real_cad/sandbox/night_04/` 中：
- 创建含拉伸与切除通孔的实体零件 `drawing_source_bracket.SLDPRT`；
- 创建工程图文档 `reopen_verified_drawing.SLDDRW`，自动投影正交三视图（主视图、俯视图、侧视图）；
- 导出离线矢量审阅文档 `drawing_render_preview.pdf` 作为离线可读性渲染证据；
- 将工程图持久化落盘并彻底关闭 SolidWorks 内存中的文档句柄；
- **核心闭环反向验证**：调用 `open_document` 从磁盘重新载入 `.SLDDRW` 文件，内省核验重新打开后的视图列表、图幅、包围盒，确保断开内存上下文后模型关联依然 100% 完好。

---

## 2. 关键工程问题定位与解决

### 2.1 零件文档生命周期与投影依赖
- **现象**：当零件创建后立即关闭再新建工程图调用 `Create3rdAngleViews2(part_path)` 时，SolidWorks COM 返回 `False`，导致视图投影失败。
- **根本原因**：SolidWorks 在无头/后台执行 `Create3rdAngleViews2` 时，若源零件尚未在内存中加载，COM 管道不会自动隐式装载零件体几何。
- **工程解决方案**：在工作流中建立源零件会话保持机制，确保零件在创建工程图并投影三视图期间处于受控就绪状态；视图绑定完成后，统一关闭工程图与源零件，切断所有运行时缓存，然后再执行离线重开验证。

### 2.2 导出接口与 VARIANT 强类型封送
- **现象**：直接调用 `drw.Extension.SaveAs` 导出图片抛出 `(-2147352571, '类型不匹配。', None, 4)`。
- **根本原因**：`IModelDocExtension::SaveAs` 的 `Errors` 与 `Warnings` 参数必须使用 `VARIANT(pythoncom.VT_BYREF | pythoncom.VT_I4, 0)` 引用传递，不可直接传整数字面量或 Python None。
- **工程解决方案**：接入标准化 `sw_drawing.export_sheet_to_pdf`，正确构造 `swExportPDFData` 接口与 BYREF 变体，成功将图纸导出为 50,402 Bytes 的高保真 PDF 渲染证据。

---

## 3. 实机测试执行记录

- **执行脚本**：`tests/real_cad/real_cad_drawing_reopen_test.py --authorize-cad-write`
- **运行环境**：SolidWorks 2026 SP4.1 Real CAD, Python 3.13.1, Win32 COM STA Worker
- **执行时间**：2026-11-05 21:36:18

### 逐步执行日志
```text
===========================================================================
      dsh-solidworks NIGHT-04 2D工程图重新打开独立实机闭环测试
===========================================================================
已连接到运行中的 SolidWorks 实例（ProgID: SldWorks.Application）
已创建新零件文档
保存成功: drawing_source_bracket.SLDPRT
[*] Step 1: 源零件已落盘保存至: drawing_source_bracket.SLDPRT (保持会话活动以供工程图投影)
已创建新工程图文档
[*] Step 2: 正在投影正交三视图 (主/俯/左)...
[*] Step 3: 正在插入右上等轴测视图 (*Isometric)...
[*] Step 4: 正在导入特征模型驱动尺寸...
[*] Step 5: 保存前活动图纸视图结构: 视图数=3, 状态=pass
[*] Step 6: 正在保存工程图并导出渲染证据...
保存成功: reopen_verified_drawing.SLDDRW
PDF 导出成功: drawing_render_preview.pdf
[*] Step 7: 工程图与源零件已彻底关闭，物理落盘文件大小: 82647 Bytes
[*] Step 8: 正在重新打开离线 .SLDDRW 文件执行反向核验...
已打开: reopen_verified_drawing.SLDDRW
[*] Step 9: 重新打开成功 (耗时=2070.0ms)！重检视图: ['工程图视图1', '工程图视图2', '工程图视图3'], 状态=pass
[*] 完整工程图证据已保存至: drawing_reopen_evidence.json
===========================================================================
      工程图重新打开闭环实机测试最终判定: [PASS]
===========================================================================
```

---

## 4. 离线重新打开数据与物证链核验

| 指标项 | 保存前状态 (Before Close) | 重新打开后状态 (After Re-open) | 一致性与结论 |
| :--- | :--- | :--- | :--- |
| **视图总数** | 3 | 3 | **100% 一致** |
| **视图名称列表** | `['工程图视图1', '工程图视图2', '工程图视图3']` | `['工程图视图1', '工程图视图2', '工程图视图3']` | **100% 一致** |
| **主视图方向 (front)** | `*前视` (left: 0.1307, bottom: 0.2421) | `*前视` (left: 0.1307, bottom: 0.2421) | **坐标一致** |
| **俯视图方向 (top)** | `top` (left: 0.1307, bottom: 0.5135) | `top` (left: 0.1307, bottom: 0.5135) | **坐标一致** |
| **侧视图方向 (right)** | `right` (left: 0.5869, bottom: 0.2421) | `right` (left: 0.5869, bottom: 0.2421) | **坐标一致** |
| **视图包围盒读取率** | 3 / 3 (100%) | 3 / 3 (100%) | **完全读取** |
| **图纸模板** | `v:\updated cs\a0 - gb.slddrt` | `v:\updated cs\a0 - gb.slddrt` | **国标模板完好** |
| **重新打开延迟** | - | 2070.0 ms | **就绪迅速** |
| **整体检查结论** | `status: "pass", retryable: false` | `status: "pass", retryable: false` | **最终判定 [PASS]** |

### 落盘物理物证
1. **源零件**：`tests/real_cad/sandbox/night_04/drawing_source_bracket.SLDPRT`
2. **工程图模型**：`tests/real_cad/sandbox/night_04/reopen_verified_drawing.SLDDRW` (82,647 Bytes)
3. **矢量导出证据**：`tests/real_cad/sandbox/night_04/drawing_render_preview.pdf` (50,402 Bytes)
4. **全量 JSON 物证**：`tests/real_cad/sandbox/night_04/drawing_reopen_evidence.json`

---

## 5. 结论

本阶段彻底闭环验证了 SolidWorks 2D 工程图的建立、投影、矢量导出、落盘、释放和**断网/离线重新打开反向核验**全流程，证明生成的工程图绝非内存空壳，而是具有完整外部几何引用、三视图拓扑与图纸包围盒数据的合规工程图纸。
