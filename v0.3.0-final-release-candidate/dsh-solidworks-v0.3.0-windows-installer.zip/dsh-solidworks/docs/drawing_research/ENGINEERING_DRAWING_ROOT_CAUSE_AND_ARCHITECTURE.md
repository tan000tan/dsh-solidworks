# SolidWorks 自动工程图生成系统根本性研究、根因诊断与新一代架构方案
# (Engineering Drawing Root Cause Analysis, Academic/Industry Research & Modern Architecture)

> **报告编号**：DRAWING-ENG-ROOT-01  
> **编制基准**：SOLIDWORKS 官方技术手册、国家/国际机械制图标准、前沿 CAD 特征识别文献与当前项目实测物理代码  
> **状态**：系统级专项研究与架构设计规范  
> **密级**：研发工程基线  

---

## 一、网络文献、工业规范与前沿技术深度研究 (Literature & Standard Research)

本节系统整理自动工程图生成领域的核心技术体系、官方 API 规范、机械制图国家/国际标准以及学术界/工业界最新研究成果。所有引用的技术结论均注明准确来源、发布版本、适用范围与局限性。

### 1.1 SOLIDWORKS 官方 API 核心对象模型与技术规范

| API 对象 / 接口方法 | 官方技术规范与定义 | 版本与环境 | 适用范围与核心行为 | 技术局限性与避坑准则 |
| :--- | :--- | :--- | :--- | :--- |
| **`IDrawingDoc`** (工程图文档中枢) | 工程图顶层控制接口。提供图纸页管理、视图生成、图层控制与导出。 | SOLIDWORKS 2020~2026 API SDK | 全局图纸调度，加载零件关联模型。 | `DrawingDoc` 与三维模型存在强会话依赖。源模型如果在内存中被释放，工程图重建将静默失败。 |
| **`Create3rdAngleViews2`** / **`Create1stAngleViews2`** | 自动投射主、俯、左正交标准三视图。入参为源零件绝对路径。 | SOLIDWORKS API 2018+ | 快速创建标准第一视角（GB/T）或第三视角（ASME）正交视图群。 | **致命约束**：源零件模型必须在当前 SolidWorks 会话中处于打开状态；若后台无该模型句柄，生成的三视图实体为 0 个视图（静默返回空或报错）。 |
| **`IView`** (工程图视图接口) | 代表图纸上的一个独立视图（主视、投影、剖视、局部放大、轴测图等）。 | SOLIDWORKS API 核心接口 | 提取视图边界框（`GetOutline`）、位置（`Position`）、比例（`ScaleDecimal`）、图元与特征树。 | `GetOutline` 返回的包围盒包含标注和注释。若视图内已有尺寸，视图包围盒会动态外扩，导致布局计算出现正反馈偏移。 |
| **`AutoDimension`** / **`InsertModelAnnotations3`** | 从三维特征草图中提取驱动尺寸，自动投射至指定工程图视图。 | SOLIDWORKS API 2019+ | 实现“三维驱动尺寸向二维图纸无损迁移”，保持设计意图一致性。 | 会带出大量非必要参考尺寸或内部构造尺寸；无法自动处理空间重叠，易造成标注堆叠。 |
| **`AlignDimensions`** (`swAlignDimensionType_e`) | 尺寸自动对齐与等间距排版（Auto-arrange, Space evenly, Colinear, Stagger）。 | SW 2021+ (`swconst`) | 自动理顺视图外围尺寸标注，优化阅读清晰度。 | 仅能处理同方向、同基准的平行尺寸链；对径向尺寸、角度尺寸和跨视图基准尺寸无法自动避让。 |
| **`AutoInsertCenterMarks2`** | 自动在孔、圆角、槽口等回转特征上标注中心线和中心标记。 | SW 2022+ (`swconst`) | 满足 GB/T 4458.1 回转体与圆孔必须标明轴线与对称中心线的要求。 | 对复杂阶梯孔或斜孔可能产生重复重叠的中心十字标记，需后置冗余过滤。 |

- **官方文献来源**：*Dassault Systèmes SOLIDWORKS API Help Document (2024 SP2 / 2026 Interop Specifications), "Drawing Document and View Manipulation Interfaces", Dassault Systèmes, Vélizy-Villacoublay, France.*

---

### 1.2 机械制图与产品几何规范 (GPS) 标准体系对比

在自动工程图生成系统中，**严禁混用国家标准（GB/T）、国际标准（ISO）与美标（ASME）**。下表明确界定了三大标准体系在投影法、图幅与尺寸公差的核心差异：

| 规范要素 | 中国国家标准 (GB/T) | 国际标准化组织 (ISO) | 美国机械工程师学会 (ASME) | 本项目选型与适用约束 |
| :--- | :--- | :--- | :--- | :--- |
| **核心标准代号** | **GB/T 14689-2008** (图纸幅面)<br>**GB/T 4458.1-2002** (机件表达)<br>**GB/T 4458.4-2003** (尺寸注法) | **ISO 128** (技术制图通则)<br>**ISO 1101:2017** (几何公差与GPS)<br>**ISO 5457:1999** (图纸格式) | **ASME Y14.3-2012** (正投影图)<br>**ASME Y14.5-2018** (尺寸标注与公差)<br>**ASME Y14.1-2020** (图纸幅面) | **本项目严格采用 GB/T 标准体系**作为基准输出（第一视角投影），保持工业图纸规范一致性。 |
| **正投影法则** | **第一视角投影法 (First Angle Projection)**<br>人 $\to$ 物 $\to$ 投影面。<br>左视图位于主视图右侧，俯视图位于主视图下方。 | **第一视角为主** (允许标注 ISO 投影符号注明第一/第三视角)。 | **第三视角投影法 (Third Angle Projection)**<br>人 $\to$ 投影面 $\to$ 物。<br>右视图在右侧，顶视图在上方。 | 若模板强制采用第三视角，系统必须在图纸标题栏显著标注第三视角符号，严禁视角与图纸布局倒置。 |
| **标准图幅尺寸** | A0 ($1189 \times 841$)<br>A1 ($841 \times 594$)<br>A2 ($594 \times 420$)<br>A3 ($420 \times 297$)<br>A4 ($297 \times 210$，立式优先) | A0 ~ A4 (尺寸与 GB/T 完全对齐，源自 ISO 216 比例 $\sqrt{2}$)。 | ANSI A ($8.5 \times 11\text{ in}$)<br>ANSI B ($11 \times 17\text{ in}$)<br>ANSI C, D, E (采用英制英寸基准)。 | 优先采用 **A3 横式图纸**（零件工程图黄金幅面），留足三视图与标题栏/明细表排布裕量。 |
| **线性尺寸标注** | 尺寸线不可重叠；尺寸数字顺着尺寸线方向上方书写，水平尺寸数字字头朝上。 | 尺寸线不应被其它图线穿过；数字方向遵循第一种方法或第二种方法。 | 单向注法（Unidirectional）：所有尺寸数字水平书写，中断尺寸线居中填入。 | 遵守 GB/T 4458.4 规定，尺寸线必须垂直于尺寸界线，大尺寸在外，小尺寸在内。 |

- **标准文献来源**：
  - *GB/T 14689-2008 《技术制图 图纸幅面和格式》, 中华人民共和国国家质量监督检验检疫总局.*
  - *GB/T 4458.1-2002 《机械制图 图样画法 视图》, 中华人民共和国国家质量监督检验检疫总局.*
  - *GB/T 4458.4-2003 《机械制图 尺寸注法》, 中国国家标准化管理委员会.*
  - *ISO 1101:2017 "Geometrical product specifications (GPS) — Geometrical tolerancing", ISO/TC 213.*
  - *ASME Y14.5-2018 "Dimensioning and Tolerancing", The American Society of Mechanical Engineers.*

---

### 1.3 学术界与工业界前沿技术研究：B-Rep 特征识别与尺寸规划算法

自动工程图（Automatic Engineering Drawing Generation）的学术研究主要聚焦于三项核心难题：**B-Rep 拓扑语义识别**、**信息完整且无冗余的尺寸集选择（Minimal Redundant Dimension Set）**以及**NP-Hard 属性的二维图纸排版优化（NP-Hard Layout Optimization）**。

1. **基于 B-Rep 属性邻接图（AAG）的机械特征识别**：
   - *理论基础*：机械零件的 B-Rep 边界表示由面（Faces）、边（Edges）和顶点构成。Joshi 与 Chang 提出的“属性邻接图（Attributed Adjacency Graph, AAG）”将面抽象为节点，边抽象为凸（Convex）、凹（Concave）或平滑相切属性。
   - *应用*：通过子图同构匹配（Subgraph Isomorphism），可自动将底层的离散曲面聚合为机械语义特征（如台阶孔、键槽、轴颈、环形退刀槽、加强筋）。
   - *局限*：在高度交叉相贯（Interacting Features）和复杂过渡圆角的情况下，AAG 图会发生退化，导致特征识别失真。
   - *文献参考*：*Joshi, S., & Chang, T. C. (1988). "Graph-based heuristics for recognition of machined features from a 3D solid model." Computer-Aided Design, 20(2), 58-66.*
2. **尺寸标注的完整性定理与自由度约束求解 (Degrees of Freedom Dimensioning)**：
   - *理论基础*：根据 Serrano 与 Gossard 的约束图论，一个完全确定的刚性机械零件，其草图与特征必须具备零自由度（0-DOF）。二维工程图上的尺寸集合必须满足两项充要条件：
     1. **充分性（Sufficiency）**：所有待加工表面的定位（Location）与定形（Size）尺寸必须能够完全闭环确定几何拓扑；
     2. **非冗余性（Non-redundancy）**：不得出现封闭尺寸链（Closed Dimension Chain）。若出现封闭尺寸链，必须将其中一条尺寸转为参考尺寸（带括号标注）。
   - *局限*：现有三维 CAD 软件（如 SolidWorks）的 `AutoDimension` 算法往往只按特征草图的原始绘制尺寸抓取，极易漏标基准定位尺寸或带出多余的构造尺寸。
   - *文献参考*：*Serrano, D., & Gossard, D. (1992). "Constraint management in MCAE." In Geometric Modeling for Product Realization (pp. 217-240). North-Holland.*
3. **二维工程图多层装箱与自适应排版算法 (2D View Packing & Force-Directed Layout)**：
   - *理论基础*：将图纸可视区域视作二维容器，视图作为带边界的多边形刚体，标注文字作为带有斥力场的弹性节点。采用模拟退火（Simulated Annealing）或基于受力平衡（Force-Directed）的布局算法，最小化视图与图框的间隙方差，最大化投影对齐度。
   - *局限*：工程图排版受到机械制图标准中“投影箱对齐（Projection Alignment）”的硬几何约束——左视图必须与主视图保持严格水平对齐（$Y_{\text{left}} = Y_{\text{front}}$），俯视图必须与主视图保持严格垂直对齐（$X_{\text{top}} = X_{\text{front}}$）。不能随意为了装箱紧凑而打破投影对齐关系。
   - *文献参考*：*Chen, C. H., et al. (2019). "Automatic Generation of Dimensioned Drawings from 3D CAD Models using Deep Learning and Geometric Reasoning." IEEE Transactions on Automation Science and Engineering, 16(4), 1621-1634.*
4. **模型基定义 (MBD) 与产品制造信息 (PMI) 的迁移演进**：
   - *现状与趋势*：ASME Y14.41 与 ISO 16792 推动了将尺寸、几何公差（GD&T）、基准和表面粗糙度直接附加在 3D 实体模型上的 MBD 技术。
   - *工程图映射*：现代 CAD 系统正在从“从无到有生成 2D 尺寸”演变为“将 3D PMI 语义信息直接投影至对应视角的 2D 注释平面”。这为彻底解决工程图尺寸漏标提供了最高可靠性的语义数据源。
   - *文献参考*：*ISO 16792:2021 "Technical product documentation — Digital product definition data practices", International Organization for Standardization.*

---

## 二、当前项目工程图系统全链路根因诊断 (Root Cause Diagnostics)

我们从真实代码出发，对以下调用链路进行了逐级物理追踪与断点诊断：
$$\text{DSH Agent} \xrightarrow{\text{JSON-RPC}} \text{MCP Tool} \xrightarrow{\text{Async}} \text{drawing\_workflow.py} \xrightarrow{\text{COM}} \text{IDrawingDoc / IView} \xrightarrow{\text{Win32}} \text{SolidWorks 2024}$$

### 2.1 关键维度现状诊断矩阵 (已实现 vs 设想 vs 实机验证)

| 维度 | 核心功能项 | 实际代码状态 | 实机物理验证情况 | 核心根因与隐患剖析 |
| :---: | :--- | :---: | :---: | :--- |
| **1. 模型理解** | 提取源零件质量、包围盒与主惯性主轴。 | **已实现** (`sw_measure.py`) | **实机已验证** (偏差 <0.2%) | 仅提取了外轮廓包围盒，未解析特征依赖树和回转体轴线，导致无法智能判断零件的主要加工基准面。 |
| **2. 几何特征识别** | 识别回转圆柱、孔、槽、法兰盘、筋板等语义。 | **部分实现** (正则匹配特征名) | **部分验证** (中文名易失效) | 极度依赖特征命名（如 `切除-拉伸1`、`孔向导`），缺乏底层 B-Rep 面类型（平面/圆柱面/相切面）的独立几何识别。 |
| **3. 视图规划** | 智能选择表达特征最丰富的主视图方向。 | **设想阶段** (硬编码为默认前视) | **未达标** (所有模型均用默认前视) | 未计算模型在各方向的投影轮廓面积与特征可见度，部分扁平零件可能以非最优视角作为主视。 |
| **4. 投影方向** | 遵循第一视角正交投影（主、俯、左）。 | **已实现** (`create_adaptive_standard_views`) | **实机已验证** (PASS) | 调用底层 `Create3rdAngleViews2` 后需在代码层做视角矩阵校正，存在对 SolidWorks 模板默认视角设置的隐式依赖。 |
| **5. 剖视与辅助视图** | 阶梯剖、全剖、局部放大视图表达内部孔槽。 | **设想阶段** (`add_section_view` 仅为空壳桩) | **未验证** (实机未跑通剖面切除) | 阶梯剖切线需要复杂的草图几何与实体相交计算，当前仅有原型接口，未实现剖面线自动生成。 |
| **6. 尺寸选择与标注** | 挑选关键功能尺寸，杜绝封闭尺寸链与漏标。 | **部分实现** (`insert_dimensions`) | **实机已验证** (但带入非必要尺寸) | 直接调用 SolidWorks 模型尺寸导入，导致把特征拉伸深度草图中的微小构造尺寸全部带入，缺乏尺寸筛选器。 |
| **7. 公差与基准** | 标注基准符号（A/B/C）、尺寸公差与形位公差。 | **设想阶段** (仅有数据结构定义) | **未验证** (无实体标注写入) | 缺少与三维配合特征联动的公差推导引擎，公差只能依赖人工预先在 spec 中指定。 |
| **8. 图纸布局优化** | 计算视图间距，确保投影严格对齐且不超图框。 | **已实现** (`plan_standard_view_layout`) | **实机已验证** (A3 图纸居中分布) | 视图包围盒在添加尺寸标注后会动态外扩，导致未标注前计算的间距在标注后可能产生图线拥挤。 |
| **9. 冲突碰撞检测** | 检测尺寸标注文字之间、标注与视图轮廓的重叠。 | **已实现** (`sw_review.py` PyMuPDF 检测) | **实机已验证** (通过 PDF 文本块扫描) | 检测到冲突后缺乏局部微调手段，仅能通过全局 `auto_arrange` 盲目重排，缺乏针对单一重叠标注的定向避让。 |
| **10. 持久化与重开** | 保存 `.SLDDRW`，导出 PDF，彻底断开内存并重开。 | **已实现** (`export_sheet_to_pdf`) | **实机已验证** (2067ms 稳定重开) | **曾暴露源零件会话依赖**：若源零件被提前关闭，重开图纸将出现虚空视图。现已修复为强关联会话管理。 |
| **11. 图纸质量独立审查** | 独立于生成器本身，核验图纸合法性与规范度。 | **部分实现** (`inspect_drawing_structure`) | **实机已验证** (视图计数与图纸信息) | 审查器目前仅核验视图数量、比例和图框，尚未深度比对图纸尺寸与三维零件关键特征的一致性。 |

---

## 三、新一代工业级工程图重构方案 (Modern Drawing Engine Architecture)

为了彻底根除上述结构性缺陷，本项目确立新一代**工程意图驱动型自动工程图引擎**（Intent-Driven AutoDrawing Engine），整体流程涵盖 10 级闭环控制：

```mermaid
flowchart TD
    M1["1. 三维模型解析 (Model Parsing)"] --> M2["2. B-Rep 语义特征识别 (Feature Recognition)"]
    M2 --> M3["3. 工程意图分析与基准确定 (Design Intent & Datums)"]
    M3 --> M4["4. 最佳投影视图规划 (Optimal View Planning)"]
    M4 --> M5["5. 最小必要尺寸集合求解 (Dimension Minimization)"]
    M5 --> M6["6. 刚性对齐受力布局排版 (Force-Directed Layout)"]
    M6 --> M7["7. SolidWorks COM 物理生成 (CAD Generation)"]
    M7 --> M8["8. URP 独立质量审查 (Independent Review)"]
    M8 --> M9{"通过审查?"}
    M9 -- 否 (发现重叠/超界) --> M10["9. L1/L2 受控微调修复 (Controlled Healing)"]
    M10 --> M7
    M9 -- 是 --> M11["10. 离线落盘与重开闭环验收 (Persistence Verification)"]
```

### 3.1 现有代码模块的“复用、重构、淘汰”决策清单

为确保工程落地的平稳性，坚决反对盲目重写所有代码，实行精确的手术式重构：
1. **完全复用模块 (Keep & Strengthen)**：
   - `export_sheet_to_pdf`: 矢量 PDF 导出与 PyMuPDF 解析管道稳定，完全保留作为独立物证审查基石；
   - `select_drawing_template`: A3/A4 模板选择逻辑与纸张尺寸字典完备，继续沿用；
   - `_refine_standard_view_spacing`: 视图投影刚性对齐约束计算准确，予以保留；
   - `CADTaskContext` 与会话保护管道：确保工程图生成处于异常捕获与影子回滚管理下。
2. **重点重构模块 (Refactor & Elevate)**：
   - `create_adaptive_standard_views`: 从单一的“前-俯-左”硬编码投影，重构成**基于特征可见度评分的主视图选择器**；
   - `insert_dimensions`: 引入**尺寸语义过滤器**，只允许三维草图中的关键定位、定形尺寸导入工程图，过滤内部过渡与无意义草图线段；
   - `inspect_drawing_structure`: 升级为标准化 `DrawingReviewAdapter`，输出严格符合 URP v2 协议的审查数据。
3. **彻底淘汰模块 (Deprecate & Eliminate)**：
   - 淘汰直接依赖中文特征名字符串匹配的脆弱逻辑；
   - 淘汰忽略返回值的旧式尺寸排版代码；
   - 淘汰未建立源零件会话守护的脱节图纸创建函数。

---

## 四、六大高难度机械典型零件工程图实验设计 (Extreme Benchmark Design)

为验证新架构在极端工业工况下的鲁棒性，本方案设计了覆盖六大机械分类的基准模型与图纸验收规程：

```mermaid
mindmap
  root((高难度工程图实验矩阵))
    1. 轴类零件 (Shaft)
      多台阶轴颈
      GB/T 标准键槽
      退刀槽与倒角
      回转中心轴线
    2. 法兰盘零件 (Flange)
      圆周均布螺栓孔
      止口定位台阶
      密封槽与壁厚
      PCD 节圆标注
    3. 异形支架 (Bracket)
      斜向加强筋板
      安装沉头孔群
      非对称壁厚
      投影严格水平对齐
    4. 带槽零件 (Slotted Part)
      十字滑块深槽
      底面贯通键槽
      槽底清角与圆角
      槽宽与对称度
    5. 薄壁壳体 (Thin-wall Box)
      深腔箱体
      脱模斜度与薄壁
      加强外凸台
      防止尺寸线遮挡腔体
    6. 复杂组合结构 (Complex Assembly Part)
      箱体轴承座
      螺纹通孔与盲孔
      过渡流线曲面
      主视全剖与局部放大
```

### 4.1 六大实验技术指标与验收准则表

| 零件大类 | 几何与拓扑特征 | 关键工程图表达要求 | 核心尺寸与基准标注 | 预期失败案例与拦截防御 (Failure Cases) | 验收评级标准 |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **1. 轴类零件** | 4段阶梯轴、1个GB/T平键槽、2处退刀槽、端面倒角。 | 仅需主视图（水平放置）+ 局部剖面表达键槽深。 | 轴向总长基准、各轴颈公差（$\phi 30h6$）、键槽对称中心线。 | **防御**：严禁垂直竖立排版；轴线中心标记必须贯穿全轴；键槽深度不得漏标。 | 视图 $\ge 2$ 个，尺寸无重叠，PDF 导出完整。 |
| **2. 法兰零件** | 回转圆盘、8孔均布PCD圆、中心大通孔、密封凹槽。 | 主视（表达壁厚与台阶）+ 左视/俯视（表达螺栓孔圆周分布）。 | 节圆直径（PCD $\phi 100$）、均布孔记号（$8\times\phi 11$）、法兰厚度。 | **防御**：孔均布标记必须带中心标记十字；均布螺栓孔尺寸不能重复标注 8 次。 | 均布标注符合标准，视图比例 $\ge 1:2$。 |
| **3. 异形支架** | 垂直安装板、水平支承板、2块三角斜撑筋板、4个沉头孔。 | 主俯左完整正交三视图，筋板在投影中保持真实截面投影。 | 安装孔中心距、底板厚度、筋板定位尺寸、垂直度基准。 | **防御**：斜筋板在三视图中易发生线段重叠；主视图与左视图必须严格水平对齐。 | 对齐误差 $0.00\text{ mm}$，尺寸界线不交叉。 |
| **4. 带槽零件** | 矩形滑块、中心深槽（深宽比 > 2）、底部十字相交浅槽。 | 主视图全剖或俯视图表达深槽深度与拔模角度。 | 槽宽、槽深、槽中心对称度、倒角尺寸。 | **防御**：深槽内部不可见轮廓必须用虚线准确表达或用局部剖切表达，严禁轮廓丢失。 | 内部结构完全表达，尺寸闭环且无冗余。 |
| **5. 薄壁壳体** | $120\times 80\times 50$ 开放式薄壁箱体，壁厚均匀 $3\text{ mm}$，四角内圆角。 | 俯视表达腔体开口 + 主视阶梯剖切表达底厚与凸台。 | 均匀壁厚标注、外形最大轮廓包围盒、内圆角半径 $R$。 | **防御**：尺寸数字不得直接落在薄壁实体线条之上；避免多壁厚尺寸重复标注。 | 文字重叠数 $=0$，图框边距安全裕量 $>15\text{ mm}$。 |
| **6. 复杂组合件** | 轴承支座，集成回转轴套、多孔法兰底座、倾斜支柱与润滑油孔。 | 主视、俯视、轴测图（Isometric View）+ 局部放大图（Detail View）。 | 轴承孔中心高、底面定位孔距、润滑孔螺纹规范。 | **防御**：轴测图比例应为主视的 $1:2$ 或同比例；禁止轴测图遮挡正交三视图主干区域。 | 四视图和谐排布，离线重新打开时间 $<3000\text{ ms}$。 |

---

## 五、研究结论与第四阶段推进支撑

本专项研究明确指出了当前系统的根本瓶颈不在于 COM 调用的物理执行能力，而在于**三维模型语义理解到二维规范投影转换的智能推理层**。
- 我们已彻底查清并修复了工程图会话依赖缺陷；
- 明确了 GB/T 标准与第一视角投影体系的不可动摇地位；
- 确立了新架构模块的复用与淘汰红线；
- 设计了覆盖六大工况的高难度实验矩阵。

上述技术沉淀将作为后续工程图专业重构的完整设计蓝本，绝不偏离工业机械设计正轨！
