# -*- coding: utf-8 -*-
"""
scripts/submit_v030_marketplace_pr.py

DSH 插件市场 (awesome-dsh-plugin) v0.3.0 版本更新 PR 自动化创建工具。
"""
import os
import subprocess
import json
import urllib.request
import urllib.error

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC_YML = os.path.join(BASE_DIR, "docs", "submission", "tan000tan__dsh-solidworks.yml")

def log(msg):
    clean = str(msg).encode("ascii", errors="backslashreplace").decode("ascii")
    print(f"[MARKET-v0.3.0] {clean}")

def get_submission_repo():
    for d in os.listdir(BASE_DIR):
        if "备份" in d:
            p = os.path.join(BASE_DIR, d)
            for sub in os.listdir(p):
                if "awesome" in sub:
                    return os.path.join(p, sub)
    raise RuntimeError("Submission repo not found")

def get_token():
    p = subprocess.Popen(['git', 'credential', 'fill'], cwd=BASE_DIR, stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True)
    out, _ = p.communicate('protocol=https\nhost=github.com\n\n')
    for l in out.splitlines():
        if l.startswith("password="):
            return l.split("=", 1)[1].strip()
    raise RuntimeError("No token")

def main():
    log("=== 启动 DSH 插件市场 (awesome-dsh-plugin) v0.3.0 投稿更新流程 ===")
    token = get_token()
    repo = get_submission_repo()
    log(f"定位到市场投稿工作副本: {repo}")

    # 1. 还原并同步 upstream/origin main
    log("正在拉取 upstream origin main 最新提交...")
    subprocess.run(["git", "fetch", "origin", "main"], cwd=repo, check=True)

    # 2. 创建或重置 v0.3.0 更新分支
    branch_name = "feat/update-tan000tan-dsh-solidworks-v030"
    log(f"创建分支 {branch_name} 基于 origin/main ...")
    subprocess.run(["git", "checkout", "-B", branch_name, "origin/main"], cwd=repo, check=True)

    # 3. 复制并覆盖最新的 tan000tan__dsh-solidworks.yml
    dst_yml = os.path.join(repo, "data", "plugins", "tan000tan__dsh-solidworks.yml")
    with open(SRC_YML, "r", encoding="utf-8") as f:
        content = f.read()
    log(f"写入 YAML 内容:\n{content.strip()}")

    with open(dst_yml, "w", encoding="utf-8") as f:
        f.write(content)

    subprocess.run(["git", "add", "data/plugins/tan000tan__dsh-solidworks.yml"], cwd=repo, check=True)
    commit_res = subprocess.run(
        ["git", "commit", "-m", "feat(plugins): update tan000tan/dsh-solidworks to v0.3.0"],
        cwd=repo, capture_output=True, text=True
    )
    log(f"Commit 输出: {commit_res.stdout.strip()}")

    # 4. 推送到用户 GitHub Fork 仓库
    log(f"正在推送分支 {branch_name} 至 fork 远程仓库...")
    push_res = subprocess.run(
        ["git", "push", "-u", "fork", branch_name, "--force"],
        cwd=repo, capture_output=True, text=True
    )
    log(f"Push 输出: {push_res.stdout.strip()} {push_res.stderr.strip()}")

    # 5. 向官方仓库提出 Pull Request
    log("正在向 awesome-dsh-plugin/awesome-dsh-plugin 检查或创建 Pull Request...")
    api_url = "https://api.github.com/repos/awesome-dsh-plugin/awesome-dsh-plugin/pulls"
    headers = {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github.v3+json",
        "User-Agent": "Antigravity-Market-Submitter"
    }

    pr_payload = {
        "title": "feat(plugins): update tan000tan/dsh-solidworks to v0.3.0",
        "head": f"tan000tan:{branch_name}",
        "base": "main",
        "body": (
            "### Description\n"
            "Update `tan000tan/dsh-solidworks` to official productization release `v0.3.0`.\n\n"
            "### Release Highlights\n"
            "- **Zero-Configuration Installation**: One-click Windows installer (`install.bat`), automatic DSH runtime discovery.\n"
            "- **SolidWorks 2020-2026 Compatibility**: Dynamic API fallback and COM error classification.\n"
            "- **12-Dimensional Health Doctor**: Built-in `doctor.bat` with sanitized reports.\n"
            "- **Physically Verified**: 11/11 CAD loop steps on SolidWorks 2026 SP4.1 with 0.0000% error.\n\n"
            "### Artifact Verification\n"
            "- **Release Notes**: https://github.com/tan000tan/dsh-solidworks/releases/tag/v0.3.0\n"
            "- **Tarball**: https://github.com/tan000tan/dsh-solidworks/releases/download/v0.3.0/dsh-solidworks-0.3.0.tgz\n"
            "- **SHA-256**: `85dad498432daeb063f806c41e64aab1364dee01d0af494d4dc485b06e6962bc`\n"
            "- **Windows Installer (ZIP)**: https://github.com/tan000tan/dsh-solidworks/releases/download/v0.3.0/dsh-solidworks-v0.3.0-windows-installer.zip\n"
            "- **SHA-256**: `68ee95802a5322758a51878391f3f955b86ed06a720af67d1ffe1d21abf27ea0`\n"
        )
    }

    req = urllib.request.Request(api_url, data=json.dumps(pr_payload).encode("utf-8"), headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req) as resp:
            pr_data = json.loads(resp.read().decode("utf-8"))
            log(f"🎉 市场投稿 PR 创建成功: {pr_data['html_url']} (PR #{pr_data['number']})")
    except urllib.error.HTTPError as e:
        err_msg = e.read().decode("utf-8")
        log(f"PR API 返回: HTTP {e.code} - {err_msg}")
        # 尝试查询是否有已存在的 PR
        check_req = urllib.request.Request(f"{api_url}?head=tan000tan:{branch_name}&state=all", headers=headers)
        try:
            with urllib.request.urlopen(check_req) as c_resp:
                existing = json.loads(c_resp.read().decode("utf-8"))
                if existing:
                    log(f"已存在对应 PR: {existing[0]['html_url']} (状态: {existing[0]['state']})")
        except Exception:
            pass

if __name__ == "__main__":
    main()
